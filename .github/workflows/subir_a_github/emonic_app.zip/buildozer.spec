[app]
# Nombre que se ve en el celular
title = Emonic Lava
package.name = emoniclava
package.domain = org.judark

# preparar_movil.ps1 copia aquí main.py (= LamparaLava), ui/ y los PNG de la app.
# Las canciones NO se empaquetan: el usuario elige su carpeta de música al abrir la app.
source.dir = .
source.include_exts = py,png,jpg,json,ttf
source.exclude_dirs = bin,.buildozer

version = 0.1

# pygame + numpy (incluye sndarray/surfarray); pyjnius y android para permisos y abrir enlaces
requirements = python3,pygame,numpy,pyjnius,android

orientation = portrait
fullscreen = 1

# Leer la música y las portadas del celular
#   Android 13+ : READ_MEDIA_AUDIO y READ_MEDIA_IMAGES
#   Android 12- : READ_EXTERNAL_STORAGE
android.permissions = READ_MEDIA_AUDIO, READ_MEDIA_IMAGES, (name=android.permission.READ_EXTERNAL_STORAGE;maxSdkVersion=32)

android.api = 34
android.minapi = 24
android.archs = arm64-v8a, armeabi-v7a
android.accept_sdk_license = True

p4a.bootstrap = sdl2

# icon.filename = %(source.dir)s/icono.png
# presplash.filename = %(source.dir)s/Bckground.png

[buildozer]
log_level = 2
warn_on_root = 1
