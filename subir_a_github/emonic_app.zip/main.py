# -*- coding: utf-8 -*-
"""
EMONIC LAVA — prototipo móvil 1080x1920 con arquitectura de ventanas internas.

Ventanas:
  - VentanaPrincipal (contenedor de las pestañas: Inicio, Buscar, Descargas y sus páginas)
  - BarraNavegacion  (barra inferior con las pestañas)
  - VentanaLampara   (panel deslizante anclado abajo; mini al minimizar)
  - VentanaAjustesVis (panel inferior sobre el reproductor: tipo y estilo del visualizador)

Controles:
  mouse: botones/barra de la lámpara | botón ▼ minimiza | tocar la mini-lámpara expande
  teclado: a/d ±5s | r reinicio | espacio play-pausa | ↑↓ volumen | 1/2 bolas | m minimizar | v cambia de visualizador | c portada <-> visualizador | e imprime energía y valencia | i mapa de imágenes | g plantillas de imágenes
"""

import colorsys
import json
import math
import os
import random
import sys
import threading
import unicodedata
import webbrowser

import numpy as np
import pygame
import pygame.sndarray
import pygame.surfarray

# ------------------------------------------------------------------ constantes
ANCHO, ALTO = 1080, 1920        # resolución de diseño (portrait, celular)
ALT_MINI = 320                  # altura del mini reproductor (la barra de pestañas va debajo)
FPS = 60
BUFFER_SIZE = 2048
ESCALA_FFT = 4.0 / BUFFER_SIZE
GRID_W, GRID_H = 180, 320       # campo de metaballs (proporción 9:16)
GRAV, FLOT = 35.0, 96.0

# ¿Corre en un celular Android (empaquetado con Buildozer / python-for-android)?
ES_ANDROID = "ANDROID_ARGUMENT" in os.environ or hasattr(sys, "getandroidapilevel")

# Biblioteca: se llena al inicio con la carpeta de música que elige el usuario (ver cargar_biblioteca()).
#   CANCIONES: nombres de archivo dentro de CARPETA_MUSICA (así las playlists guardan solo el nombre)
#   PORTADAS : ruta completa de la portada de cada canción (mismo nombre .jpg/.png) o None
CARPETA_MUSICA = None
EXT_AUDIO = (".mp3", ".wav", ".ogg", ".flac")
EXT_PORTADA = (".jpg", ".jpeg", ".png")
CANCIONES = []
PORTADAS = []

# ------------------------------------------------------------------ pestañas y fuentes de descarga
NAV_H = 200                      # alto de la barra de pestañas (abajo del todo)

# Pestañas de la barra inferior: (id, texto). Cada una abre su propia ventana (ver VentanaPrincipal).
# El id da el nombre de sus imágenes: ui/nav_<id>.png  (y nav_<id>_on.png cuando está activa).
# Para añadir una pestaña: agrega una tupla aquí y su página en VentanaPrincipal.paginas.
PESTANAS = (("inicio", "Inicio"), ("buscar", "Buscar"), ("descargas", "Descargas"))

# Pestaña "Descargas": una tarjeta por cada fuente -> (nombre, dirección, descripción).
# Son ejemplos de fuentes gratuitas y legales: cámbialos por los que quieras.
SITIOS_DESCARGA = [
    ("Free Music Archive", "https://freemusicarchive.org", "Música libre con licencias abiertas"),
    ("Jamendo Music", "https://www.jamendo.com", "Artistas independientes (Creative Commons)"),
    ("Bandcamp", "https://bandcamp.com", "Descarga directa desde los artistas"),
    ("Beatport", "https://www.beatport.com/", "Apoya a tus artistas favoritos"),
    ("Pixabay Music", "https://pixabay.com/music/", "Pistas gratuitas sin atribución"),
]
# False: tocar una fuente abre su ventana (con el botón "Abrir en el navegador").
# True : la abre directamente en el navegador.
SITIOS_ABRIR_DIRECTO = False

# Paletas del visualizador: (color caliente, color frío). None = tomarla de la portada.
PALETAS = {
    "energia": ((255, 70, 40), (70, 110, 255)),   # solo para la muestra del chip
    "portada": None,
    "calida": ((255, 150, 40), (200, 40, 90)),
    "fria": ((90, 210, 255), (70, 60, 220)),
    "neon": ((60, 255, 170), (255, 50, 200)),
}

# Cristal esmerilado sobre el visualizador. Nivel -> parámetros del efecto:
#   lava_radio / lava_pasadas : cuánto se difumina la lava (en celdas de su cuadrícula de 180x320)
#   laser_div                 : cuánto se difumina el láser (más alto = más borroso)
#   mezcla                    : 0..1, parte de imagen desenfocada frente a la nítida
#   grano                     : intensidad del punteado del vidrio mate (0 = sin grano)
CRISTAL = {1: {"lava_radio": 2, "lava_pasadas": 1, "laser_div": 3, "mezcla": 0.50, "grano": 5},   # Suave
           2: {"lava_radio": 3, "lava_pasadas": 2, "laser_div": 6, "mezcla": 0.85, "grano": 9}}   # Mate

# La lava se mueve más rápido con más energía: 0 = velocidad constante, 0.5 = de 0.75x a 1.25x
LAVA_VEL_ENERGIA = 0.5
LAVA_RADIO = 0.40       # tamaño de la masa de lava al sonar (fracción del ancho; antes 0.26)
LAVA_RESORTE = 30.0     # cuánto se agrupa al centro al sonar (antes 46; menos = se reparte más)

# La energía suavizada de una canción suele moverse entre ~0.08 (calma) y ~0.55 (muy intensa): se estira a 0..1.
# Si tus canciones se ven siempre muy azules o muy rojas, ajusta estos dos números
# (la tecla 'e' imprime la energía actual en consola para calibrar).
ENERGIA_MIN, ENERGIA_MAX = 0.08, 0.55


# --------------------------------------------------- análisis de emoción (valencia)
# Perfiles de tonalidad de Krumhansl-Schmuckler (cuánto pesa cada nota respecto a la tónica).
PERFIL_MAYOR = np.array([6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88])
PERFIL_MENOR = np.array([6.33, 2.68, 3.52, 5.38, 2.60, 3.53, 2.54, 4.75, 3.98, 2.69, 3.34, 3.17])

# valencia = PESO_MODO * modo + PESO_BRILLO * brillo + PESO_TEMPO * tempo   (cada uno 0..1)
PESO_MODO, PESO_BRILLO, PESO_TEMPO = 0.50, 0.25, 0.25

# La valencia calculada suele moverse entre ~0.25 (oscura) y ~0.80 (luminosa): se estira a 0..1.
# Igual que con la energía, la tecla 'e' imprime el valor actual para calibrar.
VALENCIA_MIN, VALENCIA_MAX = 0.25, 0.80


def _correlacion_modo(chroma):
    """Correlación del chroma con la mejor tonalidad mayor y la mejor menor (12 giros de cada perfil)."""
    c = chroma - chroma.mean()
    nc = float(np.linalg.norm(c))
    if nc < 1e-9:
        return 0.0, 0.0
    mejores = []
    for perfil in (PERFIL_MAYOR, PERFIL_MENOR):
        p = perfil - perfil.mean()
        npf = float(np.linalg.norm(p))
        mejores.append(max(float(np.dot(c, np.roll(p, k))) / (nc * npf) for k in range(12)))
    return mejores[0], mejores[1]


def analizar_emocion(muestras, sr, seg=3.0):
    """Analiza la canción completa UNA sola vez (pensado para correr en un hilo).
    Devuelve {"t": segundos del centro de cada tramo, "valencia": 0..1 por tramo, "modo", "brillo",
    "tempo"} o None si el audio es demasiado corto.
        modo   : 1 = tonalidad mayor (alegre) ... 0 = menor (oscura)   [chroma + Krumhansl]
        brillo : centroide espectral, timbre apagado (0) -> brillante (1)
        tempo  : 70 BPM -> 0 ... 150 BPM -> 1                          [flujo espectral + autocorrelación]"""
    d = max(1, int(round(sr / 11025.0)))                 # a ~11 kHz: promediar grupos = filtro pasa-bajos
    n = (len(muestras) // d) * d
    x = muestras[:n].reshape(-1, d).mean(axis=1).astype(np.float32)
    sr2 = sr / d
    N, hop = 8192, 4096
    if len(x) < max(N, int(2 * seg * sr2)):
        return None
    dur = len(x) / sr2

    # ---- chroma (12 notas) y brillo por cuadro ----
    win = np.hanning(N).astype(np.float32)
    nf = 1 + (len(x) - N) // hop
    freqs = np.arange(N // 2 + 1) * sr2 / N
    banda = (freqs >= 130) & (freqs <= 2000)
    pc = (np.round(12 * np.log2(freqs[banda] / 440.0)).astype(int) + 9) % 12   # 0 = Do, 9 = La
    P = np.zeros((int(banda.sum()), 12), np.float32)
    P[np.arange(P.shape[0]), pc] = 1.0
    b_cen = (freqs >= 100) & (freqs <= 5000)
    chroma = np.zeros((nf, 12), np.float32)
    cent = np.zeros(nf, np.float32)
    for a in range(0, nf, 128):
        b = min(nf, a + 128)
        idx = hop * np.arange(a, b)[:, None] + np.arange(N)[None, :]
        mag = np.abs(np.fft.rfft(x[idx] * win, axis=1)).astype(np.float32)
        chroma[a:b] = (mag[:, banda] ** 0.7) @ P
        m = mag[:, b_cen]
        cent[a:b] = (m * freqs[b_cen]).sum(axis=1) / (m.sum(axis=1) + 1e-9)
    t_f = (np.arange(nf) * hop + N / 2) / sr2

    # ---- flujo espectral (golpes) para el tempo ----
    N2, hop2 = 512, 256
    win2 = np.hanning(N2).astype(np.float32)
    nf2 = 1 + (len(x) - N2) // hop2
    flujo = np.zeros(nf2, np.float32)
    previo = None
    for a in range(0, nf2, 512):
        b = min(nf2, a + 512)
        idx = hop2 * np.arange(a, b)[:, None] + np.arange(N2)[None, :]
        mag = np.log1p(10.0 * np.abs(np.fft.rfft(x[idx] * win2, axis=1))).astype(np.float32)
        dif = np.diff(mag, axis=0, prepend=(mag[:1] if previo is None else previo[None, :]))
        flujo[a:b] = np.maximum(dif, 0.0).sum(axis=1)
        previo = mag[-1]
    fps2 = sr2 / hop2
    lags = np.arange(int(60 * fps2 / 170), int(60 * fps2 / 70) + 1)
    bpms = 60 * fps2 / lags
    previa = np.exp(-0.5 * (np.log2(bpms / 115.0) / 0.55) ** 2)   # prefiere tempos "humanos"

    # ---- un valor por tramo ----
    nseg = max(1, int(dur // seg))
    tc = (np.arange(nseg) + 0.5) * seg
    modo = np.zeros(nseg)
    brillo = np.zeros(nseg)
    tempo = np.zeros(nseg)
    for i in range(nseg):
        dist = np.abs(t_f - tc[i])
        sel = dist <= 1.5 * seg                      # ±1.5 tramos de contexto: modo/brillo más estables
        if not sel.any():
            sel = dist <= dist.min() + 1e-9
        cM, cm = _correlacion_modo(chroma[sel].sum(axis=0))
        modo[i] = 0.5 + 0.5 * np.tanh(5.0 * (cM - cm))
        c = float(np.mean(cent[sel]))
        brillo[i] = min(1.0, max(0.0, np.log2(max(c, 1.0) / 600.0) / np.log2(3500.0 / 600.0)))
        a2, b2 = int(max(0, (tc[i] - 6) * fps2)), int(min(nf2, (tc[i] + 6) * fps2))
        f = flujo[a2:b2] - flujo[a2:b2].mean()
        bpm = 100.0
        if len(f) > lags[-1] + 4 and float(f.std()) > 1e-6:
            L = len(f)
            ac = np.fft.irfft(np.abs(np.fft.rfft(f, 2 * L)) ** 2)[:L]
            ac = ac / (ac[0] + 1e-9)
            bpm = float(bpms[int(np.argmax(ac[lags] * previa))])
        tempo[i] = min(1.0, max(0.0, (bpm - 70.0) / 80.0))

    val = PESO_MODO * modo + PESO_BRILLO * brillo + PESO_TEMPO * tempo
    if nseg >= 3:                                    # suavizado de 3 puntos (sin saltos bruscos)
        val = np.convolve(np.pad(val, 1, mode="edge"), [0.25, 0.5, 0.25], mode="valid")
    return {"t": tc, "valencia": val, "modo": modo, "brillo": brillo, "tempo": tempo}


# Los cuatro cuadrantes del modelo de Russell (valencia, energía) -> color
_ESQUINAS = {
    (0, 0): (55, 60, 200),     # triste / calmo      -> índigo
    (1, 0): (60, 205, 160),    # sereno / contento   -> menta
    (0, 1): (225, 25, 60),     # tenso / agresivo    -> carmesí
    (1, 1): (255, 195, 25),    # alegre / enérgico   -> amarillo ámbar
}


def _color_2d(v, e):
    """Interpolación bilineal (en RGB) entre los cuatro cuadrantes + piso de saturación/brillo
    para que el centro del mapa no se vea turbio. La energía también sube el brillo."""
    c = np.zeros(3)
    for (cv, ce), col in _ESQUINAS.items():
        c += (v if cv else 1.0 - v) * (e if ce else 1.0 - e) * np.array(col, float)
    h, s, br = colorsys.rgb_to_hsv(*(np.clip(c, 0, 255) / 255.0))
    s = max(s, 0.80)
    br = max(br, 0.90) * (0.82 + 0.18 * e)
    return tuple(int(255 * x) for x in colorsys.hsv_to_rgb(h, min(1.0, s), min(1.0, br)))


def color_emocion(energia, valencia=0.5):
    """(energía, valencia) -> (color caliente, color frío), modelo de Russell.
        tenso/agresivo (valencia baja, energía alta)  -> rojo / carmesí
        alegre/enérgico (valencia alta, energía alta) -> amarillo / naranja
        triste/calmo (valencia baja, energía baja)    -> azul / índigo
        sereno/contento (valencia alta, energía baja) -> verde / menta
    El color frío es el vecino del caliente en el mapa (algo más calmo): sirve para los degradados."""
    e = max(0.0, min(1.0, (energia - ENERGIA_MIN) / (ENERGIA_MAX - ENERGIA_MIN)))
    v = max(0.0, min(1.0, (valencia - VALENCIA_MIN) / (VALENCIA_MAX - VALENCIA_MIN)))
    e2 = e - 0.22 if e >= 0.22 else e + 0.22
    return _color_2d(v, e), _color_2d(v, e2)

# --------------------------------------------------- estado global del programa
pantalla = None        # ventana real (la que ve el usuario)
lienzo = None          # canvas virtual 1080x1920 donde se dibuja todo
factor_ventana = 1.0   # escala ventana->diseño para convertir el mouse
desplazamiento = (0, 0)  # margen (px) cuando la pantalla no es 9:16 y el lienzo queda centrado
reloj = None
gestor = None
ventana_lampara = None
ventana_principal = None
ventana_ajustes = None
ventana_nav = None
brillo_bombilla = None
volumen = 1.0
_fuentes = {}


# ------------------------------------------------------------------ utilidades
def fuente_t(tam):
    tam = max(8, int(tam))
    if tam not in _fuentes:
        _fuentes[tam] = pygame.font.Font(None, tam)
    return _fuentes[tam]


def _sombra_texto(dest, render, rect, desp):
    sombra = render.copy()
    sombra.fill((0, 0, 0, 255), special_flags=pygame.BLEND_RGBA_MULT)     # mismo texto, en negro
    sombra.set_alpha(150)
    dest.blit(sombra, rect.move(desp, desp + 1))


def texto(dest, cadena, x, y, tam, color=(255, 255, 255), sombra=False):
    render = fuente_t(tam).render(str(cadena), True, color)
    r = render.get_rect(center=(int(x), int(y)))
    if sombra:
        _sombra_texto(dest, render, r, max(1, int(tam // 28)))
    dest.blit(render, r)


def texto_ajustado(dest, cadena, cx, cy, tam, ancho_max, color=(255, 255, 255), sombra=False):
    """Texto centrado que reduce su tamaño hasta caber en ancho_max."""
    render = None
    for t in range(max(12, int(tam)), 11, -2):
        render = fuente_t(t).render(str(cadena), True, color)
        if render.get_width() <= ancho_max:
            break
    if render is None:
        render = fuente_t(12).render(str(cadena), True, color)
    r = render.get_rect(center=(int(cx), int(cy)))
    if sombra:                      # sombra suave: el texto se lee también sobre la lava clara
        _sombra_texto(dest, render, r, max(1, int(tam // 28)))
    dest.blit(render, r)


def texto_izq(dest, cadena, x, y, tam, ancho_max=None, color=(255, 255, 255)):
    """Texto alineado a la izquierda (x = borde, y = centro vertical).
    Si no cabe en ancho_max lo recorta con '...'."""
    cadena = str(cadena)
    render = fuente_t(tam).render(cadena, True, color)
    if ancho_max is not None and render.get_width() > ancho_max:
        n = len(cadena)
        while n > 1 and render.get_width() > ancho_max:
            n -= 1
            render = fuente_t(tam).render(cadena[:n].rstrip() + "...", True, color)
    dest.blit(render, render.get_rect(midleft=(int(x), int(y))))


# Paleta de la interfaz (grises, sobre el fondo gris (29, 30, 30) de las pestañas)
GRIS_FONDO = (29, 30, 30)
GRIS_BOTON = (50, 52, 52)         # botones, tarjetas y filas en reposo
GRIS_BOTON_ON = (78, 81, 81)      # seleccionado / activo
GRIS_TARJETA = (38, 40, 40)       # tarjeta del mini reproductor y de la barra inferior


def boton(dest, r, etiqueta, activo=False, tam=40, radio=24, desp=0):
    """Botón/chip con el estilo del menú (gris, sin borde)."""
    pygame.draw.rect(dest, GRIS_BOTON_ON if activo else GRIS_BOTON, r, border_radius=radio)
    texto(dest, etiqueta, r.centerx + desp, r.centery, tam)


# ------------------------------------------------------------------ imágenes de botones
# CÓMO PONER TUS IMÁGENES (3 pasos):
#   1. Crea una carpeta llamada  ui  junto a este archivo (emonic_lava.py).
#   2. Guarda ahí tus PNG (fondo transparente) con el NOMBRE EXACTO que espera cada botón.
#   3. Vuelve a abrir la app: ese botón ya usa tu imagen. Los que no tengan archivo siguen con texto,
#      así que puedes ir cambiándolos de a uno.
# Para saber qué nombre lleva cada botón y dónde está:
#   - Tecla  i  : rotula cada botón en pantalla con su archivo (verde = ya tiene imagen, rojo = falta).
#   - Tecla  g  : crea la carpeta  ui_plantillas  con un PNG de ejemplo por cada botón, ya con su nombre
#                 y tamaño correcto. Copia a  ui  los que quieras y reemplázalos por los tuyos.
# Los botones que se pueden "seleccionar" aceptan una versión  _on  (ej. nav_buscar_on.png) para cuando
# están activos; si no existe, se usa la misma imagen con un borde. La imagen se ajusta al botón sin
# deformarse (conviene dibujarla al doble del tamaño sugerido para que quede nítida).
CARPETA_UI = "ui"
MOSTRAR_CARATULA_VISUALIZADOR = False   # True: vuelve la carátula pequeña de abajo a la izquierda del visualizador
OJOS_LAVA = True                        # al pausar, una burbuja de la lámpara abre dos ojitos (solo en la lámpara de lava)
TINTAR_BOTON_VISUALIZADOR = True        # el botón del visualizador toma el color de la carátula
MOSTRAR_UI = False                # lo cambia la tecla i


def _slots_ui():
    """Todas las imágenes que la app sabe usar: (archivo sin .png, ancho, alto, dónde aparece, ¿tiene _on?)."""
    n = len(PESTANAS)
    w_nav = (ANCHO - 140 - 20 * (n - 1)) // n
    s = [(f"nav_{i}", w_nav, 120, f"Barra inferior: pestaña {t}", True) for i, t in PESTANAS]
    s += [("buscar_limpiar", 90, 90, "Buscar: borrar el texto", False)]
    s += [(f"inicio_playlist_{k + 1}", 490, 160, f"Inicio: botón de la playlist {k + 1}", False)
          for k in range(3)]
    s += [("altavoz_fondo", 430, 470, "Inicio: fondo del altavoz (textura de madera)", False),
          ("altavoz_cono", 360, 360, "Inicio: cono del altavoz (PNG cuadrado, centrado)", False)]
    s += [(f"sitio_{k + 1}", 960, 150, f"Descargas: tarjeta de {sit[0]}", False)
          for k, sit in enumerate(SITIOS_DESCARGA)]
    s += [("sitio_abrir", 960, 110, "Página de una fuente: Abrir en el navegador", False),
          ("pagina_volver", 120, 74, "Páginas de descarga: flecha para volver", False)]
    s += [("reproductor_anterior", 150, 150, "Reproductor: canción anterior", False),
          ("reproductor_siguiente", 150, 150, "Reproductor: canción siguiente", False),
          ("reproductor_play", 150, 150, "Reproductor: play", False),
          ("reproductor_pausa", 150, 150, "Reproductor: pausa", False),
          ("reproductor_minimizar", 300, 10, "Reproductor: barra para minimizar", False),
          ("reproductor_mas", 120, 74, "Reproductor: guardar en playlist (+); _on = ya guardada", True),
          ("reproductor_iniciar_visualizador", 206, 84, "Portada: iniciar visualizadores (y ajustes dentro)", False),
          ("reproductor_volver_portada", 120, 74, "Visualizador: volver a la portada", False)]
    s += [("modo_lava", 306, 90, "Ajustes visualizador: Lámpara de lava", True),
          ("modo_laser", 306, 90, "Ajustes visualizador: Láseres", True),
          ("modo_morfo", 306, 90, "Ajustes visualizador: Morfógeno", True)]
    s += [(f"paleta_{p}", 176, 90, f"Ajustes visualizador: paleta {p}", True)
          for p in ("energia", "portada", "calida", "fria", "neon")]
    s += [(f"lava_masa_{v}", 306, 90, f"Ajustes (lava): masa {v}", True) for v in (8, 14, 24)]
    s += [(f"laser_rayos_{v}", 306, 90, f"Ajustes (láseres): {v} rayos", True) for v in (8, 14, 20)]
    s += [(f"laser_disp_{v}", 225, 90, f"Ajustes (láseres): {v}", True)
          for v in ("vortice", "abanico", "cruzado", "radial")]
    s += [(f"morfo_sim_{v}", 306, 90, f"Ajustes (Morfógeno): simetría {v}", True)
          for v in ("ninguna", "espejo", "cuadruple")]
    s += [(f"morfo_react_{v}", 306, 90, f"Ajustes (Morfógeno): reactividad {v}", True)
          for v in ("suave", "normal", "intensa")]
    s += [(f"cristal_{v}", 306, 90, f"Ajustes visualizador: cristal {v}", True) for v in (0, 1, 2)]
    s += [("listo", 960, 95, "Ajustes visualizador: botón Listo", False)]
    return s
_cache_ui = {}
_cache_ui_esc = {}


def carpetas_base():
    """Dónde buscar la carpeta ui/: junto al .exe (si está empaquetado), dentro del paquete
    (PyInstaller), junto a este archivo y en la carpeta de trabajo."""
    bases = []
    if getattr(sys, "frozen", False):
        bases.append(os.path.dirname(os.path.abspath(sys.executable)))
        if getattr(sys, "_MEIPASS", None):
            bases.append(sys._MEIPASS)
    bases += [os.path.dirname(os.path.abspath(__file__)), os.getcwd()]
    vistas = []
    for b in bases:
        if b not in vistas:
            vistas.append(b)
    return vistas


ANIM_FPS = 24                     # velocidad por defecto de las animaciones (fotogramas por segundo)
ANIM_FPS_POR_NOMBRE = {}          # opcional: {"paleta_energia": 30} para una animación concreta
_cache_anim = {}


def ui_frames(nombre):
    """Fotogramas de una animación: ui/anim/<nombre>/*.png (en orden alfabético). [] si no hay."""
    if nombre not in _cache_anim:
        marcos = []
        for base in carpetas_base():
            carpeta = os.path.join(base, CARPETA_UI, "anim", nombre)
            if os.path.isdir(carpeta):
                for f in sorted(os.listdir(carpeta)):
                    if f.lower().endswith(".png"):
                        img = cargar_imagen(os.path.join(carpeta, f))
                        if img is not None:
                            marcos.append(img)
                if marcos:
                    print(f"[ui] animación '{nombre}': {len(marcos)} fotogramas ({carpeta})")
                    break
        _cache_anim[nombre] = marcos
    return _cache_anim[nombre]


def ui_img(nombre):
    """Imagen de ui/<nombre>.png (None si no existe). Si hay una animación ui/anim/<nombre>/ devuelve el
    fotograma que toca ahora (en bucle), así que cualquier botón se puede animar sin tocar más código.
    Si el archivo existe pero no se puede leer, lo dice."""
    marcos = ui_frames(nombre)
    if marcos:
        fps = ANIM_FPS_POR_NOMBRE.get(nombre, ANIM_FPS)
        return marcos[int(pygame.time.get_ticks() * fps / 1000.0) % len(marcos)]
    if nombre not in _cache_ui:
        img = None
        for base in carpetas_base():
            ruta = os.path.join(base, CARPETA_UI, nombre + ".png")
            if os.path.exists(ruta):
                img = cargar_imagen(ruta)
                print(("[ui] cargada: " if img is not None else "[ui] ERROR al leer: ") + ruta)
                break
        _cache_ui[nombre] = img
    return _cache_ui[nombre]


def etiqueta_ui(dest, r, nombre, hay_img):
    """Modo "mapa de imágenes" (tecla i): rotula el botón con el archivo que espera.
    Verde = ya tiene imagen en ui/, rojo = falta."""
    if not MOSTRAR_UI or r.w < 40 or r.h < 24:
        return
    col = (60, 220, 120) if hay_img else (255, 90, 90)
    pygame.draw.rect(dest, col, r, width=3, border_radius=12)
    txt = fuente_t(max(16, min(26, r.h // 3))).render(nombre + ".png", True, (0, 0, 0))
    fondo = pygame.Rect(r.x + 4, r.y + 4, txt.get_width() + 10, txt.get_height() + 6)
    pygame.draw.rect(dest, col, fondo, border_radius=6)
    dest.blit(txt, (fondo.x + 5, fondo.y + 3))


def boton_ui(dest, r, nombre, etiqueta, activo=False, tam=40, desp=0, estado_texto=None):
    """Botón con la imagen ui/<nombre>.png si existe; si no, el botón de texto de siempre.
    Activo: usa ui/<nombre>_on.png si existe, o la misma imagen con un borde."""
    img = ui_img(nombre + "_on") if activo else None
    con_borde = False
    if img is None:
        img = ui_img(nombre)
        con_borde = activo and img is not None
    if img is None:
        boton(dest, r, etiqueta, activo if estado_texto is None else estado_texto, tam, desp=desp)
        etiqueta_ui(dest, r, nombre, False)
        return
    clave = (id(img), r.w, r.h)
    if clave not in _cache_ui_esc:
        k = min(r.w / img.get_width(), r.h / img.get_height())   # "contener": sin deformar
        _cache_ui_esc[clave] = pygame.transform.smoothscale(
            img, (max(1, int(img.get_width() * k)), max(1, int(img.get_height() * k))))
    esc = _cache_ui_esc[clave]
    dest.blit(esc, esc.get_rect(center=r.center))
    if con_borde:                       # sin imagen _on: un velo claro marca que está activo
        velo = pygame.Surface((r.w, r.h), pygame.SRCALPHA)
        pygame.draw.rect(velo, (255, 255, 255, 38), velo.get_rect(), border_radius=24)
        dest.blit(velo, r.topleft)
    etiqueta_ui(dest, r, nombre, True)


_cache_icono = {}
_cache_acento = {}
_cache_tinte = {}


def color_acento(car):
    """Color vivo representativo de una carátula (RGB). Pondera los píxeles saturados y luminosos, así
    un fondo gris o negro no domina. Sin carátula devuelve un violeta suave."""
    if car is None:
        return (170, 140, 255)
    clave = id(car)
    if clave not in _cache_acento:
        peq = pygame.transform.smoothscale(car, (24, 24))
        a = pygame.surfarray.array3d(peq).astype(np.float32)
        mx, mn = a.max(axis=2), a.min(axis=2)
        sat = (mx - mn) / (mx + 1.0)
        w = (sat ** 2) * (mx / 255.0) + 0.002
        c = (a * w[..., None]).sum(axis=(0, 1)) / w.sum()
        h, sa, v = colorsys.rgb_to_hsv(*(float(x) / 255.0 for x in c))
        r, g, b = colorsys.hsv_to_rgb(h, max(sa, 0.50), 1.0)           # versión viva y brillante
        if len(_cache_acento) > 60:
            _cache_acento.clear()
        _cache_acento[clave] = (int(r * 255), int(g * 255), int(b * 255))
    return _cache_acento[clave]


def tintar(img, color):
    """Recolorea una imagen con transparencia: conserva su forma y sombreado y reemplaza su color por
    'color'. Funciona con imágenes de cualquier color, también blancas o grises: lo más claro pasa a ser
    una versión pastel del color (no queda blanco puro, para que el cambio siempre se note)."""
    q = tuple(int(c) // 6 * 6 for c in color)                 # cuantiza: pocas versiones en caché
    clave = (id(img), q)
    if clave not in _cache_tinte:
        if len(_cache_tinte) > 60:
            _cache_tinte.clear()
        rgb = pygame.surfarray.array3d(img).astype(np.float32)
        alfa = pygame.surfarray.array_alpha(img)
        lum = (0.299 * rgb[..., 0] + 0.587 * rgb[..., 1] + 0.114 * rgb[..., 2]) / 255.0
        lum = np.clip(lum / max(0.5, float(lum[alfa > 20].max()) if (alfa > 20).any() else 1.0), 0.0, 1.0)
        lum = lum ** 0.6                                       # sube los tonos medios: el color se ve vivo
        t = np.clip((lum - 0.80) / 0.20, 0.0, 1.0)
        blanco = 0.38 * t * t * (3 - 2 * t)                    # los brillos suben hasta un 38 % hacia el blanco
        base = np.array(q, dtype=np.float32)
        out = base[None, None, :] * lum[..., None] * (1 - blanco[..., None]) + 255.0 * blanco[..., None]
        s = pygame.Surface(img.get_size(), pygame.SRCALPHA)
        pygame.surfarray.blit_array(s, np.clip(out, 0, 255).astype(np.uint8))
        pygame.surfarray.pixels_alpha(s)[:] = alfa
        _cache_tinte[clave] = s
    return _cache_tinte[clave]


def dibujar_icono(dest, img, r):
    """Dibuja img (un fotograma de una animación) dentro de r, sin deformarla, con caché por tamaño."""
    clave = (id(img), r.w, r.h)
    if clave not in _cache_icono:
        k = min(r.w / img.get_width(), r.h / img.get_height())
        _cache_icono[clave] = pygame.transform.smoothscale(
            img, (max(1, int(img.get_width() * k)), max(1, int(img.get_height() * k))))
    esc = _cache_icono[clave]
    dest.blit(esc, esc.get_rect(center=r.center))


def generar_plantillas():
    """Crea ui_plantillas/ con un PNG por cada imagen que la app sabe usar, con su nombre y tamaño.
    Copia a ui/ las que quieras y reemplázalas por las tuyas (sin cambiar el nombre). No toca ui/."""
    base = os.path.join(carpetas_base()[0], "ui_plantillas")
    os.makedirs(base, exist_ok=True)
    n = 0
    for nombre, w, h, donde, con_on in _slots_ui():
        for sufijo in (("", "_on") if con_on else ("",)):
            s = pygame.Surface((w, h), pygame.SRCALPHA)
            rad = max(4, min(h // 3, 28))
            pygame.draw.rect(s, (95, 80, 160, 255) if sufijo else (45, 40, 70, 255), s.get_rect(), border_radius=rad)
            pygame.draw.rect(s, (150, 130, 220, 255), s.get_rect(), width=3, border_radius=rad)
            f = fuente_t(max(16, min(34, h // 3)))
            for k, linea in enumerate((nombre + sufijo, f"{w} x {h}")):
                t = f.render(linea, True, (255, 255, 255))
                if t.get_width() > w - 8:
                    t = pygame.transform.smoothscale(t, (w - 8, max(1, int(t.get_height() * (w - 8) / t.get_width()))))
                s.blit(t, t.get_rect(center=(w // 2, int(h / 2 + (k - 0.5) * f.get_linesize()))))
            pygame.image.save(s, os.path.join(base, nombre + sufijo + ".png"))
            n += 1
    return base, n


def _caja(a, r, eje):
    """Promedio móvil de ancho 2r+1 a lo largo de un eje (bordes con ceros)."""
    pad = [(0, 0)] * a.ndim
    pad[eje] = (r + 1, r)
    c = np.cumsum(np.pad(a, pad), axis=eje, dtype=np.float32)
    n = a.shape[eje]
    return (np.take(c, np.arange(2 * r + 1, 2 * r + 1 + n), axis=eje) -
            np.take(c, np.arange(0, n), axis=eje)) / (2 * r + 1)


def _desenfocar_campo(rgb, alfa, radio, pasadas, mezcla):
    """Desenfoque barato del campo de la lava (180x320). Usa el color premultiplicado por la
    opacidad para que los bordes no se oscurezcan al difuminarse."""
    p = np.dstack((rgb * alfa[..., None], alfa)).astype(np.float32)
    h, w = p.shape[:2]
    if radio >= 2 and h % 2 == 0 and w % 2 == 0:
        # el desenfoque se hace a la mitad de resolución (4 veces menos píxeles) y se vuelve a ampliar:
        # a este nivel de difuminado no se nota la diferencia y cuesta mucho menos
        q = p.reshape(h // 2, 2, w // 2, 2, 4).mean(axis=(1, 3))
        r2 = max(1, radio // 2)
        for _ in range(pasadas):
            q = _caja(_caja(q, r2, 0), r2, 1)
        q = np.repeat(np.repeat(q, 2, axis=0), 2, axis=1)
    else:
        q = p
        for _ in range(pasadas):
            q = _caja(_caja(q, radio, 0), radio, 1)
    pm = p + (q - p) * mezcla
    a = pm[..., 3]
    rgb_n = pm[..., :3] / np.maximum(a, 1e-3)[..., None]
    rgb_n = np.where(a[..., None] > 0.003, rgb_n, 0.0)
    return rgb_n, a


_cache_portadas = {}


def portada(img, tam, radio=20):
    """Portada escalada a tam x tam con esquinas redondeadas (cacheada)."""
    if img is None:
        return None
    clave = (id(img), tam, radio)
    if clave not in _cache_portadas:
        if len(_cache_portadas) > 80:        # tamaños animados: no dejar crecer la caché
            _cache_portadas.clear()
        s = pygame.transform.smoothscale(img, (tam, tam)).convert_alpha()
        mascara = pygame.Surface((tam, tam), pygame.SRCALPHA)
        pygame.draw.rect(mascara, (255, 255, 255, 255), mascara.get_rect(), border_radius=radio)
        s.blit(mascara, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
        _cache_portadas[clave] = s
    return _cache_portadas[clave]


def nombre_cancion(i):
    """('Título', 'Artista') a partir del nombre del archivo."""
    base = CANCIONES[i].rsplit(".", 1)[0]
    if " - " in base:
        artista, titulo = base.split(" - ", 1)
        return titulo, artista
    return base, ""


def carpeta_datos():
    """Carpeta donde la app puede escribir: en Android, su almacenamiento privado; en PC, junto a la app."""
    if ES_ANDROID:
        return os.environ.get("ANDROID_PRIVATE") or os.getcwd()
    return carpetas_base()[0]


ARCHIVO_DATOS = "emonic_datos.json"      # tu memoria: playlists y últimas canciones
ARCHIVO_CONFIG = "emonic_config.json"    # recuerda la carpeta de música elegida
_POS_CANCION = {}


def ruta_musica(nombre):
    return os.path.join(CARPETA_MUSICA or "", nombre)


def ruta_app(nombre):
    """Archivo propio de la app (iconos, fondo): se busca en las carpetas base."""
    for base in carpetas_base():
        r = os.path.join(base, nombre)
        if os.path.exists(r):
            return r
    return nombre


def _clave_nombre(s):
    """Para emparejar canción y portada aunque cambien espacios, guiones o tildes."""
    return "".join(ch for ch in _norm(s) if ch.isalnum())


def contar_canciones(carpeta):
    try:
        return sum(1 for f in os.listdir(carpeta)
                   if f.lower().endswith(EXT_AUDIO) and os.path.isfile(os.path.join(carpeta, f)))
    except OSError:
        return 0


def cargar_biblioteca(carpeta):
    """Llena CANCIONES y PORTADAS con los audios de la carpeta (y sus portadas). Devuelve cuántas hay."""
    global CARPETA_MUSICA
    try:
        archivos = sorted(os.listdir(carpeta), key=_norm)
    except OSError as ex:
        print(f"⚠ No se pudo leer la carpeta {carpeta}: {ex}")
        return 0
    imagenes = {}
    for f in archivos:
        base, ext = os.path.splitext(f)
        if ext.lower() in EXT_PORTADA:
            imagenes.setdefault(_clave_nombre(base), os.path.join(carpeta, f))
    canciones = [f for f in archivos
                 if f.lower().endswith(EXT_AUDIO) and os.path.isfile(os.path.join(carpeta, f))]
    if not canciones:
        return 0
    CARPETA_MUSICA = carpeta
    CANCIONES[:] = canciones                       # se modifican en su sitio: el resto del código las comparte
    PORTADAS[:] = [imagenes.get(_clave_nombre(os.path.splitext(c)[0])) for c in canciones]
    _POS_CANCION.clear()
    _POS_CANCION.update({c: i for i, c in enumerate(CANCIONES)})
    print(f"[biblioteca] {len(CANCIONES)} canciones en {carpeta}")
    return len(CANCIONES)


def leer_config():
    try:
        with open(os.path.join(carpeta_datos(), ARCHIVO_CONFIG), encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def guardar_config(d):
    try:
        with open(os.path.join(carpeta_datos(), ARCHIVO_CONFIG), "w", encoding="utf-8") as f:
            json.dump(d, f, ensure_ascii=False, indent=2)
    except OSError as ex:
        print(f"⚠ No se pudo guardar la configuración: {ex}")


class Datos:
    """Memoria de la app. Guarda TUS playlists y las canciones recientes en emonic_datos.json.
    Las canciones se guardan por NOMBRE de archivo (no por posición), así no se desordenan si cambias
    la lista CANCIONES; si una canción ya no existe, simplemente no aparece (el archivo no la pierde)."""

    def __init__(self, ruta=None):
        self.ruta = ruta or os.path.join(carpeta_datos(), ARCHIVO_DATOS)
        self.listas = []                 # [{"nombre": str, "canciones": [archivo, ...]}]
        self.recientes = []              # archivos, el más nuevo primero
        self.cargar()

    def cargar(self):
        try:
            with open(self.ruta, encoding="utf-8") as f:
                d = json.load(f)
        except (OSError, ValueError):
            return
        if not isinstance(d, dict):
            return
        for l in d.get("playlists", []):
            if isinstance(l, dict) and isinstance(l.get("nombre"), str):
                cs = l.get("canciones", [])
                self.listas.append({"nombre": l["nombre"],
                                    "canciones": [c for c in cs if isinstance(c, str)]})
        self.recientes = [c for c in d.get("recientes", []) if isinstance(c, str)]

    def guardar(self):
        try:
            tmp = self.ruta + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump({"playlists": self.listas, "recientes": self.recientes}, f,
                          ensure_ascii=False, indent=2)
            os.replace(tmp, self.ruta)           # reemplazo atómico: nunca queda un archivo a medias
        except OSError as ex:
            print(f"⚠ No se pudo guardar {self.ruta}: {ex}")

    def indices(self, k):
        """Índices (en CANCIONES) de la playlist k, en su orden."""
        return [_POS_CANCION[n] for n in self.listas[k]["canciones"] if n in _POS_CANCION]

    def contiene(self, k, idx):
        return CANCIONES[idx] in self.listas[k]["canciones"]

    def en_alguna(self, idx):
        return any(CANCIONES[idx] in l["canciones"] for l in self.listas)

    def nueva(self, nombre):
        nombre = " ".join(nombre.split())[:30] or f"Playlist {len(self.listas) + 1}"
        base, n = nombre, 2
        while any(l["nombre"].lower() == nombre.lower() for l in self.listas):
            nombre, n = f"{base} {n}", n + 1
        self.listas.append({"nombre": nombre, "canciones": []})
        self.guardar()
        return len(self.listas) - 1

    def alternar(self, k, idx):
        """Añade la canción a la playlist, o la quita si ya estaba. Devuelve True si quedó dentro."""
        cs = self.listas[k]["canciones"]
        nombre = CANCIONES[idx]
        if nombre in cs:
            cs.remove(nombre)
            dentro = False
        else:
            cs.append(nombre)
            dentro = True
        self.guardar()
        return dentro

    def quitar(self, k, idx):
        if CANCIONES[idx] in self.listas[k]["canciones"]:
            self.listas[k]["canciones"].remove(CANCIONES[idx])
            self.guardar()

    def eliminar(self, k):
        del self.listas[k]
        self.guardar()


def mapear(valor, a1, b1, a2, b2):
    return a2 + (valor - a1) * (b2 - a2) / (b1 - a1)


def mapear_volumen_a_ganancia(vol):
    return mapear(vol, 0.0, 1.0, -40, 0)


def cargar_imagen(ruta):
    if not ruta:
        return None
    try:
        return pygame.image.load(ruta).convert_alpha()
    except (pygame.error, FileNotFoundError) as err:
        if os.path.exists(ruta):             # existe pero no se puede leer: avisa (si no existe, es normal)
            print(f"[ui] no se pudo abrir {ruta}: {err}")
        return None


def crear_bombilla():
    """Resplandor cálido de la base (256 px, se escala al dibujar)."""
    global brillo_bombilla
    S = 256
    yy, xx = np.mgrid[0:S, 0:S]
    d = np.sqrt((xx - S / 2) ** 2 + (yy - S / 2) ** 2) / (S / 2)
    inten = np.clip(1.0 - d, 0, 1) ** 2.2
    rgba = np.zeros((S, S, 4), np.uint8)
    rgba[..., 0] = (255 * inten).astype(np.uint8)
    rgba[..., 1] = (185 * inten).astype(np.uint8)
    rgba[..., 2] = (110 * inten).astype(np.uint8)
    rgba[..., 3] = 255
    brillo_bombilla = pygame.image.frombuffer(rgba.tobytes(), (S, S), "RGBA").convert_alpha()


# ------------------------------------------------------------------ audio (igual)
class NivelBanda:
    """Convierte la energía cruda de una banda (graves, medios, agudos) en un nivel 0..1 con CONTRASTE
    constante: compara cada valor con lo que ha pasado en los últimos segundos (percentiles), no con el
    pico máximo de toda la canción. Así un golpe enorme no "apaga" el resto de la música y un pasaje
    suave sigue moviendo el visualizador."""

    def __init__(self, ventana=4.0, hz=40.0, potencia=0.5):
        self.n = int(ventana * hz)
        self.paso = 1.0 / hz
        self.pot = potencia
        self.reiniciar()

    def reiniciar(self):
        self.buf = np.zeros(self.n, np.float32)
        self.lleno = 0
        self.i = 0
        self.acum = 0.0
        self.ref = 1e-4              # referencia lenta de volumen (evita amplificar el silencio)

    def nivel(self, valor, dt):
        v = max(0.0, float(valor)) ** self.pot            # compresión: se parece más a cómo oímos
        self.ref = max(v, self.ref * math.exp(-dt / 20.0))
        self.acum += dt
        if self.acum >= self.paso:                         # muestreo regular, sin depender de los FPS
            self.acum = 0.0
            self.buf[self.i] = v
            self.i = (self.i + 1) % self.n
            self.lleno = min(self.n, self.lleno + 1)
        if self.lleno < 6:                                 # recién empieza: sin historial todavía
            return max(0.0, min(1.0, v / (self.ref + 1e-9)))
        ventana = self.buf[:self.lleno]
        lo = float(np.percentile(ventana, 12))
        hi = float(np.percentile(ventana, 93))     # ignora picos aislados muy cortos
        hi = max(hi, 0.30 * self.ref)                      # nunca tratar un susurro como si fuera un golpe
        lo = min(lo, 0.85 * hi)
        return max(0.0, min(1.0, (v - lo) / (hi - lo + 1e-9)))


class DetectorGolpe:
    """Golpe de bajo (bombo): se dispara al SUBIR por encima de 'sube' y no vuelve a disparar hasta que el
    nivel haya bajado de 'baja' (histéresis). Evita los falsos golpes dobles de un nivel que se queda alto."""

    def __init__(self, sube=0.62, baja=0.34, espera=0.16):
        self.sube, self.baja, self.espera = sube, baja, espera
        self.armado = True
        self.ultimo = -1.0

    def golpe(self, nivel, t):
        if nivel < self.baja or (t - self.ultimo) > 0.60:   # se rearma al bajar (o tras 0.6 s sin golpe)
            self.armado = True
        if self.armado and nivel > self.sube and (t - self.ultimo) > self.espera:
            self.armado = False
            self.ultimo = t
            return True
        return False


def suavizar(actual, objetivo, dt, ataque=0.025, caida=0.14):
    """Suavizado independiente de los FPS: sube rápido (el golpe se nota) y baja más despacio."""
    tau = ataque if objetivo > actual else caida
    return actual + (objetivo - actual) * (1.0 - math.exp(-dt / tau))


class FFTAnalizador:
    def __init__(self, sample_rate, buffer_size=BUFFER_SIZE):
        self.sr = sample_rate
        self.N = buffer_size
        self.ventana = np.hanning(self.N).astype(np.float32)
        self.espectro = np.zeros(self.N // 2 + 1, dtype=np.float64)

    def freq_to_index(self, freq):
        return int(round(freq * self.N / self.sr))

    def forward(self, muestras, frame_inicio):
        fin = frame_inicio + self.N
        seg = muestras[frame_inicio:fin]
        if len(seg) < self.N:
            seg = np.pad(seg, (0, self.N - len(seg)))
        self.espectro = np.abs(np.fft.rfft(seg * self.ventana)) * ESCALA_FFT

    def get_band(self, i):
        return float(self.espectro[i])


class Reproductor:
    def __init__(self, ruta):
        self.sound = pygame.mixer.Sound(ruta)   # pygame.error si falta -> se maneja arriba
        self.ruta = ruta
        self.arr = pygame.sndarray.array(self.sound)
        self.sr = pygame.mixer.get_init()[0]

        mono = self.arr.astype(np.float32)
        if mono.ndim > 1:
            mono = mono.mean(axis=1)
        self.muestras = mono / 32768.0
        self.total_frames = len(self.muestras)
        self.duracion_ms = int(self.total_frames * 1000 / self.sr)

        self.canal = pygame.mixer.Channel(0)
        self._base_ms = 0
        self._tick = 0
        self.reproduciendo = False
        self.en_pausa = False

    @property
    def posicion(self):
        if self.reproduciendo and not self.en_pausa:
            return min(self._base_ms + (pygame.time.get_ticks() - self._tick),
                       self.duracion_ms)
        return self._base_ms

    @property
    def longitud(self):
        return self.duracion_ms

    def esta_reproduciendo(self):
        return self.reproduciendo and not self.en_pausa and self.canal.get_busy()

    def actualizar(self):
        if self.reproduciendo and not self.en_pausa and not self.canal.get_busy():
            self.reproduciendo = False
            self.en_pausa = False
            self._base_ms = self.duracion_ms

    def play(self):
        if self.en_pausa:
            self.canal.unpause()
            self._tick = pygame.time.get_ticks()
            self.en_pausa = False
            self.reproduciendo = True
        elif not self.reproduciendo:
            if self._base_ms >= self.duracion_ms - 50:
                self._base_ms = 0
            self._iniciar_desde(self._base_ms)

    def pause(self):
        if self.reproduciendo and not self.en_pausa:
            self._base_ms = self.posicion
            self.canal.pause()
            self.en_pausa = True

    def rewind(self):
        self.cue(0)

    def cue(self, ms):
        ms = max(0, min(int(ms), self.duracion_ms))
        if self.reproduciendo and not self.en_pausa:
            self._iniciar_desde(ms)
        else:
            self.canal.stop()
            self.reproduciendo = False
            self.en_pausa = False
            self._base_ms = ms

    def _iniciar_desde(self, ms):
        frame = max(0, min(int(ms * self.sr / 1000), self.total_frames - 1))
        trozo = np.ascontiguousarray(self.arr[frame:])
        if trozo.shape[0] == 0:
            self.reproduciendo = False
            return
        try:
            self.canal.play(pygame.sndarray.make_sound(trozo))
        except (pygame.error, ValueError) as e:
            print(f"⚠ Error al reposicionar el audio: {e}")
            self.reproduciendo = False
            self.en_pausa = False
            self._base_ms = 0
            return
        # --- ESTAS 4 LÍNEAS ERAN LAS QUE FALTABAN ---
        self._base_ms = ms
        self._tick = pygame.time.get_ticks()
        self.reproduciendo = True
        self.en_pausa = False

    def set_gain(self, ganancia_db):
        vol = 10 ** (ganancia_db / 20.0)
        self.canal.set_volume(max(0.0, min(1.0, vol)))


# ------------------------------------------------------------------ arquitectura
class Ventana:
    """Base de toda pantalla interna: rect + update + dibujar + evento."""

    def __init__(self, x, y, w, h):
        self.rect = pygame.Rect(x, y, w, h)
        self.visible = True

    def update(self, dt):
        pass

    def dibujar(self, dest):
        pass

    def evento(self, e):
        """Retorna True si consumió el evento (el gestor deja de propagarlo)."""
        return False

    def rueda(self, pos, dy):
        """Rueda del ratón sobre esta ventana (dy > 0 = hacia arriba). True si la consumió."""
        return False


class GestorVentanas:
    """Orden de dibujo = orden de lista (la última queda arriba).
    Eventos: de arriba hacia abajo; la primera que consume, gana."""

    def __init__(self):
        self.ventanas = []

    def add(self, v):
        self.ventanas.append(v)

    def update(self, dt):
        for v in self.ventanas:
            v.update(dt)

    def dibujar(self, dest):
        for v in self.ventanas:
            if v.visible:
                v.dibujar(dest)

    def evento(self, e):
        for v in reversed(self.ventanas):
            if not v.visible:
                continue
            if e.type == pygame.MOUSEMOTION or v.rect.collidepoint(e.pos):
                if v.evento(e):
                    return

    def rueda(self, pos, dy):
        for v in reversed(self.ventanas):
            if v.visible and v.rect.collidepoint(pos):
                if v.rueda(pos, dy):
                    return


# ------------------------------------------------------------------ lámpara de lava
class Blob:
    def __init__(self):
        self.x = GRID_W / 2 + random.uniform(-22, 22)
        self.y = random.uniform(GRID_H * 0.30, GRID_H * 0.90)
        self.r_base = random.uniform(9, 20)
        self.r = self.r_base
        self.vx = random.uniform(-5, 5)
        self.vy = random.uniform(-5, 5)
        self.temp = random.uniform(0.2, 0.9)
        self.fase = random.uniform(0, math.tau)
        self.wob = random.uniform(0.5, 1.5)


class LamparaDeLava:
    """Campo de metaballs rectangular (GRID_W x GRID_H) con física de convección.
    render() re-escala a cualquier tamaño de destino (para la mini-ventana)."""

    def __init__(self, n_blobs=14):
        self.blobs = [Blob() for _ in range(n_blobs)]
        self.burbujas = []
        self.agrupacion = 0.0    # 0 = lámpara libre | 1 = altavoz (agrupado al centro)
        self.centro = (GRID_W / 2, GRID_H * 0.52)
        self.pulso = 0.0
        self.t = 0.0
        self.ultimo_beat = -1.0
        self.det = DetectorGolpe(espera=0.18)
        self.alfa_burbujas = 1.0
        # --- ojitos de la mascota (aparecen al pausar) ---
        self.mascota = None            # la burbuja que lleva los ojos
        self.t_pausa = 0.0             # segundos que lleva en pausa
        self.ojo_prog = 0.0            # 0 = cerrados ... 1 = abiertos del todo (avanza linealmente)
        self.t_parpadeo = 0.0          # >0 mientras parpadea (0..1 y vuelve a 0)
        self.sig_parpadeo = 3.0
        self.mirada = [0.0, 0.0]       # hacia dónde mira la pupila (-1..1)
        self.mirada_obj = [0.0, 0.0]
        self.sig_mirada = 1.0
        self.ancla = None              # dónde van los ojos (centro de la masa donde está la mascota, suavizado)
        self._ojo_cache = {}
        self.set_colores((255, 150, 40), (200, 40, 90))

        ys = np.arange(GRID_H, dtype=np.float32)
        xs = np.arange(GRID_W, dtype=np.float32)
        self.X, self.Y = np.meshgrid(xs, ys)

        # sin máscara de "frasco": la lava puede llegar hasta los bordes de la pantalla
        self.xs = xs
        self.ys = ys

    def set_colores(self, caliente, fria):
        self.col_caliente = np.asarray(caliente, np.float32)
        self.col_fria = np.asarray(fria, np.float32)

    def medio_ancho(self, u):
        return GRID_W * 0.5                       # todo el ancho de la pantalla (antes un trapecio de 52-80 %)

    def agregar(self):
        if len(self.blobs) < 40:
            self.blobs.append(Blob())

    def quitar(self):
        if len(self.blobs) > 4:
            self.blobs.pop()

    def update(self, dt, bass, mid, high, activo=True):
        self.t += dt

        # --- transición de modo: altavoz (suena) <-> lámpara libre (pausa) ---
        objetivo = 1.0 if activo else 0.0
        self.agrupacion += (objetivo - self.agrupacion) * min(1.0, 1.6 * dt)
        if self.agrupacion < 0.003:
            self.agrupacion = 0.0
        elif self.agrupacion > 0.997:
            self.agrupacion = 1.0

        # fundido de burbujas (igual que antes)
        obj_b = 1.0 if activo else 0.0
        self.alfa_burbujas += (obj_b - self.alfa_burbujas) * min(1.0, 2.5 * dt)
        if not activo and self.alfa_burbujas <= 0.02:
            self.alfa_burbujas = 0.0
            self.burbujas.clear()

        cx, cy = self.centro

        # --- detección de beat ---
        if self.det.golpe(bass, self.t):
            self.ultimo_beat = self.t
            self.pulso = 1.0
            if self.agrupacion > 0.5:
                # MODO ALTAVOZ: patada radial hacia afuera (el "bombo")
                for b in self.blobs:
                    dx, dy = b.x - cx, b.y - cy
                    d = math.hypot(dx, dy) + 1e-3
                    imp = random.uniform(70, 130) * self.agrupacion
                    b.vx += dx / d * imp
                    b.vy += dy / d * imp
            else:
                # MODO LÁMPARA: impulso vertical según altura (no chocan el techo)
                for b in self.blobs:
                    margen = min(1.0, max(0.0, (b.y - GRID_H * 0.15) / (GRID_H * 0.35)))
                    b.vy -= random.uniform(88, 152) * margen
                    b.vx += random.uniform(-25, 25)
        self.pulso *= max(0.0, 1.0 - 3.5 * dt)

        for b in self.blobs:
            u = b.y / GRID_H

            # temperatura (solo gobierna la flotabilidad en modo libre)
            if u > 0.70:
                b.temp = min(1.0, b.temp + dt * 0.55 * (u - 0.60) / 0.40)
            else:
                b.temp = max(0.0, b.temp - dt * 0.14)

            # flotabilidad: se apaga gradualmente al agruparse
            b.vy += (GRAV - FLOT * b.temp) * (1.0 - self.agrupacion) * dt

            # --- MODO ALTAVOZ: resorte al centro + vibración de ferrofluido ---
            if self.agrupacion > 0.001:
                k = LAVA_RESORTE * self.agrupacion
                b.vx += (cx - b.x) * k * dt
                b.vy += (cy - b.y) * k * dt
                # temblor incoherente por gota, proporcional a los medios
                b.vx += math.sin(self.t * (22.0 + b.wob * 6.0) + b.fase * 7.0) \
                        * 1400.0 * mid * self.agrupacion * dt
                b.vy += math.cos(self.t * (19.0 + b.wob * 5.0) + b.fase * 5.0) \
                        * 900.0 * mid * self.agrupacion * dt
                # frontera circular blanda: nunca se alejan del centro
                dx, dy = b.x - cx, b.y - cy
                d = math.hypot(dx, dy)
                r_max = GRID_W * LAVA_RADIO + 36.0 * bass
                if d > r_max:
                    ex = (d - r_max) / d
                    b.x -= dx * ex * min(1.0, 6.0 * dt)
                    b.y -= dy * ex * min(1.0, 6.0 * dt)
                    b.vx *= 1.0 - min(0.9, 4.0 * dt)
                    b.vy *= 1.0 - min(0.9, 4.0 * dt)

            # techo suave (solo actúa en modo libre)
            zona_tope = GRID_H * 0.18
            if b.y < zona_tope and b.vy < 0:
                s = 1.0 - self.agrupacion
                b.vy *= 1.0 - 5.0 * dt * s
                b.vy += 40.0 * (1.0 - b.y / zona_tope) * dt * s

            # fricción (mayor al agruparse: masa más densa y controlada)
            f = max(0.0, 1.0 - (1.9 + 2.2 * self.agrupacion) * dt)
            b.vx *= f
            b.vy *= f
            b.x += b.vx * dt
            b.y += b.vy * dt

            # paredes del frasco
            hw = self.medio_ancho(u) - b.r * 0.15
            if b.x < GRID_W / 2 - hw:
                b.x = GRID_W / 2 - hw
                b.vx = abs(b.vx) * 0.5
            elif b.x > GRID_W / 2 + hw:
                b.x = GRID_W / 2 + hw
                b.vx = -abs(b.vx) * 0.5
            arriba = GRID_H * 0.03 + b.r * 0.25
            abajo = GRID_H * 0.985 - b.r * 0.25
            if b.y < arriba:
                b.y = arriba
                b.vy = abs(b.vy) * 0.15
            elif b.y > abajo:
                b.y = abajo
                b.vy = -abs(b.vy) * 0.4

            # radio: en modo altavoz late mucho más fuerte (bombo + temblor de agudos)
            extra = (0.55 * self.pulso + 0.45 * bass + 0.35 * high) * self.agrupacion
            b.r = b.r_base * (0.80 + 0.45 * b.temp) * \
                  (1 + 0.28 * self.pulso + 0.22 * bass + extra)

        # separación entre blobs (este bloque queda IGUAL que lo tenías)
        bs = self.blobs
        for i in range(len(bs)):
            for j in range(i + 1, len(bs)):
                b1, b2 = bs[i], bs[j]
                dx, dy = b2.x - b1.x, b2.y - b1.y
                d2 = dx * dx + dy * dy
                dmin = (b1.r + b2.r) * 0.55
                if 1e-4 < d2 < dmin * dmin:
                    d = math.sqrt(d2)
                    f2 = (dmin - d) * 25.0 * dt / d
                    b1.x -= dx * f2 * 0.5
                    b1.y -= dy * f2 * 0.5
                    b2.x += dx * f2 * 0.5
                    b2.y += dy * f2 * 0.5

        self._update_ojos(dt, activo)

        # burbujas con los agudos (este bloque queda IGUAL que lo tenías)
        if activo and high > 0.20 and len(self.burbujas) < 40 and random.random() < high * 0.5:
            hw0 = self.medio_ancho(0.88) - 8
            self.burbujas.append({
                "x": GRID_W / 2 + random.uniform(-hw0, hw0),
                "y": GRID_H * 0.93,
                "r": random.uniform(1.0, 3.2),
                "v": (20 + random.uniform(0, 35)) * (0.6 + high),
            })
        for bub in self.burbujas[:]:
            bub["y"] -= bub["v"] * dt * (1 + high)
            if bub["y"] < GRID_H * 0.10:
                self.burbujas.remove(bub)

    # ---------------------------------------------------------- ojitos (la mascota)
    OJO_ABRIR_S = 0.7                  # segundos que tardan en abrirse (con tus fotogramas: lo que dure tu animación)
    OJO_CERRAR_S = 0.18

    def _update_ojos(self, dt, activo):
        if activo or not OJOS_LAVA:
            self.t_pausa = 0.0
        else:
            self.t_pausa += dt
        quiere = OJOS_LAVA and (not activo) and self.t_pausa > 0.9 and self.agrupacion < 0.5   # espera a que la lava se suelte
        marcos = ui_frames("ojos_lava")
        dur_abrir = (len(marcos) / ANIM_FPS_POR_NOMBRE.get("ojos_lava", ANIM_FPS)) if marcos else self.OJO_ABRIR_S
        if quiere:
            if self.ojo_prog <= 0.0 and (self.mascota is None or self.mascota not in self.blobs):
                self.mascota = max(self.blobs, key=lambda b: b.r_base)        # la burbuja más grande es la mascota
            self.ojo_prog = min(1.0, self.ojo_prog + dt / max(0.05, dur_abrir))
        else:
            self.ojo_prog = max(0.0, self.ojo_prog - dt / self.OJO_CERRAR_S)
        if self.ojo_prog <= 0.0:
            self.t_parpadeo = 0.0
            self.sig_parpadeo = random.uniform(1.5, 3.5)
            return
        # parpadeo ocasional (solo con los ojos abiertos del todo)
        if self.t_parpadeo > 0.0:
            marcos_p = ui_frames("ojos_lava_parpadeo")
            dur = (len(marcos_p) / ANIM_FPS_POR_NOMBRE.get("ojos_lava_parpadeo", ANIM_FPS)) if marcos_p else 0.22
            self.t_parpadeo += dt / dur
            if self.t_parpadeo >= 1.0:
                self.t_parpadeo = 0.0
                self.sig_parpadeo = random.uniform(2.2, 6.0)
        elif self.ojo_prog >= 1.0:
            self.sig_parpadeo -= dt
            if self.sig_parpadeo <= 0.0:
                self.t_parpadeo = 1e-4
        # la mirada vaga: a veces al centro, a veces a un lado, siguiendo un poco el movimiento de la burbuja
        self.sig_mirada -= dt
        if self.sig_mirada <= 0.0:
            self.sig_mirada = random.uniform(1.2, 3.2)
            if random.random() < 0.35:
                self.mirada_obj = [0.0, 0.0]
            else:
                a, rr = random.uniform(0, math.tau), random.uniform(0.5, 1.0)
                self.mirada_obj = [math.cos(a) * rr, math.sin(a) * rr * 0.7]
        k = min(1.0, 7.0 * dt)
        b = self.mascota
        # los ojos van en el corazón de la masa: centro de la mascota y las burbujas que están pegadas a ella
        pesos = [(o, o.r * o.r) for o in self.blobs if math.hypot(o.x - b.x, o.y - b.y) < (o.r + b.r) * 1.15]
        tot = sum(w for _o, w in pesos) or 1.0
        ax = sum(o.x * w for o, w in pesos) / tot
        ay = sum(o.y * w for o, w in pesos) / tot
        if self.ancla is None or self.ojo_prog < 0.02:
            self.ancla = [ax, ay]
        else:
            self.ancla[0] += (ax - self.ancla[0]) * min(1.0, 8.0 * dt)
            self.ancla[1] += (ay - self.ancla[1]) * min(1.0, 8.0 * dt)
        sx = max(-1.0, min(1.0, b.vx / 25.0)) * 0.35 if b is not None else 0.0
        sy = max(-1.0, min(1.0, b.vy / 25.0)) * 0.35 if b is not None else 0.0
        self.mirada[0] += (self.mirada_obj[0] + sx - self.mirada[0]) * k
        self.mirada[1] += (self.mirada_obj[1] + sy - self.mirada[1]) * k

    def _sprite_ojo(self, D):
        """Un ojo de dibujos animados (esclera blanca, pupila negra con brillo), sin pupila: la pupila se pinta aparte."""
        if D not in self._ojo_cache:
            if len(self._ojo_cache) > 30:
                self._ojo_cache.clear()
            S = D * 3
            sup = pygame.Surface((S, S), pygame.SRCALPHA)
            pygame.draw.circle(sup, (70, 30, 30, 90), (S // 2, S // 2 + S // 40), S // 2 - 2)      # sombra suave
            pygame.draw.circle(sup, (250, 249, 246, 255), (S // 2, S // 2), S // 2 - S // 18)
            self._ojo_cache[D] = sup
        return self._ojo_cache[D]

    def dibujar_ojos(self, sup, esc_x, esc_y):
        """Dibuja los ojitos sobre la burbuja mascota. Usa tus fotogramas de ui/anim/ojos_lava/ si existen
        (y ojos_lava_parpadeo/ para los parpadeos); si no, unos ojos dibujados por código."""
        if self.ojo_prog <= 0.0 or self.mascota is None or not OJOS_LAVA:
            return
        b = self.mascota
        esc = min(esc_x, esc_y)
        ax, ay = self.ancla if self.ancla is not None else (b.x, b.y)
        cx, cy = ax * esc_x, ay * esc_y
        radio = b.r * esc * 1.25
        marcos = ui_frames("ojos_lava")
        if marcos:                                              # --- tu animación (PNG con transparencia)
            marcos_p = ui_frames("ojos_lava_parpadeo")
            if self.t_parpadeo > 0.0 and marcos_p:
                img = marcos_p[min(len(marcos_p) - 1, int(self.t_parpadeo * len(marcos_p)))]
            else:
                img = marcos[min(len(marcos) - 1, int(self.ojo_prog * len(marcos)))]
            ancho = max(8, int(radio * 1.6))
            alto = max(8, int(ancho * img.get_height() / img.get_width()))
            clave = (id(img), ancho)
            if clave not in self._ojo_cache:
                if len(self._ojo_cache) > 200:
                    self._ojo_cache.clear()
                self._ojo_cache[clave] = pygame.transform.smoothscale(img, (ancho, alto))
            esc_img = self._ojo_cache[clave]
            sup.blit(esc_img, esc_img.get_rect(center=(int(cx), int(cy - radio * 0.06))))
            return
        # --- ojos por código
        sm = self.ojo_prog * self.ojo_prog * (3.0 - 2.0 * self.ojo_prog)            # apertura suave
        pest = 1.0
        if self.t_parpadeo > 0.0:
            pest = max(0.04, abs(math.cos(self.t_parpadeo * math.pi)) ** 0.8)        # baja y sube
        o = sm * pest
        if o < 0.03:
            return
        D = max(10, int(radio * 0.80))                                              # diámetro de cada ojo
        D += D % 2
        base = self._sprite_ojo(D)
        # pupila (con brillo) pintada sobre una copia grande y luego reducida
        S = D * 3
        ojo = base.copy()
        pr = int(S * 0.20)
        px = S // 2 + int(self.mirada[0] * S * 0.17)
        py = S // 2 + int(self.mirada[1] * S * 0.17)
        pygame.draw.circle(ojo, (22, 14, 18, 255), (px, py), pr)
        pygame.draw.circle(ojo, (255, 255, 255, 255), (px - pr // 3, py - pr // 3), max(2, pr // 3))
        ojo = pygame.transform.smoothscale(ojo, (D, D))
        alto = max(2, int(D * o))
        ojo = pygame.transform.smoothscale(ojo, (D, alto)) if alto != D else ojo
        sep = radio * 0.40
        y = int(cy - radio * 0.06)
        for sgn in (-1, 1):
            sup.blit(ojo, ojo.get_rect(center=(int(cx + sgn * sep), y)))

    def render(self, sup, w_px, h_px, cristal=None):
        campo = np.zeros((GRID_H, GRID_W), dtype=np.float32)
        for b in self.blobs:                       # cada gota solo se calcula en su caja (no en toda la rejilla)
            R = b.r * 1.8
            x0, x1 = max(0, int(b.x - R)), min(GRID_W, int(b.x + R) + 2)
            y0, y1 = max(0, int(b.y - R)), min(GRID_H, int(b.y + R) + 2)
            if x1 <= x0 or y1 <= y0:
                continue
            dx = self.xs[x0:x1] - b.x
            dy = self.ys[y0:y1, None] - b.y
            t = 1.0 - (dx * dx + dy * dy) / (R * R)
            np.maximum(t, 0.0, out=t)
            campo[y0:y1, x0:x1] += t * t

        alfa = np.clip((campo - 0.45) / 0.40, 0.0, 1.0)
        alfa = alfa * alfa * (3.0 - 2.0 * alfa)

        gy, gx = np.gradient(campo)
        nx, ny, nz = -gx * 8.0, -gy * 8.0, np.ones_like(campo)
        largo = np.sqrt(nx * nx + ny * ny + nz * nz)
        nx /= largo
        ny /= largo
        nz /= largo
        dif = np.clip(nx * -0.45 + ny * -0.60 + nz * 0.66, 0.0, 1.0)
        esp = np.clip(nx * -0.249 + ny * -0.331 + nz * 0.917, 0.0, 1.0) ** 40

        u = self.Y / GRID_H
        base = self.col_fria + (self.col_caliente - self.col_fria) * (1.0 - u)[..., None]
        rgb = base * (0.30 + 0.75 * dif)[..., None]
        rgb += np.array((255, 235, 210), np.float32) * (0.9 * esp)[..., None]
        emis = np.clip(campo - 1.25, 0.0, 1.0) * 0.30
        rgb += self.col_caliente * emis[..., None]
        rgb = np.clip(rgb, 0.0, 255.0)
        rgb[alfa <= 0.003] = 0

        if cristal:                  # cristal esmerilado: difumina el campo (180x320, barato)
            rgb, alfa = _desenfocar_campo(rgb, alfa, cristal["lava_radio"],
                                          cristal["lava_pasadas"], cristal["mezcla"])
        data = np.dstack((rgb, alfa * 255.0)).astype(np.uint8)
        # convert_alpha ANTES de escalar: con el formato de la pantalla el blit es ~6 veces más rápido
        s_grid = pygame.image.frombuffer(data.tobytes(), (GRID_W, GRID_H), "RGBA").convert_alpha()
        sup.blit(pygame.transform.smoothscale(s_grid, (w_px, h_px)), (0, 0))

    _sprites = {}

    @classmethod
    def _sprite(cls, r):
        """Burbuja suave (círculo con borde difuminado), cacheada por radio."""
        if r not in cls._sprites:
            d = 2 * (r + 4)
            S = 4
            grande = pygame.Surface((d * S, d * S), pygame.SRCALPHA)
            pygame.draw.circle(grande, (255, 235, 205, 255), (d * S // 2, d * S // 2), r * S)
            spr = pygame.transform.smoothscale(grande, (d, d))
            chico = pygame.transform.smoothscale(spr, (max(2, d // 2), max(2, d // 2)))   # difumina el borde
            cls._sprites[r] = pygame.transform.smoothscale(chico, (d, d)).convert_alpha()
        return cls._sprites[r]

    def dibujar_burbujas(self, sup, esc_x, esc_y):
        """Dibuja las burbujas directamente en sup (unos pocos blits pequeños en vez de una capa completa)."""
        if self.alfa_burbujas <= 0.01 or not self.burbujas:
            return
        alfa = int(95 * self.alfa_burbujas)
        for bub in self.burbujas:
            disuelva = min(1.0, (bub["y"] - GRID_H * 0.10) / (GRID_H * 0.08))
            r = max(1, int(bub["r"] * esc_x * 0.5 * disuelva))
            spr = self._sprite(r)
            spr.set_alpha(alfa)
            sup.blit(spr, (int(bub["x"] * esc_x) - spr.get_width() // 2,
                           int(bub["y"] * esc_y) - spr.get_height() // 2))


class VisualizadorLaser:
    """Rayos láser. Misma interfaz que LamparaDeLava: update(dt, bass, mid, high, activo)
    y render(sup, w_px, h_px). Dibuja sobre un lienzo con rastro (como tu pg.background(0, 15)).
    Disposiciones: 'vortice' (tu versión de Processing, 3D con perspectiva), 'abanico',
    'cruzado' y 'radial'."""

    LW, LH = 360, 640            # resolución interna 9:16 (se escala al dibujar)
    # Cámara del vórtice: tus medidas de Processing (300, 600, -300, 700 sobre 1080 px)
    # escaladas a 360 px de ancho.
    R1, R2, Z1, Z2, F = 100.0, 200.0, -100.0, 233.0, 312.0

    def __init__(self, n_rayos=20, disposicion="vortice"):
        self.n = n_rayos
        self.disp = disposicion
        self.t = 0.0
        self.ang = 0.0           # giro del vórtice
        self.giro = 0.0          # fase del barrido de los otros estilos
        self.kick = 0.0          # patada de giro en cada golpe de bajo
        self.pulso = 0.0
        self.ultimo_beat = -1.0
        self.det = DetectorGolpe(espera=0.18)
        self.brillo = 0.25
        self.bass = self.mid = self.high = 0.0
        self.muestras = []       # colores de la portada (uno por rayo) cuando la paleta es 'Portada'
        self.set_colores((255, 150, 40), (200, 40, 90))
        self.rastro = pygame.Surface((self.LW, self.LH))
        self.comp = pygame.Surface((self.LW, self.LH))

    @staticmethod
    def _vivo(c):
        """Los láseres siempre son vivos: normaliza el color a su máxima intensidad."""
        c = np.asarray(c, np.float32)
        return c * (255.0 / max(1.0, float(c.max())))

    def set_colores(self, caliente, fria):
        self.col_caliente = self._vivo(caliente)
        self.col_fria = self._vivo(fria)

    def set_muestras(self, colores):
        self.muestras = [self._vivo(c) for c in colores] if colores else []

    def configurar(self, n_rayos, disposicion):
        if disposicion != self.disp:
            self.rastro.fill((0, 0, 0))
        self.n = n_rayos
        self.disp = disposicion

    def _color(self, i, f):
        if self.muestras:
            return self.muestras[i % len(self.muestras)]
        return self.col_fria + (self.col_caliente - self.col_fria) * f

    def _proy(self, x, y, z):
        """Proyección en perspectiva (cámara en z = F, mirando al centro)."""
        s = self.F / (self.F - z)
        return (self.LW / 2 + (x - self.LW / 2) * s, self.LH / 2 + (y - self.LH / 2) * s)

    # ---------------------------------------------------------- update
    def update(self, dt, bass, mid, high, activo=True):
        self.t += dt
        self.bass, self.mid, self.high = bass, mid, high
        if self.det.golpe(bass, self.t):
            self.ultimo_beat = self.t
            self.pulso = 1.0
            self.kick += 1.6                       # tu "angle += PI/12", pero solo en cada golpe
        self.pulso *= max(0.0, 1.0 - 4.0 * dt)
        self.kick *= max(0.0, 1.0 - 3.0 * dt)
        if activo:
            self.giro += (0.35 + 1.3 * mid + 1.1 * self.pulso) * dt
            self.ang += (0.20 + 1.2 * bass + self.kick) * dt
        else:
            self.giro += 0.25 * dt
            self.ang += 0.15 * dt
        objetivo = (0.70 + 0.45 * bass + 0.40 * self.pulso) if activo else 0.30
        self.brillo += (min(1.4, objetivo) - self.brillo) * min(1.0, 8.0 * dt)

        # rastro: el vórtice se desvanece despacio, los demás estilos se redibujan limpios
        if self.disp == "vortice":
            f = min(255, int(max(1, 840 * dt)))    # ~14 por frame a 60 fps (tu alpha 15)
        else:
            f = 255
        self.rastro.fill((f, f, f), special_flags=pygame.BLEND_RGB_SUB)
        if self.disp == "vortice":
            self._dibujar_vortice()
        else:
            self._dibujar_rayos()

    # ---------------------------------------------------------- vórtice (versión Processing)
    def _dibujar_vortice(self):
        cx, cy = self.LW / 2, self.LH / 2
        n = max(1, self.n)
        k = min(1.0, self.brillo)
        ancho = 1 + int(2 * self.bass + 1.5 * self.pulso)     # tu strokeWeight(bassEnergy*0.1)
        jit = 8.0 * self.mid                                  # tu x2 + midEnergy
        for i in range(n):
            a = self.ang + math.tau / n * i
            x1, y1 = cx + math.cos(a) * self.R1, cy + math.sin(a) * self.R1
            b = a + math.pi / 4
            x2, y2 = cx + math.cos(b) * self.R2, cy + math.sin(b) * self.R2
            p1 = self._proy(x1, y1, self.Z1)
            p2 = self._proy(x2, y2, self.Z2)
            p3 = self._proy(x2 + jit, y2 + jit, self.Z2)
            col = self._color(i, i / max(1, n - 1)) * k
            c = (int(min(255, col[0])), int(min(255, col[1])), int(min(255, col[2])))
            pygame.draw.line(self.rastro, c, (cx, cy), p1, ancho)   # centro -> anillo
            pygame.draw.line(self.rastro, c, p1, p2, ancho)         # anillo -> hacia la cámara
            pygame.draw.line(self.rastro, c, p1, p3, ancho)         # igual, con temblor de medios

        # haces finos al azar (tu addLightBeams): chispean con los agudos
        if self.high > 0.12:
            kh = min(1.0, 0.4 + self.high)
            for _ in range(5):
                col = self._color(random.randrange(n), random.random()) * kh
                c = (int(min(255, col[0])), int(min(255, col[1])), int(min(255, col[2])))
                a1 = self._proy(cx + random.uniform(-133, 133), cy + random.uniform(-133, 133),
                                random.uniform(-67, 67))
                a2 = self._proy(cx + random.uniform(-133, 133), cy + random.uniform(-133, 133),
                                random.uniform(-167, -100))
                pygame.draw.line(self.rastro, c, a1, a2, 1)

    # ---------------------------------------------------------- abanico / cruzado / radial
    def _rayos(self):
        """Lista de (origen_x, origen_y, ángulo, f); f en 0..1 reparte el color."""
        W, H = self.LW, self.LH
        n, g = self.n, self.giro
        res = []
        for i in range(n):
            f = i / max(1, n - 1)
            if self.disp == "cruzado":
                lado = -1 if i % 2 == 0 else 1
                ox = W * (0.04 if lado < 0 else 0.96)
                barrido = 0.5 + 0.5 * math.sin(g * 0.9 + i * 0.8)
                res.append((ox, H * 0.97, -lado * (0.12 + 0.75 * barrido), f))
            elif self.disp == "radial":
                res.append((W / 2, H * 0.5, g * 0.6 + i * math.tau / n, f))
            else:
                amp = 0.55 + 0.40 * (0.5 + 0.5 * math.sin(g * 0.5))
                ang = (f - 0.5) * 2.0 * amp + 0.22 * math.sin(g * 1.1 + i * 0.9)
                res.append((W / 2, H * 0.97, ang, f))
        return res

    def _dibujar_rayos(self):
        lienzo = self.rastro
        rayos = self._rayos()
        largo = self.LH * 1.6
        # tres pasadas (aura ancha -> cuerpo -> núcleo casi blanco)
        for ancho, intensidad in ((int(10 + 8 * self.pulso), 0.30), (5, 0.70), (2, 1.0)):
            for i, (ox, oy, ang, f) in enumerate(rayos):
                col = self._color(i, f)
                if ancho == 2:
                    col = col * 0.45 + 140.0
                k = intensidad * self.brillo
                c = (int(min(255, col[0] * k)), int(min(255, col[1] * k)),
                     int(min(255, col[2] * k)))
                fin = (ox + math.sin(ang) * largo, oy - math.cos(ang) * largo)
                pygame.draw.line(lienzo, c, (ox, oy), fin, ancho)
        k = min(1.0, self.brillo)
        c0 = tuple(int(v * k) for v in (self.col_caliente + 255.0) * 0.5)
        for ox, oy in {(round(r[0]), round(r[1])) for r in rayos}:
            pygame.draw.circle(lienzo, c0, (ox, oy), int(8 + 10 * self.pulso))

    # ---------------------------------------------------------- render
    def render(self, sup, w_px, h_px, cristal=None):
        W, H = self.LW, self.LH
        comp = self.comp
        comp.blit(self.rastro, (0, 0))
        # resplandor (bloom): versión borrosa sumada encima (sin tocar el rastro)
        halo = pygame.transform.smoothscale(
            pygame.transform.smoothscale(comp, (W // 8, H // 8)), (W, H))
        comp.blit(halo, (0, 0), special_flags=pygame.BLEND_RGB_ADD)
        comp.blit(halo, (0, 0), special_flags=pygame.BLEND_RGB_ADD)
        if cristal:                  # cristal esmerilado: difumina a 360x640 (casi gratis)
            d = cristal["laser_div"]
            borroso = pygame.transform.smoothscale(
                pygame.transform.smoothscale(comp, (max(2, W // d), max(2, H // d))), (W, H))
            borroso.set_alpha(int(255 * cristal["mezcla"]))
            comp.blit(borroso, (0, 0))
        sup.blit(pygame.transform.smoothscale(comp, (w_px, h_px)), (0, 0),
                 special_flags=pygame.BLEND_RGB_ADD)


class VisualizadorMorfogeno:
    """Reacción-difusión de Gray-Scott (el "morfógeno" de Turing) dirigida por la música.
    Idea tomada de la escena "morphogen" de photism.app: una figura que crece sola, los golpes de
    bajo siembran colonias nuevas, los acentos la re-dibujan y la paleta (5 colores, que puede salir
    de la portada) ilumina el crecimiento. Implementación propia, en numpy.
    Misma interfaz que los otros: update(dt, bass, mid, high, activo) y render(sup, w_px, h_px, cristal).

    simetria    : 'ninguna' | 'espejo' (izquierda-derecha) | 'cuadruple' (como un mandala)
    reactividad : 'suave' | 'normal' | 'intensa'   (equivale al REACT de Photism; también regula el destello)"""

    GW, GH = 126, 224                # cuadrícula 9:16 (pares, para que la simetría sea exacta)
    DU, DV = 1.0, 0.5                # difusión de los dos "químicos"
    ESC = 2.4                        # cuánto se estira v (0..~0.4) hacia la paleta
    REACT = {"suave": 0.5, "normal": 1.0, "intensa": 1.7}

    def __init__(self, simetria="cuadruple", reactividad="normal"):
        self.sim = simetria
        self.react = self.REACT[reactividad]
        self.t = 0.0
        self.u = np.ones((self.GH, self.GW), np.float32)
        self.v = np.zeros((self.GH, self.GW), np.float32)
        self._bu = np.zeros((self.GH + 2, self.GW + 2), np.float32)
        self._bv = np.zeros((self.GH + 2, self.GW + 2), np.float32)
        self.acum = np.zeros((self.GH, self.GW, 3), np.float32)
        self.pulso = 0.0
        self.destello = 0.0
        self.ultimo_beat = -1.0
        self.det = DetectorGolpe(espera=0.20)
        self.ultimo_claro = 0.0
        self.energia = 0.3
        self.bass = self.mid = self.high = 0.0
        self.paso_f = 0.0
        self.set_colores((255, 150, 40), (200, 40, 90))
        self.reiniciar()

    # ---------------------------------------------------------- paleta (5 colores)
    def set_colores(self, caliente, fria):
        c, f = np.asarray(caliente, np.float32), np.asarray(fria, np.float32)
        blanco = np.array([255, 255, 255], np.float32)
        self._lut_desde([f * 0.07, f * 0.55, f, c, c + (blanco - c) * 0.6])

    def set_muestras(self, colores):
        """Con la paleta 'Portada': 5 colores dominantes de la imagen (k-means), de oscuro a claro."""
        if not colores or len(colores) < 12:
            return
        pts = np.asarray(colores, np.float32)
        lum = pts @ np.array([0.3, 0.6, 0.1], np.float32)
        cent = pts[np.argsort(lum)[np.linspace(0, len(pts) - 1, 5).astype(int)]]   # arranque repartido
        for _ in range(8):
            d = ((pts[:, None, :] - cent[None, :, :]) ** 2).sum(axis=2)
            asig = d.argmin(axis=1)
            for j in range(5):
                if (asig == j).any():
                    cent[j] = pts[asig == j].mean(axis=0)
        cent = cent[np.argsort(cent @ np.array([0.3, 0.6, 0.1], np.float32))]
        # que el fondo sea oscuro y la punta clara, sin perder el tono de la portada
        cent[0] = cent[0] * min(1.0, 40.0 / max(1.0, float(cent[0].max())))
        cent[1:] = [c * (200.0 / max(1.0, float(c.max()))) if c.max() < 120 else c for c in cent[1:]]
        cent[4] = cent[4] + (255.0 - cent[4]) * 0.25
        self._lut_desde(list(cent))

    def _lut_desde(self, paradas):
        paradas = np.clip(np.asarray(paradas, np.float32), 0, 255)
        x = np.linspace(0, 1, 5)
        xs = np.linspace(0, 1, 256)
        self.lut = np.stack([np.interp(xs, x, paradas[:, c]) for c in range(3)], axis=1).astype(np.float32)

    def configurar(self, simetria, reactividad):
        cambio = simetria != self.sim
        self.sim = simetria
        self.react = self.REACT[reactividad]
        if cambio:
            self.reiniciar()

    # ---------------------------------------------------------- simulación
    def reiniciar(self):
        self.u.fill(1.0)
        self.v.fill(0.0)
        for _ in range(3):
            self._sembrar(random.randint(int(self.GW * 0.3), int(self.GW * 0.7)),
                          random.randint(int(self.GH * 0.3), int(self.GH * 0.7)), 5)

    def _sembrar(self, cx, cy, r):
        """Planta una colonia (y sus reflejos, según la simetría)."""
        pts = [(cx, cy)]
        if self.sim in ("espejo", "cuadruple"):
            pts.append((self.GW - 1 - cx, cy))
        if self.sim == "cuadruple":
            pts += [(cx, self.GH - 1 - cy), (self.GW - 1 - cx, self.GH - 1 - cy)]
        for x, y in pts:
            y0, y1 = max(0, y - r), min(self.GH, y + r + 1)
            x0, x1 = max(0, x - r), min(self.GW, x + r + 1)
            yy, xx = np.ogrid[y0:y1, x0:x1]
            m = (yy - y) ** 2 + (xx - x) ** 2 <= r * r
            self.u[y0:y1, x0:x1][m] = 0.5
            self.v[y0:y1, x0:x1][m] = 0.25

    def _borrar(self, cx, cy, r):
        """Abre un claro (y sus reflejos): la figura vuelve a crecer hacia adentro desde los bordes."""
        pts = [(cx, cy)]
        if self.sim in ("espejo", "cuadruple"):
            pts.append((self.GW - 1 - cx, cy))
        if self.sim == "cuadruple":
            pts += [(cx, self.GH - 1 - cy), (self.GW - 1 - cx, self.GH - 1 - cy)]
        for x, y in pts:
            y0, y1 = max(0, y - r), min(self.GH, y + r + 1)
            x0, x1 = max(0, x - r), min(self.GW, x + r + 1)
            yy, xx = np.ogrid[y0:y1, x0:x1]
            m = (yy - y) ** 2 + (xx - x) ** 2 <= r * r
            self.u[y0:y1, x0:x1][m] = 1.0
            self.v[y0:y1, x0:x1][m] = 0.0

    @staticmethod
    def _lap(a, buf):
        """Laplaciano 3x3 (0.2 vecinos, 0.05 diagonales) con bordes que se envuelven."""
        buf[1:-1, 1:-1] = a
        buf[0, 1:-1] = a[-1]
        buf[-1, 1:-1] = a[0]
        buf[1:-1, 0] = a[:, -1]
        buf[1:-1, -1] = a[:, 0]
        buf[0, 0], buf[0, -1], buf[-1, 0], buf[-1, -1] = a[-1, -1], a[-1, 0], a[0, -1], a[0, 0]
        adj = buf[:-2, 1:-1] + buf[2:, 1:-1] + buf[1:-1, :-2] + buf[1:-1, 2:]
        dia = buf[:-2, :-2] + buf[:-2, 2:] + buf[2:, :-2] + buf[2:, 2:]
        return 0.2 * adj + 0.05 * dia - a

    def _paso(self, f, k):
        u, v = self.u, self.v
        uvv = u * v * v
        du = self.DU * self._lap(u, self._bu) - uvv + f * (1.0 - u)
        dv = self.DV * self._lap(v, self._bv) + uvv - (f + k) * v
        u += du
        v += dv
        np.clip(u, 0.0, 1.0, out=u)
        np.clip(v, 0.0, 1.0, out=v)

    def update(self, dt, bass, mid, high, activo=True):
        self.t += dt
        self.bass, self.mid, self.high = bass, mid, high
        r = self.react
        if activo:
            self.energia += (0.5 * bass + 0.3 * mid + 0.2 * high - self.energia) * min(1.0, 0.8 * dt)

        # golpe de bajo: nuevas colonias + destello breve (limitado, ver HEAT en Photism)
        if activo and self.det.golpe(bass, self.t):
            self.ultimo_beat = self.t
            self.pulso = 1.0
            self.destello = 1.0
            for _ in range(1 + int(round(2 * r))):
                self._sembrar(random.randint(int(self.GW * 0.12), int(self.GW * 0.88)),
                              random.randint(int(self.GH * 0.12), int(self.GH * 0.88)),
                              random.randint(3, 6))
        # acento fuerte (o cada ~9 s aunque haya calma): se abre un claro que la figura vuelve a colonizar,
        # así el cuadro nunca se queda quieto
        espera = self.t - self.ultimo_claro
        if activo and ((bass > 0.8 and espera > 1.6 / r) or espera > 9.0):
            self.ultimo_claro = self.t
            self._borrar(random.randint(int(self.GW * 0.15), int(self.GW * 0.85)),
                         random.randint(int(self.GH * 0.15), int(self.GH * 0.85)),
                         random.randint(14, 30))
        self.pulso *= max(0.0, 1.0 - 4.0 * dt)
        self.destello *= max(0.0, 1.0 - 7.0 * dt)

        # el carácter del patrón sigue a la energía: calma = laberinto lento, intensa = células que se dividen
        en = min(1.0, max(0.0, (self.energia - 0.08) / 0.47))
        f = 0.0300 + 0.0045 * en + 0.003 * r * (bass - 0.4)
        k = 0.0570 + 0.0045 * en + 0.0020 * r * (mid - 0.4)
        n = int(round((5 + 4 * en + 2 * r) * dt * 60)) if activo else 2
        for _ in range(max(1, min(14, n))):
            self._paso(f, k)

        if float(self.v.max()) < 0.04:               # la colonia se extinguió: nueva semilla
            self.reiniciar()

    # ---------------------------------------------------------- dibujo
    def render(self, sup, w_px, h_px, cristal=None):
        t = np.clip(self.v * self.ESC, 0.0, 1.0)
        img = self.lut[(t * 255.0).astype(np.uint8)]
        r = self.react
        brillo = 0.70 + 0.26 * self.bass + 0.20 * min(1.0, r) * self.destello    # destello acotado
        img = img * brillo
        tr = 0.55 - 0.15 * min(1.0, r)                    # rastro: más reactivo = menos persistencia
        self.acum = self.acum * tr + img * (1.0 - tr)
        out = np.ascontiguousarray(np.clip(self.acum, 0, 255).astype(np.uint8))
        base = pygame.image.frombuffer(out.tobytes(), (self.GW, self.GH), "RGB").convert()

        # resplandor (bloom)
        halo = pygame.transform.smoothscale(
            pygame.transform.smoothscale(base, (self.GW // 6, self.GH // 6)), (self.GW, self.GH))
        base = base.copy()
        base.blit(halo, (0, 0), special_flags=pygame.BLEND_RGB_ADD)

        if cristal:                                       # cristal esmerilado: difumina la figura
            d = cristal["laser_div"]
            borroso = pygame.transform.smoothscale(
                pygame.transform.smoothscale(base, (max(2, self.GW // d), max(2, self.GH // d))),
                (self.GW, self.GH))
            borroso.set_alpha(int(255 * cristal["mezcla"]))
            base.blit(borroso, (0, 0))
        sup.blit(pygame.transform.smoothscale(base, (w_px, h_px)), (0, 0),
                 special_flags=pygame.BLEND_RGB_ADD)


# ------------------------------------------------------------------ ventana lámpara
class VentanaLampara(Ventana):
    def __init__(self):
        super().__init__(0, 0, ANCHO, ALTO)      # arranca en pantalla completa
        self.h_objetivo = ALTO
        self.mini = False
        self.barra = False
        self._ultimo_cue = 0

        # Carátula
        self.caratula_y = 620
        
        self.caratula_x = 620

        # Título
        self.titulo_y = 1080

        self.lampara = LamparaDeLava(14)
        self.laser = VisualizadorLaser()
        self.morfo = VisualizadorMorfogeno()
        self.vista = "normal"                      # "normal" (portada, al abrir) | "visualizador"
        self.vista_t = 0.0                         # 0 = portada ... 1 = visualizador (se anima)
        self._sombras = {}
        self._normal_cache = None
        self._normal_h = -1
        self._fondo_portada_cache = None
        self.vis_modo = "lava"                     # "lava" | "laser" | "morfo"
        self.cfg = {"paleta": "energia", "lava_masa": 14,
                    "laser_rayos": 20, "laser_disp": "vortice", "cristal": 2,
                    "morfo_sim": "cuadruple", "morfo_react": "normal"}
        self.energia = 0.0                         # energía suavizada de la canción (0..1)
        self._t_color = 0.0
        self.valencia = 0.5                        # valencia suavizada (0 oscura ... 1 luminosa)
        self.emocion = None                        # resultado de analizar_emocion() de la canción actual
        self._cache_emocion = {}                   # indice -> análisis (no se repite al volver a una canción)
        self._grano_cache = None
        self._capa2_cache = None
        self.ajustes = None                        # se asigna en setup()
        self._caratula_actual = None
        self.datos = Datos()                       # playlists y recientes (se guardan en emonic_datos.json)
        self.recientes = [_POS_CANCION[n] for n in self.datos.recientes if n in _POS_CANCION][:12]
        self.guardar = None                        # ventana "Guardar en playlist" (se asigna en setup())
        self.principal = None                      # contenedor de pestañas (lo asigna VentanaPrincipal)
        self.cola = list(range(len(CANCIONES)))    # lista que usan Anterior/Siguiente
        self.reproductor = None
        self.fft = None
        self.indice = 0
        self.img = []
        self.next_img = self.prev_img = self.pause_img = self.play_img = None

        self.bass_s = self.mid_s = self.high_s = 0.0
        self.picos = {"bass": 1e-3, "mid": 1e-3, "high": 1e-3}   # solo para la energía (color de la emoción)
        self.bass_e = self.mid_e = self.high_e = 0.0
        self.niveles = {k: NivelBanda() for k in ("bass", "mid", "high")}   # para mover los visualizadores

        # rects en coordenadas de diseño (escala 1, centrados en ANCHO/2)
        self.r_min = pygame.Rect(390, 30, 300, 10)
        self.r_prev = pygame.Rect(240, 1780, 120, 120)
        self.r_play = pygame.Rect(480, 1780, 120, 120)
        self.r_next = pygame.Rect(720, 1780, 120, 120)
        self.r_barra = pygame.Rect(90, 1700, 900, 16)
        self.r_volver = pygame.Rect(60, 30, 120, 74)     # visualizador: volver a la portada
        self.r_mas = pygame.Rect(ANCHO - 60 - 120, 30, 120, 74)   # botón +: guardar en una playlist
        self.v_titulo_y, self.v_artista_y = 1530, 1595   # visualizador: título y artista (como en la portada)
        self.v_tiempos_y = 1752                          # visualizador: tiempos (debajo de la barra)
        self._col_btn = None                             # color (animado) del botón del visualizador
        self._col_btn_t = 0
        # vista normal (portada grande, sin visualizador)
        self.n_barra = pygame.Rect(90, 1300, 900, 16)
        self.n_prev = pygame.Rect(240, 1405, 100, 100)
        self.n_play = pygame.Rect(485, 1405, 100, 100)
        self.n_next = pygame.Rect(740, 1405, 100, 100)
        self.r_mini_play = pygame.Rect(770, 105, 130, 130)   # (px) mini reproductor: play/pausa
        self.r_mini_next = pygame.Rect(930, 125, 90, 90)     # (px) mini reproductor: siguiente
        self.r_vis_portada = pygame.Rect(ANCHO/2-103, 1020, 206, 84)   # botón, en la portada (arriba del título)
        self.v_boton_dy = 118       # en el visualizador: el botón queda esta distancia por encima del título

        # caches de superficies (se reconstruyen si cambia la altura)
        self._superficie = None
        self._h_superficie = -1
        self._fondo_cache = None
        self._fondo_h = -1
        self._vidrio_cache = None
        self._vidrio_h = -1
        self._capa_cache = None
        self._capa_h = -1

    # ---------------------------------------------------------- carga
    def cargar_recursos(self):
        self.next_img = cargar_imagen(ruta_app("Next.png"))
        self.prev_img = cargar_imagen(ruta_app("Prev.png"))
        self.pause_img = cargar_imagen(ruta_app("Pause.png"))
        self.play_img = cargar_imagen(ruta_app("Play.png"))
        self.vizuali_img = cargar_imagen(ruta_app("Vizuali.png"))
        self.bck_img = cargar_imagen(ruta_app("Bckground.png"))
        self.vis_btn_img = cargar_imagen(ruta_app("BotonVis.png"))   # opcional: icono del botón de visualizador
        self.img = [cargar_imagen(p) for p in PORTADAS]
        self.indice = self.recientes[0] if self.recientes else random.randrange(len(CANCIONES))   # retoma la última
        self.cargar_cancion(self.indice)
        if self.reproductor is not None and self.reproductor.esta_reproduciendo():
            self.reproductor.pause()

    def cargar_cancion(self, indice):
        if self.reproductor is not None:
            self.reproductor.canal.stop()   # parar la anterior ANTES de lanzar la nueva
        intentos = 0
        while intentos < len(CANCIONES):
            try:
                rep = Reproductor(ruta_musica(CANCIONES[indice]))
                rep.play()
            except (pygame.error, OSError) as e:
                print(f"⚠ No se pudo cargar '{CANCIONES[indice]}', pruebo la siguiente. ({e})")
                indice = (indice + 1) % len(CANCIONES)
                intentos += 1
                continue
            break
        else:
            print("Ninguna canción de la carpeta elegida se pudo cargar.")
            return
        self.reproductor = rep
        if indice in self.recientes:
            self.recientes.remove(indice)
        self.recientes.insert(0, indice)
        del self.recientes[12:]
        self.datos.recientes = [CANCIONES[i] for i in self.recientes]
        self.datos.guardar()
        self.indice = indice
        rep.set_gain(mapear_volumen_a_ganancia(volumen))
        self.fft = FFTAnalizador(rep.sr)
        for n in self.niveles.values():
            n.reiniciar()                       # cada canción empieza con su propio historial
        self._lanzar_analisis(rep, indice)
        self._aplicar_paleta(self.img[indice])

    def _aplicar_paleta(self, caratula):
        self._caratula_actual = caratula
        self.laser.set_muestras(None)
        paleta = self.cfg["paleta"]
        if paleta == "energia":
            self._set_colores(*color_emocion(self.energia, self.valencia))
        elif PALETAS.get(paleta) is not None:
            self._set_colores(*PALETAS[paleta])
        elif caratula is None:
            self._set_colores((255, 150, 40), (200, 40, 90))
        else:
            pix = pygame.surfarray.array3d(caratula)
            w, h = pix.shape[0], pix.shape[1]
            m = []
            for _ in range(400):
                c = pix[random.randrange(w), random.randrange(h)]
                m.append((int(c[0]), int(c[1]), int(c[2])))
            m.sort(key=lambda c: 0.3 * c[0] + 0.6 * c[1] + 0.1 * c[2])
            self._set_colores(m[-3], m[len(m) // 3])
            self.morfo.set_muestras(m)                       # paleta de 5 colores (k-means) de la portada
            self.laser.set_muestras(random.sample(m[len(m) // 3:], 24))   # un color de la portada por rayo
        self._fondo_h = -1   # reconstruir el fondo con el nuevo color

    # ---------------------------------------------------------- visualizador y cola
    @property
    def visualizador(self):
        return {"laser": self.laser, "morfo": self.morfo}.get(self.vis_modo, self.lampara)

    def _set_colores(self, caliente, fria):
        self.lampara.set_colores(caliente, fria)
        self.laser.set_colores(caliente, fria)
        self.morfo.set_colores(caliente, fria)

    def aplicar_config(self):
        """Aplica self.vis_modo y self.cfg a los visualizadores (lo llama el panel de ajustes)."""
        n = self.cfg["lava_masa"]
        while len(self.lampara.blobs) < n:
            self.lampara.agregar()
        while len(self.lampara.blobs) > n:
            self.lampara.quitar()
        self.laser.configurar(self.cfg["laser_rayos"], self.cfg["laser_disp"])
        self.morfo.configurar(self.cfg["morfo_sim"], self.cfg["morfo_react"])
        self._aplicar_paleta(self._caratula_actual)

    def reproducir_cola(self, cola, empezar=0):
        """Reproduce una playlist desde la posición 'empezar' y abre el reproductor."""
        self.cola = list(cola)
        self.cargar_cancion(self.cola[empezar])
        self.expandir()

    def reproducir_indice(self, i):
        """Reproduce una canción suelta (p. ej. de 'Recientes') y abre el reproductor."""
        if i == self.indice and self.reproductor is not None:
            if not self.reproductor.esta_reproduciendo():
                self.reproductor.play()
        else:
            if i not in self.cola:
                self.cola = list(range(len(CANCIONES)))
            self.cargar_cancion(i)
        self.expandir()

    def _mover(self, delta):
        cola = self.cola if self.indice in self.cola else list(range(len(CANCIONES)))
        pos = cola.index(self.indice) if self.indice in cola else 0
        self.cargar_cancion(cola[(pos + delta) % len(cola)])

    # ---------------------------------------------------------- valencia (análisis en segundo plano)
    def _lanzar_analisis(self, rep, indice):
        """Analiza la canción completa en un hilo (modo mayor/menor, brillo, tempo).
        Mientras termina, la valencia es neutra. El resultado se guarda para no repetirlo."""
        if indice in self._cache_emocion:
            self.emocion = self._cache_emocion[indice]
            return
        self.emocion = None

        def trabajo():
            try:
                res = analizar_emocion(rep.muestras, rep.sr)
            except Exception as e:           # el análisis nunca debe tumbar el reproductor
                print(f"⚠ No se pudo analizar la emoción de la canción: {e}")
                res = None
            self._cache_emocion[indice] = res
            if self.reproductor is rep:
                self.emocion = res

        threading.Thread(target=trabajo, daemon=True).start()

    def _actualizar_valencia(self, dt):
        rep = self.reproductor
        if rep is None or self.emocion is None:
            objetivo = 0.5
        else:
            objetivo = float(np.interp(rep.posicion / 1000.0,
                                       self.emocion["t"], self.emocion["valencia"]))
        self.valencia += (objetivo - self.valencia) * min(1.0, 1.0 * dt)

    # ---------------------------------------------------------- cristal esmerilado
    def _cfg_cristal(self):
        """Parámetros del cristal elegido (None = nítido)."""
        return CRISTAL.get(self.cfg["cristal"])

    def _capa2(self):
        """Capa de burbujas a doble resolución de la cuadrícula: al escalarla se ven suaves."""
        if self._capa2_cache is None:
            self._capa2_cache = pygame.Surface((GRID_W * 2, GRID_H * 2), pygame.SRCALPHA)
        return self._capa2_cache

    def _grano(self, intensidad):
        """Punteado fijo (como el de un vidrio mate), del tamaño de la pantalla completa."""
        if self._grano_cache is None or self._grano_cache[0] != intensidad:
            rng = np.random.default_rng(7)
            ruido = rng.integers(0, intensidad + 1, (ALTO, ANCHO), dtype=np.uint8)
            rgb = np.ascontiguousarray(np.repeat(ruido[:, :, None], 3, axis=2))
            surf = pygame.image.frombuffer(rgb.tobytes(), (ANCHO, ALTO), "RGB").convert()
            self._grano_cache = (intensidad, surf)
        return self._grano_cache[1]

    def _cristal_mate(self, sup):
        """Grano del vidrio esmerilado sobre lo ya dibujado (antes de la interfaz).
        El desenfoque en sí se hace dentro de cada visualizador, a baja resolución (casi gratis)."""
        cfg = self._cfg_cristal()
        if cfg is None or cfg["grano"] <= 0:
            return
        w, h = sup.get_size()
        sup.blit(self._grano(cfg["grano"]), (0, 0), area=pygame.Rect(0, 0, w, h),
                 special_flags=pygame.BLEND_RGB_ADD)

    def margen_inf(self):
        """Espacio que deja libre abajo para la barra de pestañas: 0 a pantalla completa y NAV_H
        cuando está minimizado (crece a medida que se reduce, así se mueve junto con la animación)."""
        frac = (ALTO - self.rect.h) / float(ALTO - ALT_MINI)
        return int(round(NAV_H * max(0.0, min(1.0, frac))))

    # ---------------------------------------------------------- deslizamiento
    def expandir(self):
        self.h_objetivo = ALTO
        self.mini = False

    def contraer(self):
        self.h_objetivo = ALT_MINI
        self.mini = True

    # ---------------------------------------------------------- update
    def update(self, dt):
        # animación de altura (suavizado exponencial, anclada abajo)
        if abs(self.rect.h - self.h_objetivo) > 3:
            self.rect.h = int(round(self.rect.h +
                                    (self.h_objetivo - self.rect.h) * min(1.0, 9.0 * dt)))
            self.rect.y = ALTO - self.rect.h - self.margen_inf()
        elif self.rect.h != self.h_objetivo:
            self.rect.h = self.h_objetivo
            self.rect.y = ALTO - self.rect.h - self.margen_inf()

        rep = self.reproductor
        sonando = False
        if rep is not None:
            rep.actualizar()
            sonando = rep.esta_reproduciendo()

        if sonando:
            frame = int(rep.posicion * rep.sr / 1000)
            self.fft.forward(rep.muestras, frame)
            bass = self._energia(20, 200)
            mid = self._energia(200, 2000)
            high = self._energia(2000, 20000)
            self.picos["bass"] = max(self.picos["bass"] * 0.998, bass, 1e-3)
            self.picos["mid"] = max(self.picos["mid"] * 0.998, mid, 1e-3)
            self.picos["high"] = max(self.picos["high"] * 0.998, high, 1e-3)
        else:
            bass = mid = high = 0.0
        # energía (color de la emoción): igual que antes, normalizada con el pico
        self.bass_e += (min(1.0, bass / self.picos["bass"]) - self.bass_e) * 0.35
        self.mid_e += (min(1.0, mid / self.picos["mid"]) - self.mid_e) * 0.35
        self.high_e += (min(1.0, high / self.picos["high"]) - self.high_e) * 0.35
        # niveles para los visualizadores: con contraste constante y suavizado que no depende de los FPS
        for clave, crudo in (("bass", bass), ("mid", mid), ("high", high)):
            objetivo = self.niveles[clave].nivel(crudo, dt) if sonando else 0.0
            setattr(self, clave + "_s", suavizar(getattr(self, clave + "_s"), objetivo, dt,
                                                 ataque=0.022 if clave == "bass" else 0.035,
                                                 caida=0.13 if clave == "bass" else 0.10))

        if sonando:               # en pausa la energía se congela (conserva el color)
            e_inst = 0.5 * self.bass_e + 0.3 * self.mid_e + 0.2 * self.high_e
            self.energia += (e_inst - self.energia) * min(1.0, 0.8 * dt)
        self._actualizar_valencia(dt)
        self._t_color += dt
        if self.cfg["paleta"] == "energia" and self._t_color >= 0.1:
            self._t_color = 0.0
            self._set_colores(*color_emocion(self.energia, self.valencia))
            self._fondo_h = -1        # el fondo toma el tinte del color actual
        objetivo_v = 1.0 if self.vista == "visualizador" else 0.0
        self.vista_t += (objetivo_v - self.vista_t) * min(1.0, 8.0 * dt)
        if abs(objetivo_v - self.vista_t) < 0.004:
            self.vista_t = objetivo_v
        vis = self.visualizador
        dt_vis = dt
        if vis is self.lampara:          # la lava se mueve más rápido con más energía
            en = max(0.0, min(1.0, (self.energia - ENERGIA_MIN) / (ENERGIA_MAX - ENERGIA_MIN)))
            dt_vis = dt * (1.0 - LAVA_VEL_ENERGIA / 2 + LAVA_VEL_ENERGIA * en)
        if not self.mini and (self.vista_t > 0.0 or self.vista == "visualizador"):   # en la portada y en el mini no se simula nada
            vis.update(dt_vis, self.bass_s, self.mid_s, self.high_s, activo=sonando)

    def _energia(self, f1, f2):
        i1 = self.fft.freq_to_index(f1)
        i2 = min(self.fft.freq_to_index(f2), len(self.fft.espectro) - 1)
        if i2 <= i1:
            return 0.0
        return float(self.fft.espectro[i1:i2 + 1].mean())

    # ---------------------------------------------------------- eventos
    def evento(self, e):
        if e.type not in (pygame.MOUSEBUTTONDOWN, pygame.MOUSEBUTTONUP, pygame.MOUSEMOTION):
            return False
        s = self.rect.h / ALTO
        mx = ANCHO / 2 + (e.pos[0] - ANCHO / 2) / s     # a coords de diseño
        my = (e.pos[1] - self.rect.y) / s
        animando = abs(self.rect.h - self.h_objetivo) > 2

        if self.mini:
            if e.type == pygame.MOUSEBUTTONDOWN and not animando:
                rep = self.reproductor
                p = (e.pos[0], e.pos[1] - self.rect.y)
                if rep is not None and self.r_mini_play.collidepoint(p):
                    rep.pause() if rep.esta_reproduciendo() else rep.play()   # play/pausa del mini
                elif self.r_mini_next.collidepoint(p):
                    self._mover(1)                                           # siguiente
                else:
                    self.expandir()                  # el resto de la mini es un botón: expandir
            return e.type != pygame.MOUSEMOTION

        # pantalla completa: modal, consume todo el mouse
        R = self._rects()
        if e.type == pygame.MOUSEBUTTONDOWN and not animando:
            if self.r_min.collidepoint((mx, my)):
                self.contraer()
                return True
            if self.r_mas.collidepoint((mx, my)):
                if self.guardar is not None:
                    self.guardar.abrir(self.indice)      # guardar esta canción en una playlist
                return True
            if self.r_vis.collidepoint((mx, my)):
                if self.vista == "normal":
                    self.vista = "visualizador"      # iniciar los visualizadores
                elif self.ajustes is not None:
                    self.ajustes.abrir()             # ajustes del visualizador
                return True
            if self.vista == "visualizador" and self.r_volver.collidepoint((mx, my)):
                self.vista = "normal"                # volver a la portada
                return True
            if R["next"].collidepoint((mx, my)):
                self._mover(1)
                return True
            if R["prev"].collidepoint((mx, my)):
                self._mover(-1)
                return True
            if R["play"].collidepoint((mx, my)):
                rep = self.reproductor
                if rep is not None:
                    rep.pause() if rep.esta_reproduciendo() else rep.play()
                return True
            if R["barra"].inflate(0, 60).collidepoint((mx, my)):
                self.barra = True
                self._progreso(mx)
                return True
            return True          # incluye el menú inferior de la portada (sin función por ahora)
        if e.type == pygame.MOUSEBUTTONUP:
            self.barra = False
            return True
        if e.type == pygame.MOUSEMOTION and self.barra:
            self._progreso(mx)
            return True
        return True

    def rueda(self, pos, dy):
        return True                  # la rueda nunca abre el reproductor ni toca la música

    def _progreso(self, mx):
        rep = self.reproductor
        if rep is None:
            return
        ahora = pygame.time.get_ticks()
        if ahora - self._ultimo_cue < 150:
            return
        self._ultimo_cue = ahora
        rb = self._rects()["barra"]
        nueva = mapear(mx, rb.x, rb.x + rb.w, 0, rep.longitud)
        rep.cue(int(max(0, min(nueva, rep.longitud))))

    # ---------------------------------------------------------- dibujo
    def dibujar(self, dest):
        h = self.rect.h
        sup = self._obtener_superficie(h)
        self._dibujar_escena(sup)
        self._rotular_botones(sup, h / ALTO)
        dest.blit(sup, (0, self.rect.y))

    def _obtener_superficie(self, h):
        if self._superficie is None or self._h_superficie != h:
            self._superficie = pygame.Surface((ANCHO, h), pygame.SRCALPHA)
            self._h_superficie = h
            self._capa_h = -1
        return self._superficie

    @property
    def r_vis(self):
        """Rect del botón del visualizador. En la portada está donde lo pusiste (r_vis_portada); al entrar
        al visualizador se desliza hasta quedar justo encima del título de la canción, y al volver regresa."""
        a = self.r_vis_portada
        t = self.vista_t
        y = a.y + (self.v_titulo_y - self.v_boton_dy - a.y) * t
        return pygame.Rect(a.x, int(round(y)), a.w, a.h)

    def _px(self, r, s):
        """Rect de diseño -> píxeles: centrado horizontalmente, escala uniforme."""
        x = ANCHO / 2 + (r.x - ANCHO / 2) * s
        return pygame.Rect(int(x), int(r.y * s),
                           max(1, int(r.w * s)), max(1, int(r.h * s)))

    def _dibujar_escena(self, sup):
        h = sup.get_height()
        s = h / ALTO
        t = self.vista_t
        if self.mini:                      # el mini reproductor es siempre la tarjeta compacta
            t = 0.0
        if t > 0.001:
            self._dibujar_visualizador(sup)
        if t < 0.999:
            if t <= 0.001:
                self._dibujar_normal(sup, s)                # portada, directo y opaco
            else:                                           # fundido entre las dos vistas
                n = self._sup_normal(h)
                self._dibujar_normal(n, s)
                n.set_alpha(int(255 * (1.0 - t)))
                sup.blit(n, (0, 0))

    def _dibujar_visualizador(self, sup):
        h = sup.get_height()
        s = h / ALTO

        sup.blit(self._fondo_gradiente(h), (0, 0))

        if self.vis_modo != "lava":
            self.visualizador.render(sup, ANCHO, h, self._cfg_cristal())
            self._cristal_mate(sup)
            self._dibujar_ui(sup, s)
            return

        # lava (metaballs sombreadas)
        self.lampara.render(sup, ANCHO, h, self._cfg_cristal())

        # burbujas (sprites pequeños y suaves, directamente sobre la lava)
        self.lampara.dibujar_burbujas(sup, ANCHO / GRID_W, h / GRID_H)
        self._cristal_mate(sup)
        self.lampara.dibujar_ojos(sup, ANCHO / GRID_W, h / GRID_H)       # los ojitos, nítidos sobre el cristal

        # vidrio
        vid = self._vidrio(h)                      # solo se mezcla la franja con brillo (no toda la pantalla)
        x0, x1 = self._vidrio_cols
        if x1 > x0:
            sup.blit(vid, (x0, 0), area=pygame.Rect(x0, 0, x1 - x0, h))

        self._dibujar_ui(sup, s)

    def _dibujar_ui(self, sup, s):
        cx = ANCHO / 2
        animando = abs(self.rect.h - self.h_objetivo) > 2
        if self.mini:
            caratula_x = 500
            caratula_y = 1000
            #titulo_y = self.titulo_y_mini
        else:
            caratula_x = self.caratula_x
            caratula_y = self.caratula_y
            #titulo_y = self.titulo_y
        if not self.mini:
            self._dibujar_boton_vis(sup, s)
            self._dibujar_boton_volver(sup, s)
            self._dibujar_boton_mas(sup, s)
        # botón minimizar
        if not self.mini:
            r = self._px(self.r_min, s)
            tam_p = max(2, int((2000 + 40 * self.bass_s) * s))
            self.caratula_y = 1500
            self.caratula_x = 200
            img_min = ui_img("reproductor_minimizar")
            if img_min is not None:
                sup.blit(pygame.transform.smoothscale(img_min, (r.w, r.h)), r.topleft)
            else:
                pygame.draw.rect(sup, (205, 207, 207), r, border_radius=max(2, r.h // 2))
        else:    
            self.caratula_y = 1000


        if self.reproductor is None:
            texto(sup, "Sin audio cargado", cx, sup.get_height() // 2, 40, (255, 80, 80))
            return
        rep = self.reproductor

        # carátula pequeña (opcional: la carátula ahora vive en el botón de volver, arriba a la izquierda)
        car = self.img[self.indice]
        if MOSTRAR_CARATULA_VISUALIZADOR:
            tam_p = max(2, int((200 + 40 * self.bass_s) * s))
            marco_w = int(200 * s)
            marco = pygame.Surface((marco_w, marco_w), pygame.SRCALPHA)
            marco.fill((15, 10, 20, 110))
            sup.blit(marco, (int(self.caratula_x - 100), int(self.caratula_y * s - marco_w / 2)))
            if car is not None:
                sup.blit(pygame.transform.smoothscale(car, (tam_p, tam_p)),
                         (int(caratula_x * s - tam_p / 2), int(self.caratula_y * s - tam_p / 2)))

        # título y artista: mismo estilo que la portada (fuente y tamaños), sin ".mp3"
        titulo, artista = nombre_cancion(self.indice)
        texto_ajustado(sup, titulo, cx, self.v_titulo_y * s, 58 * s, ANCHO - 120, sombra=True)
        if artista:
            texto_ajustado(sup, artista, cx, self.v_artista_y * s, 40 * s, ANCHO - 160, (205, 208, 208), sombra=True)
        pos_ms, dur = rep.posicion, rep.longitud
        tam_t = max(10, int(36 * s))
        texto(sup, f"{pos_ms // 60000:02d}:{(pos_ms // 1000) % 60:02d}",
              cx + (150 - cx) * s, self.v_tiempos_y * s, tam_t, sombra=True)
        texto(sup, f"{dur // 60000:02d}:{(dur // 1000) % 60:02d}",
              cx + (ANCHO - 150 - cx) * s, self.v_tiempos_y * s, tam_t, sombra=True)

        # barra de progreso
        # controles de reproducción
# Solo aparecen cuando la lámpara está abierta
        if not self.mini:

            # barra de progreso
            rb = self._px(self.r_barra, s)
            progreso_px = int(rb.w * (pos_ms / max(1, dur)))

            pygame.draw.rect(
                sup,
                (0x74, 0x74, 0x74),
                rb,
                border_radius=max(2, rb.h // 2)
            )

            if progreso_px > 0:
                pygame.draw.rect(
                    sup,
                    (0xCB, 0xCB, 0xCB),
                    (rb.x, rb.y, progreso_px, rb.h),
                    border_radius=max(2, rb.h // 2)
                )

            pygame.draw.circle(
                sup,
                (255, 255, 255),
                (rb.x + progreso_px, rb.centery),
                max(2, rb.h // 2)
            )

            # botones de reproducción
            self._boton_ui(
                sup, ui_img("reproductor_anterior") or self.prev_img, self.r_prev, s, "Anterior"
            )

            self._boton_ui(
                sup, ui_img("reproductor_siguiente") or self.next_img, self.r_next, s, "Siguiente"
            )

            if rep.esta_reproduciendo():
                self._boton_ui(
                    sup, ui_img("reproductor_pausa") or self.pause_img, self.r_play, s, "Pausa"
                )
            else:
                self._boton_ui(
                    sup, ui_img("reproductor_play") or self.play_img, self.r_play, s, "Play"
                )

        

    # ---------------------------------------------------------- vista normal (portada, sin visualizador)
    def _rects(self):
        """Rects (coords de diseño) de los controles de la vista activa."""
        if self.vista == "normal":
            return {"barra": self.n_barra, "prev": self.n_prev, "play": self.n_play, "next": self.n_next}
        return {"barra": self.r_barra, "prev": self.r_prev, "play": self.r_play, "next": self.r_next}

    def _sup_normal(self, h):
        if self._normal_cache is None or self._normal_h != h:
            self._normal_cache = pygame.Surface((ANCHO, h), pygame.SRCALPHA)
            self._normal_h = h
        return self._normal_cache

    def _fondo_portada(self):
        """Fondo de la vista normal: la portada hecha un lavado de color, oscurecido y con degradado."""
        car = self.img[self.indice] if self.img else None
        clave = id(car)
        if self._fondo_portada_cache is not None and self._fondo_portada_cache[0] == clave:
            return self._fondo_portada_cache[1]
        if car is None:
            fondo = pygame.Surface((ANCHO, ALTO))
            fondo.fill((26, 27, 27))
        else:
            peq = pygame.transform.smoothscale(car, (9, 16))
            fondo = pygame.transform.smoothscale(peq, (ANCHO, ALTO))
            fondo.fill((110, 110, 120), special_flags=pygame.BLEND_RGB_MULT)       # oscurecer
            velo = np.zeros((ALTO, 1, 4), np.uint8)
            velo[:, 0, 3] = np.linspace(40, 215, ALTO).astype(np.uint8)            # más oscuro hacia abajo
            velo = pygame.transform.scale(
                pygame.image.frombuffer(velo.tobytes(), (1, ALTO), "RGBA").convert_alpha(), (ANCHO, ALTO))
            fondo.blit(velo, (0, 0))
        self._fondo_portada_cache = (clave, fondo)
        return fondo

    def _sombra(self, tam):
        """Sombra suave bajo la portada (cuadrado pequeño que se agranda con suavizado)."""
        if tam not in self._sombras:
            if len(self._sombras) > 40:
                self._sombras.clear()
            m = tam // 5
            W = tam + 2 * m
            chica = pygame.Surface((W // 8, W // 8), pygame.SRCALPHA)
            pygame.draw.rect(chica, (0, 0, 0, 150),
                             pygame.Rect(m // 8, m // 8, tam // 8, tam // 8), border_radius=6)
            self._sombras[tam] = pygame.transform.smoothscale(chica, (W, W))
        return self._sombras[tam]

    def _dibujar_normal(self, sup, s):
        """Vista inicial: reproductor normal con la portada al centro y sin visualizador."""
        h = sup.get_height()
        if self.mini:
            sup.fill((0, 0, 0, 0))          # el mini es una tarjeta: alrededor se ve la pestaña
        else:
            sup.blit(self._fondo_portada(), (0, 0), area=pygame.Rect(0, 0, ANCHO, min(h, ALTO)))
        rep = self.reproductor
        car = self.img[self.indice] if self.img else None
        if rep is None:
            texto(sup, "Sin audio cargado", ANCHO // 2, h // 2, 40, (255, 80, 80))
            return
        if self.mini:
            self._dibujar_normal_mini(sup, car, rep)
            return
        cx = ANCHO / 2
        self._dibujar_boton_min(sup, s)
        self._dibujar_boton_iniciar_vis(sup, s)
        self._dibujar_boton_mas(sup, s)

        # portada grande, centrada
        tam = max(16, int(800 * s) // 16 * 16)
        x0, y0 = int(cx - tam / 2), int(190 * s)
        sombra = self._sombra(tam)
        sup.blit(sombra, (x0 - (sombra.get_width() - tam) // 2,
                          y0 - (sombra.get_height() - tam) // 2 + int(24 * s)))
        rad = max(4, int(48 * s))
        p = portada(car, tam, rad)
        if p is not None:
            sup.blit(p, (x0, y0))
        else:
            pygame.draw.rect(sup, GRIS_BOTON_ON, (x0, y0, tam, tam), border_radius=rad)
            texto(sup, "Imagen no encontrada", cx, y0 + tam // 2, max(12, int(40 * s)), (255, 120, 120))

        # título y artista
        titulo, artista = nombre_cancion(self.indice)
        texto_ajustado(sup, titulo, cx, 1145 * s, 58 * s, ANCHO - 120)
        if artista:
            texto_ajustado(sup, artista, cx, 1210 * s, 40 * s, ANCHO - 160, (185, 188, 188))

        # barra de progreso y tiempos
        pos_ms, dur = rep.posicion, rep.longitud
        self._dibujar_barra(sup, self.n_barra, s, pos_ms, dur)
        tam_t = max(10, int(36 * s))
        texto(sup, f"{pos_ms // 60000:02d}:{(pos_ms // 1000) % 60:02d}", cx + (150 - cx) * s, 1350 * s, tam_t)
        texto(sup, f"{dur // 60000:02d}:{(dur // 1000) % 60:02d}", cx + (ANCHO - 150 - cx) * s, 1350 * s, tam_t)

        # controles
        self._boton_ui(sup, ui_img("reproductor_anterior") or self.prev_img, self.n_prev, s, "Anterior")
        self._boton_ui(sup, ui_img("reproductor_siguiente") or self.next_img, self.n_next, s, "Siguiente")
        if rep.esta_reproduciendo():
            self._boton_ui(sup, ui_img("reproductor_pausa") or self.pause_img, self.n_play, s, "Pausa")
        else:
            self._boton_ui(sup, ui_img("reproductor_play") or self.play_img, self.n_play, s, "Play")


    def _dibujar_normal_mini(self, sup, car, rep):
        """Mini reproductor (tarjeta de abajo): portada, título, barra de progreso, play/pausa y siguiente.
        Va encima de la barra de pestañas y juntas forman una sola tarjeta, como en el dibujo."""
        h = sup.get_height()
        radios = dict(border_top_left_radius=44, border_top_right_radius=44)
        pygame.draw.rect(sup, GRIS_TARJETA, (30, 0, 1020, h + 60), **radios)
        if car is not None:                    # fondo: la misma carátula, desenfocada y oscurecida
            ancho_t, alto_t = 1020, h + 60
            clave = (id(car), alto_t)
            if getattr(self, "_mini_fondo_clave", None) != clave:
                peq = pygame.transform.smoothscale(car, (10, 4))           # lavado de color de la carátula
                grande = pygame.transform.smoothscale(peq, (ancho_t, alto_t))
                grande.fill((150, 150, 160), special_flags=pygame.BLEND_RGB_MULT)   # oscurecer: el texto se lee
                tarjeta = pygame.Surface((ancho_t, alto_t), pygame.SRCALPHA)
                tarjeta.blit(grande, (0, 0))
                mascara = pygame.Surface((ancho_t, alto_t), pygame.SRCALPHA)
                pygame.draw.rect(mascara, (255, 255, 255, 255), (0, 0, ancho_t, alto_t),
                                 border_top_left_radius=44, border_top_right_radius=44)
                tarjeta.blit(mascara, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
                self._mini_fondo, self._mini_fondo_clave = tarjeta, clave
            sup.blit(self._mini_fondo, (30, 0))
        p = portada(car, 220, 30)
        if p is not None:
            sup.blit(p, (60, 50))
        else:
            pygame.draw.rect(sup, GRIS_BOTON_ON, (60, 50, 220, 220), border_radius=30)
        titulo, artista = nombre_cancion(self.indice)
        texto_izq(sup, titulo, 310, 100, 46, 440)
        texto_izq(sup, artista, 310, 150, 32, 440, (185, 188, 188))
        self._dibujar_barra(sup, pygame.Rect(310, 215, 440, 12), 1.0, rep.posicion, rep.longitud)
        if rep.esta_reproduciendo():
            self._boton_ui(sup, ui_img("reproductor_pausa") or self.pause_img, self.r_mini_play, 1.0, "Pausa")
        else:
            self._boton_ui(sup, ui_img("reproductor_play") or self.play_img, self.r_mini_play, 1.0, "Play")
        self._boton_ui(sup, ui_img("reproductor_siguiente") or self.next_img, self.r_mini_next, 1.0, "Siguiente")

    def _dibujar_barra(self, sup, rd, s, pos_ms, dur):
        rb = self._px(rd, s)
        progreso_px = int(rb.w * (pos_ms / max(1, dur)))
        pygame.draw.rect(sup, (0x74, 0x74, 0x74), rb, border_radius=max(2, rb.h // 2))
        if progreso_px > 0:
            pygame.draw.rect(sup, (0xCB, 0xCB, 0xCB), (rb.x, rb.y, progreso_px, rb.h),
                             border_radius=max(2, rb.h // 2))
        pygame.draw.circle(sup, (255, 255, 255), (rb.x + progreso_px, rb.centery), max(2, rb.h // 2 + 2))

    def _dibujar_boton_min(self, sup, s):
        r = self._px(self.r_min, s)
        img_min = ui_img("reproductor_minimizar")
        if img_min is not None:
            sup.blit(pygame.transform.smoothscale(img_min, (r.w, r.h)), r.topleft)
            return
        pygame.draw.rect(sup, (205, 207, 207), r, border_radius=max(2, r.h // 2))

    def _color_boton_vis(self):
        """Color del botón del visualizador: el de la carátula, con transición suave entre canciones."""
        objetivo = color_acento(self.img[self.indice] if self.img else None)
        ahora = pygame.time.get_ticks()
        if self._col_btn is None:
            self._col_btn = [float(c) for c in objetivo]
        else:
            k = 1.0 - math.exp(-min(0.1, (ahora - self._col_btn_t) / 1000.0) * 7.0)
            self._col_btn = [c + (o - c) * k for c, o in zip(self._col_btn, objetivo)]
        self._col_btn_t = ahora
        return tuple(int(c) for c in self._col_btn)

    def _dibujar_img_boton_vis(self, sup, img, r):
        """Dibuja la imagen del botón del visualizador, teñida con el color de la carátula."""
        if TINTAR_BOTON_VISUALIZADOR:
            img = tintar(img, self._color_boton_vis())
        clave = (id(img), r.w, r.h)
        if clave not in _cache_icono:
            _cache_icono[clave] = pygame.transform.smoothscale(img, (r.w, r.h))
        sup.blit(_cache_icono[clave], r.topleft)

    def _dibujar_boton_iniciar_vis(self, sup, s):
        """Portada: botón que inicia los visualizadores (icono de ecualizador)."""
        r = self._px(self.r_vis, s)
        img = ui_img("reproductor_iniciar_visualizador")
        if img is not None:
            self._dibujar_img_boton_vis(sup, img, r)
            return
        rad = max(2, int(20 * s))
        col = self._color_boton_vis() if TINTAR_BOTON_VISUALIZADOR else None
        fondo = tuple(int(c * 0.32 + 14) for c in col) if col else GRIS_BOTON
        barras = tuple(int(c * 0.35 + 165) for c in col) if col else (215, 218, 218)
        pygame.draw.rect(sup, fondo, r, border_radius=rad)
        bw, gap = max(2, int(r.w * 0.11)), max(2, int(r.w * 0.07))
        x0 = r.centerx - (4 * bw + 3 * gap) // 2
        base = r.centery + int(r.h * 0.26)
        for k, a in enumerate((0.45, 0.85, 0.6, 1.0)):                # 4 barras de ecualizador
            hh = int(r.h * 0.52 * a)
            pygame.draw.rect(sup, barras, (x0 + k * (bw + gap), base - hh, bw, hh),
                             border_radius=max(1, bw // 2))

    def _dibujar_boton_volver(self, sup, s):
        """Visualizador: botón que vuelve a la portada (icono de imagen)."""
        r = self._px(self.r_volver, s)
        car = self.img[self.indice] if self.img else None
        if car is not None:                    # el botón muestra la carátula de la canción que suena
            lado = max(8, min(r.w, r.h))
            p = portada(car, lado, max(4, int(lado * 0.22)))
            sup.blit(p, p.get_rect(center=r.center))
            return
        img = ui_img("reproductor_volver_portada")
        if img is not None:
            sup.blit(pygame.transform.smoothscale(img, (r.w, r.h)), r.topleft)
            return
        rad = max(2, int(20 * s))
        pygame.draw.rect(sup, GRIS_BOTON, r, border_radius=rad)
        lado = int(r.h * 0.52)
        cuadro = pygame.Rect(0, 0, lado, lado)
        cuadro.center = r.center
        pygame.draw.rect(sup, (215, 218, 218), cuadro, width=max(1, int(3 * s)),
                         border_radius=max(2, int(8 * s)))
        pygame.draw.circle(sup, (215, 218, 218), (cuadro.centerx, cuadro.centery), max(2, lado // 6))

    def _dibujar_boton_mas(self, sup, s):
        """Botón + : guarda la canción en una playlist. Se vuelve ✓ si ya está en alguna."""
        r = self._px(self.r_mas, s)
        guardada = self.datos.en_alguna(self.indice)
        if ui_img("reproductor_mas") is not None:
            boton_ui(sup, r, "reproductor_mas", "", guardada)
            return
        pygame.draw.rect(sup, GRIS_BOTON_ON if guardada else GRIS_BOTON, r, border_radius=max(2, int(20 * s)))
        cx, cy = r.center
        a = max(3, int(r.h * 0.22))
        gr = max(2, int(6 * s))
        col = (255, 255, 255) if guardada else (215, 218, 218)
        if guardada:
            pygame.draw.lines(sup, col, False, [(cx - a, cy), (cx - a // 3, cy + a * 2 // 3), (cx + a, cy - a * 2 // 3)], gr)
        else:
            pygame.draw.line(sup, col, (cx - a, cy), (cx + a, cy), gr)
            pygame.draw.line(sup, col, (cx, cy - a), (cx, cy + a), gr)

    def _dibujar_boton_vis(self, sup, s):
        """Botón del reproductor que abre los ajustes del visualizador."""
        r = self._px(self.r_vis, s)
        img = (ui_img("reproductor_iniciar_visualizador") or ui_img("reproductor_visualizador")
               or self.vis_btn_img)
        if img is not None:
            if img is not self.vis_btn_img:                    # la imagen de ui/ se tiñe igual que en la portada
                self._dibujar_img_boton_vis(sup, img, r)
            else:
                sup.blit(pygame.transform.smoothscale(img, (r.w, r.h)), r.topleft)
            return
        rad = max(2, int(20 * s))
        pygame.draw.rect(sup, GRIS_BOTON, r, border_radius=rad)
        for k, frac in enumerate((0.30, 0.70, 0.45)):          # 3 deslizadores
            y = r.y + int(r.h * (0.25 + 0.25 * k))
            x1, x2 = r.x + int(r.w * 0.20), r.right - int(r.w * 0.20)
            pygame.draw.line(sup, (205, 208, 208), (x1, y), (x2, y), max(1, int(3 * s)))
            pygame.draw.circle(sup, (255, 255, 255), (x1 + int((x2 - x1) * frac), y),
                               max(2, int(8 * s)))

    def _boton_ui(self, sup, imagen, r_d, s, etiqueta):
        r = self._px(r_d, s)
        if imagen is not None:
            sup.blit(pygame.transform.smoothscale(imagen, (r.w, r.h)), r.topleft)
        else:
            pygame.draw.rect(sup, (50, 50, 50), r, border_radius=max(2, int(r.w * 0.2)))
            texto(sup, etiqueta, r.centerx, r.centery, max(10, int(34 * s)))
        nombre = {"Anterior": "reproductor_anterior", "Siguiente": "reproductor_siguiente",
                  "Pausa": "reproductor_pausa", "Play": "reproductor_play"}.get(etiqueta)
        if nombre:
            etiqueta_ui(sup, r, nombre, imagen is not None)

    def _rotular_botones(self, sup, s):
        """Mapa de imágenes (tecla i) para los botones del reproductor que no pasan por boton_ui."""
        if not MOSTRAR_UI or self.mini:
            return

        def hay(nombre):
            return ui_img(nombre) is not None
        etiqueta_ui(sup, self._px(self.r_min, s), "reproductor_minimizar", hay("reproductor_minimizar"))
        etiqueta_ui(sup, self._px(self.r_mas, s), "reproductor_mas", hay("reproductor_mas"))
        etiqueta_ui(sup, self._px(self.r_vis, s), "reproductor_iniciar_visualizador",
                    hay("reproductor_iniciar_visualizador") or hay("reproductor_visualizador")
                    or self.vis_btn_img is not None)
        if self.vista != "normal":
            etiqueta_ui(sup, self._px(self.r_volver, s), "reproductor_volver_portada",
                        hay("reproductor_volver_portada"))

    # -------- fondos cacheados por altura --------
    def _fondo_gradiente(self, h):
        if self._fondo_h == h and self._fondo_cache is not None:
            return self._fondo_cache
        arriba = np.asarray(self.lampara.col_fria * 0.22, np.float32)
        abajo = np.array((4, 2, 8), np.float32)
        t = np.linspace(0, 1, h, dtype=np.float32)[:, None]
        grad = arriba[None, :] * (1.0 - t) + abajo[None, :] * t
        col = np.ascontiguousarray(grad.astype(np.uint8))
        sup = pygame.transform.scale(
            pygame.image.frombuffer(col.tobytes(), (1, h), "RGB").convert(), (ANCHO, h))
        self._fondo_cache, self._fondo_h = sup, h
        return sup

    def _vidrio(self, h):
        if self._vidrio_h == h and self._vidrio_cache is not None:
            return self._vidrio_cache
        x = np.arange(ANCHO, dtype=np.float32)
        s1 = np.exp(-(((x - 0.30 * ANCHO) / (0.045 * ANCHO)) ** 2)) * 26
        s2 = np.exp(-(((x - 0.72 * ANCHO) / (0.030 * ANCHO)) ** 2)) * 12
        alfa = np.clip(s1 + s2, 0, 40).astype(np.uint8)
        rgba = np.zeros((h, ANCHO, 4), np.uint8)
        rgba[..., 0] = 255
        rgba[..., 1] = 255
        rgba[..., 2] = 255
        rgba[..., 3] = alfa[None, :]
        sup = pygame.image.frombuffer(rgba.tobytes(), (ANCHO, h), "RGBA").convert_alpha()
        cols = np.nonzero(alfa)[0]
        self._vidrio_cols = (int(cols[0]), int(cols[-1]) + 1) if len(cols) else (0, 0)
        self._vidrio_cache, self._vidrio_h = sup, h
        return sup

    def _capa(self, h):
        if self._capa_h == h and self._capa_cache is not None:
            return self._capa_cache
        self._capa_cache = pygame.Surface((ANCHO, h), pygame.SRCALPHA)
        self._capa_h = h
        return self._capa_cache


# ------------------------------------------------------------------ ventana principal
class AltavozWidget:
    """Módulo de altavoz del Inicio: un fondo estático (textura de madera) y un cono que late con la música.
    Imágenes: ui/altavoz_fondo.png (madera) y ui/altavoz_cono.png (cono, PNG cuadrado y centrado).
    Sin ellas se dibujan una madera y un cono de ejemplo. El cono es un resorte amortiguado: los graves lo
    empujan y vuelve con un pequeño rebote, como el de un altavoz de verdad."""

    def __init__(self, rect):
        self.rect = rect
        self.x = 0.0                 # excursión del cono (0 = reposo, ~1 = máxima)
        self.v = 0.0
        self.t = 0.0
        self.ultimo = -1.0
        self.hi = 0.0                # cima y valle recientes de los graves (para medir el contraste)
        self.lo = 1.0
        self.ondas = []              # edad (s) de las ondas que salen en cada golpe de bajo
        self._madera = None
        self._conos = {}
        self._esc_cono = {}

    def update(self, dt, bass, mid, high):
        self.t += dt
        # El cono responde al GOLPE, no al volumen: con música densa los graves relativos casi siempre
        # están altos (0.7-1.0) y el cono quedaría pegado arriba. Por eso se mide cuánto se despega el
        # bajo de su valle reciente, frente al rango cima-valle (se autoajusta a cada canción).
        self.hi = max(bass, self.hi - 0.6 * dt)
        self.lo = min(bass, self.lo + 0.6 * dt)
        rango = max(0.15, self.hi - self.lo)
        nivel = max(0.0, min(1.0, (bass - self.lo) / rango))
        objetivo = min(1.0, 0.25 * bass + 0.70 * nivel + 0.15 * mid * nivel)
        acc = (objetivo - self.x) * 520.0 - self.v * 24.0           # resorte con amortiguación
        self.v += acc * dt
        self.x = max(0.0, min(1.3, self.x + self.v * dt))
        if bass > 0.55 and self.t - self.ultimo > 0.20:
            self.ultimo = self.t
            self.ondas.append(0.0)
        self.ondas = [a + dt for a in self.ondas if a + dt < 0.45]

    # ---- fondo de ejemplo: madera con vetas (se genera una vez)
    def _fondo_madera(self):
        if self._madera is None:
            w, h = self.rect.size
            rng = np.random.default_rng(11)
            veta = np.convolve(rng.normal(0, 1, w), np.ones(5) / 5, mode="same").astype(np.float32) * 2.2
            ondas = np.sin(np.arange(h, dtype=np.float32)[:, None] * 0.015 + veta[None, :] * 1.5) * 6
            base = np.array((138, 90, 52), np.float32)
            img = (base[None, None, :] + veta[None, :, None] * 9 + ondas[..., None]
                   - (np.arange(h, dtype=np.float32)[:, None, None] / h) * 22)
            rgb = np.ascontiguousarray(np.clip(img, 0, 255).astype(np.uint8))
            s = pygame.image.frombuffer(rgb.tobytes(), (w, h), "RGB").convert_alpha()
            mascara = pygame.Surface((w, h), pygame.SRCALPHA)
            pygame.draw.rect(mascara, (255, 255, 255, 255), mascara.get_rect(), border_radius=44)
            s.blit(mascara, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
            pygame.draw.rect(s, (58, 36, 20), s.get_rect(), width=6, border_radius=44)
            self._madera = s
        return self._madera

    # ---- cono de ejemplo (a 2x y reducido, para que quede suave)
    def _cono_ejemplo(self, d):
        d = max(8, d // 4 * 4)
        if d not in self._conos:
            if len(self._conos) > 30:
                self._conos.clear()
            R = d                                            # trabajo a 2x: radio = d
            s = pygame.Surface((2 * d, 2 * d), pygame.SRCALPHA)
            c = (d, d)
            pygame.draw.circle(s, (20, 20, 24), c, int(R * 1.00))
            pygame.draw.circle(s, (48, 48, 54), c, int(R * 0.93))
            pygame.draw.circle(s, (28, 28, 32), c, int(R * 0.80))
            for i in range(16):                              # el cono: anillos de más oscuro a más claro
                t = i / 15.0
                col = (int(54 + 62 * t), int(54 + 62 * t), int(62 + 66 * t))
                pygame.draw.circle(s, col, c, int(R * (0.76 - 0.46 * t)))
            pygame.draw.circle(s, (78, 78, 90), c, int(R * 0.26))            # casquete
            pygame.draw.circle(s, (150, 150, 168), (c[0] - int(R * 0.07), c[1] - int(R * 0.08)), int(R * 0.09))
            self._conos[d] = pygame.transform.smoothscale(s, (d, d))
        return self._conos[d]

    def _cono_img(self, cono, d):
        """Tu cono escalado a d x d (en pasos de 4 px, con caché: no se reescala en cada cuadro)."""
        d = max(8, d // 4 * 4)
        clave = (id(cono), d)
        if clave not in self._esc_cono:
            if len(self._esc_cono) > 40:
                self._esc_cono.clear()
            k = min(d / cono.get_width(), d / cono.get_height())
            self._esc_cono[clave] = pygame.transform.smoothscale(
                cono, (max(1, int(cono.get_width() * k)), max(1, int(cono.get_height() * k))))
        return self._esc_cono[clave]

    def dibujar(self, dest):
        r = self.rect
        fondo = ui_img("altavoz_fondo")
        if fondo is not None:
            boton_ui(dest, r, "altavoz_fondo", "")
        else:
            dest.blit(self._fondo_madera(), r.topleft)
            etiqueta_ui(dest, r, "altavoz_fondo", False)
        cx, cy = r.center
        D = int(min(r.w, r.h) * 0.74)                        # diámetro del cono en reposo
        d = int(D * (1.0 + 0.085 * self.x))                  # al empujar, el cono "sale"
        dest.set_clip(r)
        for edad in self.ondas:                              # ondas que se expanden en cada golpe
            k = edad / 0.45
            rad = int(D / 2 + 90 * k)
            alfa = int(120 * (1.0 - k))
            onda = pygame.Surface((2 * rad + 8, 2 * rad + 8), pygame.SRCALPHA)
            pygame.draw.circle(onda, (255, 235, 205, alfa), (rad + 4, rad + 4), rad, 4)
            dest.blit(onda, (cx - rad - 4, cy - rad - 4))
        dest.set_clip(None)
        cono = ui_img("altavoz_cono")
        if cono is not None:
            esc = self._cono_img(cono, d)
        else:
            esc = self._cono_ejemplo(d)
        brillo = int(34 * min(1.0, self.x))                  # la luz resbala más al salir el cono
        if brillo:
            esc = esc.copy()
            esc.fill((brillo, brillo, brillo), special_flags=pygame.BLEND_RGB_ADD)
        dest.blit(esc, esc.get_rect(center=(cx, cy)))
        etiqueta_ui(dest, pygame.Rect(cx - D // 2, cy - D // 2, D, D), "altavoz_cono", cono is not None)


class PaginaInicio:
    """Pestaña Inicio, según el dibujo: playlists a la izquierda, módulo de altavoz a la derecha, título
    EMONIC arriba y, debajo, las canciones recientes. Si hay más recientes de las que caben, la rueda
    del ratón desplaza toda la página. Ocupa y < ALTO - ALT_MINI - NAV_H."""
    R_PLAY = [pygame.Rect(60, 336 + i * 192, 490, 160) for i in range(3)]
    R_VER_TODAS = pygame.Rect(720, 236, 300, 70)
    R_ALTAVOZ = pygame.Rect(590, 330, 430, 470)
    Y_RECIENTES = 1000
    Y_FILAS, PASO_FILA, ALTO_FILA = 1050, 112, 100
    Y_VISTA = ALTO - ALT_MINI - NAV_H           # hasta aquí se ve la página (debajo está el mini)

    def __init__(self, lamp):
        self.lamp = lamp
        self.altavoz = AltavozWidget(self.R_ALTAVOZ)
        self.scroll = 0.0
        self._lienzo = None

    def _slots(self):
        """Botones de la izquierda: tu biblioteca, tus 2 primeras playlists y, si falta sitio, 'Nueva'."""
        d = self.lamp.datos
        s = [("Mi biblioteca", f"{len(CANCIONES)} canciones", ("bib", None))]
        for k, l in enumerate(d.listas[:2]):
            s.append((l["nombre"], f"{len(d.indices(k))} canciones", ("lista", k)))
        if len(s) < 3:
            s.append(("+  Nueva playlist", "Guarda tus canciones", ("nueva", None)))
        return s

    def _alto_contenido(self):
        n = len(self.lamp.recientes)
        return max(self.Y_VISTA, self.Y_FILAS + n * self.PASO_FILA + 30)

    def _max_scroll(self):
        return max(0.0, self._alto_contenido() - self.Y_VISTA)

    def update(self, dt):
        lamp = self.lamp
        self.altavoz.update(dt, lamp.bass_s, lamp.mid_s, lamp.high_s)
        self.scroll = max(0.0, min(self.scroll, self._max_scroll()))

    def rueda(self, pos, dy):
        self.scroll = max(0.0, min(self.scroll - dy * PASO_RUEDA, self._max_scroll()))
        return True

    def _fila(self, i):
        return pygame.Rect(60, self.Y_FILAS + i * self.PASO_FILA, 960, self.ALTO_FILA)

    def evento(self, e):
        if e.type == pygame.MOUSEBUTTONDOWN:
            pos = (e.pos[0], e.pos[1] + self.scroll)           # a coordenadas del contenido
            pr = self.lamp.principal
            if self.R_VER_TODAS.collidepoint(pos):
                pr.abrir_playlists()
                return True
            for r, (_n, _c, accion) in zip(self.R_PLAY, self._slots()):
                if r.collidepoint(pos):
                    if accion[0] == "bib":
                        pr.abrir_lista(None)                       # biblioteca completa
                    elif accion[0] == "lista":
                        pr.abrir_lista(accion[1])                  # tu playlist, tal cual la creaste
                    else:
                        self.lamp.guardar.abrir(None)              # crear una playlist nueva
                    return True
            for i in range(len(self.lamp.recientes)):
                if self._fila(i).collidepoint(pos):
                    self.lamp.reproducir_indice(self.lamp.recientes[i])
                    return True
        return False

    def _contenido(self, dest):
        texto(dest, "EMONIC", ANCHO // 2, 100, 110)
        texto_izq(dest, "Tus playlists", 60, 270, 46, color=(185, 188, 188))
        ver = fuente_t(40).render("Ver todas  ›", True, (185, 188, 188))
        dest.blit(ver, ver.get_rect(midright=(self.R_VER_TODAS.right, 270)))
        for i, (r, (nombre, detalle, _acc)) in enumerate(zip(self.R_PLAY, self._slots())):
            clave = f"inicio_playlist_{i + 1}"
            if ui_img(clave) is not None:
                boton_ui(dest, r, clave, nombre)
                continue
            boton(dest, r, "", False, radio=36)
            texto_izq(dest, nombre, r.x + 36, r.centery - 20, 56, r.w - 72)
            texto_izq(dest, detalle, r.x + 36, r.centery + 34, 34, r.w - 72, (160, 163, 163))
            etiqueta_ui(dest, r, clave, False)
        self.altavoz.dibujar(dest)

        texto_izq(dest, "Recientes", 60, self.Y_RECIENTES, 56, color=(185, 188, 188))
        for i, idx in enumerate(self.lamp.recientes):
            fila_cancion(dest, self._fila(i), self.lamp, idx)

    def dibujar(self, dest):
        if self._max_scroll() <= 0:
            self.scroll = 0.0
            self._contenido(dest)
            return
        alto = int(self._alto_contenido())
        if self._lienzo is None or self._lienzo.get_height() != alto:
            self._lienzo = pygame.Surface((ANCHO, alto))
        self._lienzo.fill(GRIS_FONDO)
        self._contenido(self._lienzo)
        sc = int(self.scroll)
        dest.blit(self._lienzo, (0, 0), area=pygame.Rect(0, sc, ANCHO, self.Y_VISTA))
        frac = self.scroll / self._max_scroll()                  # indicador de desplazamiento
        alto_b = max(60, int(self.Y_VISTA * self.Y_VISTA / alto))
        pygame.draw.rect(dest, (115, 118, 118),
                         (ANCHO - 14, int(frac * (self.Y_VISTA - alto_b)), 6, alto_b), border_radius=3)


def dibujar_portada(dest, img, x, y, tam, etiqueta="", radio=20):
    p = portada(img, tam, radio)
    if p is not None:
        dest.blit(p, (x, y))
    else:                                  # sin imagen: recuadro con la inicial
        r = pygame.Rect(x, y, tam, tam)
        pygame.draw.rect(dest, GRIS_BOTON_ON, r, border_radius=radio)
        texto(dest, etiqueta[:1].upper(), r.centerx, r.centery, max(12, tam // 3))


def fila_cancion(dest, r, lamp, idx, reservar=0):
    """Fila de canción (portada, título, artista); resaltada si es la que suena."""
    boton(dest, r, "", activo=(idx == lamp.indice))
    titulo, artista = nombre_cancion(idx)
    dibujar_portada(dest, lamp.img[idx], r.x + 10, r.y + 10, r.h - 20, titulo, radio=14)
    x_t = r.x + r.h + 10
    texto_izq(dest, titulo, x_t, r.y + r.h * 0.37, 42, r.w - r.h - 40 - reservar)
    texto_izq(dest, artista, x_t, r.y + r.h * 0.72, 32, r.w - r.h - 40 - reservar, (160, 163, 163))


def _norm(s):
    """Minúsculas y sin acentos, para comparar al buscar."""
    return unicodedata.normalize("NFD", s).encode("ascii", "ignore").decode("ascii").lower()


def abrir_url(url):
    """Abre una dirección en el navegador del sistema."""
    try:
        if ES_ANDROID:
            from jnius import autoclass        # pyjnius (viene con python-for-android)
            Intent = autoclass("android.content.Intent")
            Uri = autoclass("android.net.Uri")
            actividad = autoclass("org.kivy.android.PythonActivity").mActivity
            actividad.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            return
        webbrowser.open(url)
    except Exception as ex:
        print(f"⚠ No se pudo abrir {url}: {ex}")


PASO_RUEDA = 110                  # píxeles de diseño que avanza cada "clic" de la rueda


def flecha_atras(dest, r):
    cx, cy = r.centerx, r.centery
    pygame.draw.lines(dest, (215, 218, 218), False,
                      [(cx + 8, cy - 18), (cx - 10, cy), (cx + 8, cy + 18)], 6)


class PaginaBuscar:
    """Pestaña Buscar: busca en tu biblioteca por título o artista (sin importar mayúsculas ni acentos).
    Con el campo vacío lista toda la biblioteca. Tocar una canción la reproduce, y la cola pasa a ser
    el resultado (así Anterior/Siguiente recorren lo buscado)."""

    CAMPO = pygame.Rect(60, 190, 960, 110)
    LIMPIAR = pygame.Rect(910, 200, 90, 90)
    LISTA = pygame.Rect(0, 380, ANCHO, 850)
    PASO, ALTO_FILA = 124, 110

    def __init__(self, lamp):
        self.lamp = lamp
        self.texto = ""
        self.foco = False
        self.t = 0.0
        self.scroll = 0.0
        self.arrastre = None                  # [y_inicial, scroll_inicial, se_movió]
        self._res = []
        self._actualizar()

    def _actualizar(self):
        palabras = _norm(self.texto).split()
        self._res = [i for i in range(len(CANCIONES))
                     if all(p in _norm(" ".join(nombre_cancion(i))) for p in palabras)]
        self.scroll = 0.0

    def _max_scroll(self):
        return max(0.0, len(self._res) * self.PASO - self.LISTA.h)

    def _fila_en(self, pos):
        if not self.LISTA.collidepoint(pos):
            return None
        y = pos[1] - self.LISTA.y + self.scroll
        k = int(y // self.PASO)
        if 0 <= k < len(self._res) and y - k * self.PASO <= self.ALTO_FILA:
            return k
        return None

    def _dar_foco(self):
        self.foco = True
        try:
            pygame.key.start_text_input()
        except Exception:
            pass

    def update(self, dt):
        self.t += dt

    def teclado(self, e):
        """Devuelve True si se quedó con la tecla (mientras escribes no se disparan los atajos)."""
        if not self.foco:
            return False
        if e.type == pygame.TEXTINPUT:
            if len(self.texto) < 40:
                self.texto += e.text
                self._actualizar()
            return True
        if e.type == pygame.KEYDOWN:
            if e.key == pygame.K_BACKSPACE:
                self.texto = self.texto[:-1]
                self._actualizar()
            elif e.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                self.foco = False
            elif e.key == pygame.K_ESCAPE:
                if self.texto:
                    self.texto = ""
                    self._actualizar()
                else:
                    self.foco = False
            return True
        return False

    def evento(self, e):
        if e.type == pygame.MOUSEBUTTONDOWN:
            if self.CAMPO.collidepoint(e.pos):
                if self.texto and self.LIMPIAR.collidepoint(e.pos):
                    self.texto = ""
                    self._actualizar()
                self._dar_foco()
                return True
            self.foco = False
            if self.LISTA.collidepoint(e.pos):
                self.arrastre = [e.pos[1], self.scroll, False]
                return True
            return False
        if e.type == pygame.MOUSEMOTION and self.arrastre is not None:
            if not e.buttons[0]:
                self.arrastre = None
                return False
            dy = e.pos[1] - self.arrastre[0]
            if abs(dy) > 14:
                self.arrastre[2] = True
            if self.arrastre[2]:
                self.scroll = max(0.0, min(self.arrastre[1] - dy, self._max_scroll()))
            return False
        if e.type == pygame.MOUSEBUTTONUP and self.arrastre is not None:
            movio = self.arrastre[2]
            self.arrastre = None
            if not movio:                      # fue un toque, no un arrastre
                k = self._fila_en(e.pos)
                if k is not None:
                    self.lamp.reproducir_cola(self._res, empezar=k)
                    return True
        return False

    def rueda(self, pos, dy):
        self.scroll = max(0.0, min(self.scroll - dy * PASO_RUEDA, self._max_scroll()))
        return True

    def dibujar(self, dest):
        texto_izq(dest, "Buscar", 60, 100, 90)
        pygame.draw.rect(dest, GRIS_BOTON_ON if self.foco else GRIS_BOTON, self.CAMPO, border_radius=30)
        cursor = "|" if self.foco and int(self.t * 2) % 2 == 0 else ""
        if self.texto:
            texto_izq(dest, self.texto + cursor, self.CAMPO.x + 36, self.CAMPO.centery, 48, self.CAMPO.w - 190)
            boton_ui(dest, self.LIMPIAR, "buscar_limpiar", "X", False, 40)
        else:
            texto_izq(dest, cursor + "Buscar canción o artista", self.CAMPO.x + 36, self.CAMPO.centery,
                      44, self.CAMPO.w - 80, (125, 128, 128))

        n = len(self._res)
        if self.texto:
            resumen = f"{n} resultado{'s' if n != 1 else ''}"
        else:
            resumen = f"{n} canciones en tu biblioteca"
        texto_izq(dest, resumen, 60, 345, 34, color=(150, 153, 153))

        dest.set_clip(self.LISTA)
        if not self._res:
            texto(dest, f"Sin resultados para «{self.texto}»", ANCHO // 2, 620, 42, (150, 153, 153))
        for k, idx in enumerate(self._res):
            y = self.LISTA.y + k * self.PASO - self.scroll
            if y > self.LISTA.bottom or y + self.ALTO_FILA < self.LISTA.y:
                continue
            fila_cancion(dest, pygame.Rect(60, int(y), 960, self.ALTO_FILA), self.lamp, idx)
        dest.set_clip(None)
        if self._max_scroll() > 0:                    # indicador de desplazamiento
            frac = self.scroll / self._max_scroll()
            alto_b = max(60, int(self.LISTA.h * self.LISTA.h / (len(self._res) * self.PASO)))
            pygame.draw.rect(dest, (115, 118, 118),
                             (ANCHO - 14, int(self.LISTA.y + frac * (self.LISTA.h - alto_b)), 6, alto_b),
                             border_radius=3)


class PaginaDescargas:
    """Pestaña Descargas: una tarjeta por cada fuente de SITIOS_DESCARGA. Tocar una abre su página."""

    def __init__(self, app):
        self.app = app
        self.tarjetas = [pygame.Rect(60, 270 + i * 180, 960, 150) for i in range(len(SITIOS_DESCARGA))]

    def update(self, dt):
        pass

    def evento(self, e):
        if e.type == pygame.MOUSEBUTTONDOWN:
            for i, r in enumerate(self.tarjetas):
                if r.collidepoint(e.pos):
                    if SITIOS_ABRIR_DIRECTO:
                        abrir_url(SITIOS_DESCARGA[i][1])
                    else:
                        self.app.abrir_sitio(i)
                    return True
        return False

    def dibujar(self, dest):
        texto_izq(dest, "Descargas", 60, 100, 90)
        texto_izq(dest, "Elige una página para conseguir música", 60, 200, 38, color=(150, 153, 153))
        for i, (nombre, url, desc) in enumerate(SITIOS_DESCARGA):
            r, clave = self.tarjetas[i], f"sitio_{i + 1}"
            if ui_img(clave) is not None:
                boton_ui(dest, r, clave, nombre)
                continue
            boton(dest, r, "", False)
            texto_izq(dest, nombre, r.x + 40, r.y + 52, 52, r.w - 160)
            texto_izq(dest, desc, r.x + 40, r.y + 106, 32, r.w - 160, (160, 163, 163))
            cx, cy = r.right - 60, r.centery
            pygame.draw.lines(dest, (205, 208, 208), False,
                              [(cx - 12, cy - 22), (cx + 10, cy), (cx - 12, cy + 22)], 6)
            etiqueta_ui(dest, r, clave, False)


class PaginaSitio:
    """Ventana de una fuente de descargas: su nombre, descripción y el botón que abre la página."""
    R_VOLVER = pygame.Rect(60, 70, 120, 74)
    R_ABRIR = pygame.Rect(60, 560, 960, 110)

    def __init__(self, app):
        self.app = app
        self.i = 0
        self.aviso = 0.0

    def abrir(self, i):
        self.i = i
        self.aviso = 0.0

    def update(self, dt):
        self.aviso = max(0.0, self.aviso - dt)

    def evento(self, e):
        if e.type == pygame.MOUSEBUTTONDOWN:
            if self.R_VOLVER.collidepoint(e.pos):
                self.app.atras()
                return True
            if self.R_ABRIR.collidepoint(e.pos):
                abrir_url(SITIOS_DESCARGA[self.i][1])
                self.aviso = 2.0
                return True
        return False

    def dibujar(self, dest):
        nombre, url, desc = SITIOS_DESCARGA[self.i]
        if ui_img("pagina_volver") is not None:
            boton_ui(dest, self.R_VOLVER, "pagina_volver", "")
        else:
            boton(dest, self.R_VOLVER, "", False)
            flecha_atras(dest, self.R_VOLVER)
            etiqueta_ui(dest, self.R_VOLVER, "pagina_volver", False)
        texto_ajustado(dest, nombre, ANCHO // 2, 280, 86, ANCHO - 120)
        texto_ajustado(dest, desc, ANCHO // 2, 380, 40, ANCHO - 120, (185, 188, 188))
        texto_ajustado(dest, url, ANCHO // 2, 450, 34, ANCHO - 120, (125, 128, 128))
        boton_ui(dest, self.R_ABRIR, "sitio_abrir", "Abrir en el navegador", True, 46, estado_texto=True)
        if self.aviso > 0:
            texto(dest, "Abriendo en tu navegador...", ANCHO // 2, 730, 38, (185, 188, 188))
        else:
            texto(dest, "La página se abre en tu navegador", ANCHO // 2, 730, 34, (125, 128, 128))


def boton_volver(dest, r):
    """Flecha para volver (usa ui/pagina_volver.png si existe)."""
    if ui_img("pagina_volver") is not None:
        boton_ui(dest, r, "pagina_volver", "")
    else:
        boton(dest, r, "", False)
        flecha_atras(dest, r)
        etiqueta_ui(dest, r, "pagina_volver", False)


class _ListaDesplazable:
    """Lógica común de las páginas con una lista que se desplaza (rueda, arrastre y toque)."""
    LISTA = pygame.Rect(0, 0, ANCHO, 100)
    PASO, ALTO_FILA = 124, 110

    def _ini_scroll(self):
        self.scroll = 0.0
        self.arrastre = None

    def _n(self):
        return 0

    def _max_scroll(self):
        return max(0.0, self._n() * self.PASO - self.LISTA.h)

    def rueda(self, pos, dy):
        self.scroll = max(0.0, min(self.scroll - dy * PASO_RUEDA, self._max_scroll()))
        return True

    def _fila_en(self, pos):
        if not self.LISTA.collidepoint(pos):
            return None
        y = pos[1] - self.LISTA.y + self.scroll
        k = int(y // self.PASO)
        if 0 <= k < self._n() and y - k * self.PASO <= self.ALTO_FILA:
            return k
        return None

    def _desplazar(self, e):
        """Gestiona el arrastre. Devuelve la posición si el gesto fue un toque (no un arrastre)."""
        if e.type == pygame.MOUSEBUTTONDOWN and self.LISTA.collidepoint(e.pos):
            self.arrastre = [e.pos[1], self.scroll, False]
        elif e.type == pygame.MOUSEMOTION and self.arrastre is not None:
            if not e.buttons[0]:
                self.arrastre = None
                return None
            dy = e.pos[1] - self.arrastre[0]
            if abs(dy) > 14:
                self.arrastre[2] = True
            if self.arrastre[2]:
                self.scroll = max(0.0, min(self.arrastre[1] - dy, self._max_scroll()))
        elif e.type == pygame.MOUSEBUTTONUP and self.arrastre is not None:
            movio = self.arrastre[2]
            self.arrastre = None
            if not movio:
                return e.pos
        return None

    def _barra_scroll(self, dest):
        if self._max_scroll() > 0:
            frac = self.scroll / self._max_scroll()
            alto_b = max(60, int(self.LISTA.h * self.LISTA.h / (self._n() * self.PASO)))
            pygame.draw.rect(dest, (115, 118, 118),
                             (ANCHO - 14, int(self.LISTA.y + frac * (self.LISTA.h - alto_b)), 6, alto_b),
                             border_radius=3)


class PaginaLista(_ListaDesplazable):
    """Ventana de UNA lista de canciones: tu biblioteca completa (k=None) o una de tus playlists.
    Muestra la lista tal cual; tocar una canción la reproduce (la cola pasa a ser esta lista).
    En la biblioteca, el + de cada fila la guarda en una playlist; en una playlist, la × la quita."""
    R_VOLVER = pygame.Rect(60, 70, 120, 74)
    R_ELIMINAR = pygame.Rect(790, 70, 230, 74)
    R_REPRODUCIR = pygame.Rect(60, 420, 470, 100)
    R_ALEATORIO = pygame.Rect(550, 420, 470, 100)
    LISTA = pygame.Rect(0, 560, ANCHO, ALTO - ALT_MINI - NAV_H - 560)

    def __init__(self, app):
        self.app = app
        self.lamp = app.lamp
        self.k = None
        self.confirmar = 0.0
        self._ini_scroll()

    def abrir(self, k=None):
        self.k = k
        self.confirmar = 0.0
        self._ini_scroll()

    def _idxs(self):
        d = self.lamp.datos
        if self.k is None:
            return list(range(len(CANCIONES)))
        return d.indices(self.k) if self.k < len(d.listas) else []

    def _n(self):
        return len(self._idxs())

    def _acc(self, fila):
        return pygame.Rect(fila.right - 98, fila.y + 14, 82, 82)

    def update(self, dt):
        self.confirmar = max(0.0, self.confirmar - dt)
        if self.k is not None and self.k >= len(self.lamp.datos.listas):
            self.app.atras()                                   # la playlist ya no existe
        self.scroll = max(0.0, min(self.scroll, self._max_scroll()))

    def evento(self, e):
        d = self.lamp.datos
        idxs = self._idxs()
        if e.type == pygame.MOUSEBUTTONDOWN:
            if self.R_VOLVER.collidepoint(e.pos):
                self.app.atras()
                return True
            if self.k is not None and self.R_ELIMINAR.collidepoint(e.pos):
                if self.confirmar > 0:
                    d.eliminar(self.k)
                    self.app.atras()
                else:
                    self.confirmar = 3.0                      # pide confirmar con un segundo toque
                return True
            if self.R_REPRODUCIR.collidepoint(e.pos) and idxs:
                self.lamp.reproducir_cola(idxs)
                return True
            if self.R_ALEATORIO.collidepoint(e.pos) and idxs:
                mezcla = list(idxs)
                random.shuffle(mezcla)
                self.lamp.reproducir_cola(mezcla)
                return True
        pos = self._desplazar(e)
        if pos is not None:
            k = self._fila_en(pos)
            if k is not None:
                fila = self._rect_fila(k)
                if self._acc(fila).collidepoint(pos):
                    if self.k is None:
                        self.lamp.guardar.abrir(idxs[k])      # + : guardar esta canción en una playlist
                    else:
                        d.quitar(self.k, idxs[k])             # × : quitar de la playlist
                else:
                    self.lamp.reproducir_cola(idxs, empezar=k)
            return True
        return e.type == pygame.MOUSEBUTTONDOWN and self.LISTA.collidepoint(e.pos)

    def _rect_fila(self, k):
        return pygame.Rect(60, int(self.LISTA.y + k * self.PASO - self.scroll), 960, self.ALTO_FILA)

    def dibujar(self, dest):
        d = self.lamp.datos
        idxs = self._idxs()
        boton_volver(dest, self.R_VOLVER)
        if self.k is None:
            nombre = "Mi biblioteca"
        else:
            nombre = d.listas[self.k]["nombre"] if self.k < len(d.listas) else ""
            boton(dest, self.R_ELIMINAR, "¿Seguro?" if self.confirmar > 0 else "Eliminar", self.confirmar > 0, 34)
        texto_ajustado(dest, nombre, ANCHO // 2, 280, 86, ANCHO - 120)
        n = len(idxs)
        texto(dest, f"{n} canci{'ones' if n != 1 else 'ón'}", ANCHO // 2, 360, 38, (185, 188, 188))
        boton(dest, self.R_REPRODUCIR, "Reproducir", True, 44)
        boton(dest, self.R_ALEATORIO, "Aleatorio", False, 44)
        dest.set_clip(self.LISTA)
        if not idxs:
            texto(dest, "Esta playlist está vacía", ANCHO // 2, 760, 46, (150, 153, 153))
            texto(dest, "Toca + en el reproductor o en la biblioteca", ANCHO // 2, 830, 34, (125, 128, 128))
            texto(dest, "para guardar canciones aquí", ANCHO // 2, 878, 34, (125, 128, 128))
        for k, idx in enumerate(idxs):
            fila = self._rect_fila(k)
            if fila.bottom < self.LISTA.y or fila.y > self.LISTA.bottom:
                continue
            fila_cancion(dest, fila, self.lamp, idx, reservar=110)
            a = self._acc(fila)
            pygame.draw.circle(dest, GRIS_BOTON_ON, a.center, 38)
            c, r = a.center, 15
            if self.k is None:                                  # +  (✓ si ya está en alguna playlist)
                if d.en_alguna(idx):
                    pygame.draw.lines(dest, (255, 255, 255), False,
                                      [(c[0] - r, c[1]), (c[0] - 4, c[1] + 11), (c[0] + r, c[1] - 11)], 6)
                else:
                    pygame.draw.line(dest, (225, 227, 227), (c[0] - r, c[1]), (c[0] + r, c[1]), 6)
                    pygame.draw.line(dest, (225, 227, 227), (c[0], c[1] - r), (c[0], c[1] + r), 6)
            else:                                               # ×
                pygame.draw.line(dest, (225, 227, 227), (c[0] - 12, c[1] - 12), (c[0] + 12, c[1] + 12), 6)
                pygame.draw.line(dest, (225, 227, 227), (c[0] - 12, c[1] + 12), (c[0] + 12, c[1] - 12), 6)
        dest.set_clip(None)
        self._barra_scroll(dest)


class PaginaPlaylists(_ListaDesplazable):
    """'Tus playlists': tu biblioteca y todas las playlists que has creado, más el botón de crear una nueva."""
    R_VOLVER = pygame.Rect(60, 70, 120, 74)
    R_NUEVA = pygame.Rect(60, 200, 960, 110)
    LISTA = pygame.Rect(0, 350, ANCHO, ALTO - ALT_MINI - NAV_H - 350)
    PASO, ALTO_FILA = 146, 130

    def __init__(self, app):
        self.app = app
        self.lamp = app.lamp
        self._ini_scroll()

    def abrir(self):
        self._ini_scroll()

    def _n(self):
        return 1 + len(self.lamp.datos.listas)

    def update(self, dt):
        self.scroll = max(0.0, min(self.scroll, self._max_scroll()))

    def evento(self, e):
        if e.type == pygame.MOUSEBUTTONDOWN:
            if self.R_VOLVER.collidepoint(e.pos):
                self.app.atras()
                return True
            if self.R_NUEVA.collidepoint(e.pos):
                self.lamp.guardar.abrir(None)
                return True
        pos = self._desplazar(e)
        if pos is not None:
            k = self._fila_en(pos)
            if k is not None:
                self.app.abrir_lista(None if k == 0 else k - 1)
            return True
        return e.type == pygame.MOUSEBUTTONDOWN and self.LISTA.collidepoint(e.pos)

    def dibujar(self, dest):
        d = self.lamp.datos
        boton_volver(dest, self.R_VOLVER)
        texto_izq(dest, "Tus playlists", 220, 107, 76, ANCHO - 280)
        boton(dest, self.R_NUEVA, "+   Nueva playlist", True, 46)
        dest.set_clip(self.LISTA)
        for k in range(self._n()):
            y = int(self.LISTA.y + k * self.PASO - self.scroll)
            if y > self.LISTA.bottom or y + self.ALTO_FILA < self.LISTA.y:
                continue
            r = pygame.Rect(60, y, 960, self.ALTO_FILA)
            boton(dest, r, "", False, radio=30)
            if k == 0:
                nombre, n = "Mi biblioteca", len(CANCIONES)
            else:
                nombre, n = d.listas[k - 1]["nombre"], len(d.indices(k - 1))
            texto_izq(dest, nombre, r.x + 40, r.centery - 22, 52, r.w - 160)
            texto_izq(dest, f"{n} canci{'ones' if n != 1 else 'ón'}", r.x + 40, r.centery + 34, 32,
                      color=(160, 163, 163))
            c = (r.right - 56, r.centery)
            pygame.draw.lines(dest, (170, 173, 173), False,
                              [(c[0] - 8, c[1] - 18), (c[0] + 10, c[1]), (c[0] - 8, c[1] + 18)], 6)
        dest.set_clip(None)
        self._barra_scroll(dest)


class VentanaGuardar(Ventana):
    """Ventana emergente del botón +: elige en qué playlists guardar la canción (tocar una la marca o
    desmarca) o crea una nueva escribiendo su nombre. Se guarda al instante en emonic_datos.json."""
    CARD = pygame.Rect(60, 300, 960, 1180)
    AREA = pygame.Rect(100, 500, 880, 744)
    R_NUEVA = pygame.Rect(100, 1255, 880, 100)
    R_LISTO = pygame.Rect(100, 1370, 880, 90)
    R_CAMPO = pygame.Rect(100, 560, 880, 120)
    R_CREAR = pygame.Rect(100, 740, 430, 100)
    R_CANCELAR = pygame.Rect(550, 740, 430, 100)
    PASO, ALTO_FILA = 124, 110

    def __init__(self, lamp):
        super().__init__(0, 0, ANCHO, ALTO)
        self.visible = False
        self.lamp = lamp
        self.idx = None
        self.modo = "lista"                  # "lista" | "nombre"
        self.texto = ""
        self.scroll = 0.0
        self.t = 0.0
        self._velo = None

    # ---- estado
    def abrir(self, idx=None):
        self.idx = idx
        self.scroll = 0.0
        self.visible = True
        if idx is None or not self.lamp.datos.listas:
            self._pedir_nombre()
        else:
            self.modo = "lista"

    def cerrar(self):
        self.visible = False
        self._fin_texto()

    def _pedir_nombre(self):
        self.modo = "nombre"
        self.texto = ""
        try:
            pygame.key.start_text_input()
        except Exception:
            pass

    def _fin_texto(self):
        try:
            pygame.key.stop_text_input()
        except Exception:
            pass

    def _crear(self):
        d = self.lamp.datos
        k = d.nueva(self.texto)
        self._fin_texto()
        if self.idx is None:
            self.cerrar()
            if self.lamp.principal is not None:
                self.lamp.principal.abrir_lista(k)        # te lleva a la playlist recién creada (vacía)
            return
        d.alternar(k, self.idx)                           # crea y guarda la canción de una vez
        self.modo = "lista"
        self.scroll = self._max_scroll()

    def _cancelar(self):
        self._fin_texto()
        if self.idx is not None and self.lamp.datos.listas:
            self.modo = "lista"
        else:
            self.cerrar()

    def _max_scroll(self):
        return max(0.0, len(self.lamp.datos.listas) * self.PASO - self.AREA.h)

    def update(self, dt):
        self.t += dt

    # ---- entrada
    def teclado(self, e):
        if self.modo == "nombre":
            if e.type == pygame.TEXTINPUT:
                if len(self.texto) < 30:
                    self.texto += e.text
            elif e.type == pygame.KEYDOWN:
                if e.key == pygame.K_BACKSPACE:
                    self.texto = self.texto[:-1]
                elif e.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                    self._crear()
                elif e.key == pygame.K_ESCAPE:
                    self._cancelar()
        elif e.type == pygame.KEYDOWN and e.key in (pygame.K_ESCAPE, pygame.K_RETURN, pygame.K_KP_ENTER):
            self.cerrar()
        return True

    def rueda(self, pos, dy):
        if self.modo == "lista":
            self.scroll = max(0.0, min(self.scroll - dy * PASO_RUEDA, self._max_scroll()))
        return True

    def evento(self, e):
        if e.type != pygame.MOUSEBUTTONDOWN:
            return True                                    # modal: nada pasa a las ventanas de abajo
        d = self.lamp.datos
        if self.modo == "nombre":
            if self.R_CREAR.collidepoint(e.pos):
                self._crear()
            elif self.R_CANCELAR.collidepoint(e.pos) or not self.CARD.collidepoint(e.pos):
                self._cancelar()
            return True
        if not self.CARD.collidepoint(e.pos) or self.R_LISTO.collidepoint(e.pos):
            self.cerrar()
        elif self.R_NUEVA.collidepoint(e.pos):
            self._pedir_nombre()
        elif self.AREA.collidepoint(e.pos):
            y = e.pos[1] - self.AREA.y + self.scroll
            k = int(y // self.PASO)
            if 0 <= k < len(d.listas) and y - k * self.PASO <= self.ALTO_FILA and self.idx is not None:
                d.alternar(k, self.idx)
        return True

    # ---- dibujo
    def dibujar(self, dest):
        if self._velo is None:
            self._velo = pygame.Surface((ANCHO, ALTO), pygame.SRCALPHA)
            self._velo.fill((0, 0, 0, 175))
        dest.blit(self._velo, (0, 0))
        pygame.draw.rect(dest, GRIS_TARJETA, self.CARD, border_radius=44)
        d = self.lamp.datos
        cx = self.CARD.centerx
        if self.modo == "nombre":
            texto(dest, "Nueva playlist", cx, self.CARD.y + 90, 64)
            if self.idx is not None:
                titulo, _a = nombre_cancion(self.idx)
                texto_ajustado(dest, f"Se guardará: {titulo}", cx, self.CARD.y + 160, 34, 840, (160, 163, 163))
            pygame.draw.rect(dest, GRIS_BOTON_ON, self.R_CAMPO, border_radius=30)
            cursor = "|" if int(self.t * 2) % 2 == 0 else ""
            if self.texto:
                texto_izq(dest, self.texto + cursor, self.R_CAMPO.x + 36, self.R_CAMPO.centery, 52, self.R_CAMPO.w - 72)
            else:
                texto_izq(dest, cursor + f"Playlist {len(d.listas) + 1}", self.R_CAMPO.x + 36,
                          self.R_CAMPO.centery, 48, self.R_CAMPO.w - 72, (125, 128, 128))
            boton(dest, self.R_CREAR, "Crear", True, 46)
            boton(dest, self.R_CANCELAR, "Cancelar", False, 46)
            return
        texto(dest, "Guardar en playlist", cx, self.CARD.y + 80, 62)
        if self.idx is not None:
            titulo, _a = nombre_cancion(self.idx)
            texto_ajustado(dest, titulo, cx, self.CARD.y + 150, 36, 840, (160, 163, 163))
        dest.set_clip(self.AREA)
        for k, l in enumerate(d.listas):
            y = int(self.AREA.y + k * self.PASO - self.scroll)
            if y > self.AREA.bottom or y + self.ALTO_FILA < self.AREA.y:
                continue
            r = pygame.Rect(self.AREA.x, y, self.AREA.w, self.ALTO_FILA)
            dentro = self.idx is not None and d.contiene(k, self.idx)
            boton(dest, r, "", dentro, radio=30)
            texto_izq(dest, l["nombre"], r.x + 36, r.centery - 18, 46, r.w - 180)
            texto_izq(dest, f"{len(d.indices(k))} canciones", r.x + 36, r.centery + 30, 30, color=(160, 163, 163))
            c = (r.right - 64, r.centery)
            if dentro:
                pygame.draw.circle(dest, (240, 242, 242), c, 30)
                pygame.draw.lines(dest, (40, 42, 42), False,
                                  [(c[0] - 13, c[1]), (c[0] - 4, c[1] + 10), (c[0] + 14, c[1] - 10)], 6)
            else:
                pygame.draw.circle(dest, (150, 153, 153), c, 30, 4)
        dest.set_clip(None)
        boton(dest, self.R_NUEVA, "+   Nueva playlist", False, 44)
        boton(dest, self.R_LISTO, "Listo", True, 44)


class PaginaPerfil:
    """Cuarta pestaña: reservada. Por ahora solo muestra un aviso."""

    def __init__(self, lamp):
        self.lamp = lamp

    def update(self, dt):
        pass

    def evento(self, e):
        return False

    def dibujar(self, dest):
        texto_izq(dest, "Perfil", 60, 100, 90)
        texto(dest, "Próximamente", ANCHO // 2, 640, 56, (150, 153, 153))


class VentanaPrincipal(Ventana):
    """Contenedor de las pestañas: cada una es una ventana distinta (Inicio, Buscar, Descargas y, dentro
    de Descargas, la página de cada fuente). Se ve cuando el reproductor está minimizado."""

    def __init__(self, lamp):
        super().__init__(0, 0, ANCHO, ALTO)
        self.lamp = lamp
        self.pestana = "inicio"
        self.sitio = None                    # fuente abierta dentro de Descargas (None = la lista)
        self.paginas = {"inicio": PaginaInicio(lamp),
                        "buscar": PaginaBuscar(lamp),
                        "descargas": PaginaDescargas(self)}
        self.pagina_sitio = PaginaSitio(self)
        self.pagina_lista = PaginaLista(self)
        self.pagina_playlists = PaginaPlaylists(self)
        self.sub = []                        # subpáginas abiertas encima de la pestaña (la última se ve)
        lamp.principal = self

    @property
    def pagina(self):
        if self.sub:
            return self.sub[-1]
        if self.pestana == "descargas" and self.sitio is not None:
            return self.pagina_sitio
        return self.paginas[self.pestana]

    def ir(self, pestana):
        """Cambia de pestaña (si ya estás en ella y en una subpágina, vuelve a su inicio)."""
        self.paginas["buscar"].foco = False
        self.pestana = pestana
        self.sitio = None
        self.sub = []

    def abrir_lista(self, k=None):
        """Abre la ventana con la lista de canciones de la biblioteca (None) o de la playlist k."""
        if self.lamp.mini is False:
            self.lamp.contraer()
        self.pagina_lista.abrir(k)
        if not (self.sub and self.sub[-1] is self.pagina_lista):
            self.sub.append(self.pagina_lista)

    def abrir_playlists(self):
        self.pagina_playlists.abrir()
        self.sub.append(self.pagina_playlists)

    def abrir_sitio(self, i):
        self.sitio = i
        self.pagina_sitio.abrir(i)

    def atras(self):
        if self.sub:
            self.sub.pop()
        else:
            self.sitio = None

    def update(self, dt):
        self.pagina.update(dt)

    def dibujar(self, dest):
        dest.fill((29, 30, 30))
        self.pagina.dibujar(dest)

    def evento(self, e):
        return self.pagina.evento(e)

    def rueda(self, pos, dy):
        f = getattr(self.pagina, "rueda", None)
        return bool(f(pos, dy)) if f is not None else False

    def teclado(self, e):
        """True si la pestaña activa (la búsqueda con el foco) se quedó con la tecla."""
        if self.pestana != "buscar" or not self.lamp.mini:
            return False
        return self.paginas["buscar"].teclado(e)


def dibujar_icono_nav(dest, pid, r, activo):
    """Iconos de ejemplo de la barra (los reemplazas poniendo ui/nav_<id>.png): nota, lupa, descargas, perfil."""
    cx, cy = r.center
    col = (242, 244, 244) if activo else (165, 168, 168)
    if activo:                                           # fondo de la pestaña activa
        pygame.draw.rect(dest, GRIS_BOTON_ON, r, border_radius=44)
    if pid == "inicio":                                  # nota musical
        for dx, dy in ((-20, 26), (24, 18)):
            pygame.draw.circle(dest, col, (cx + dx, cy + dy), 13)
        pygame.draw.line(dest, col, (cx - 8, cy + 24), (cx - 8, cy - 28), 6)
        pygame.draw.line(dest, col, (cx + 36, cy + 16), (cx + 36, cy - 36), 6)
        pygame.draw.polygon(dest, col, [(cx - 8, cy - 28), (cx + 36, cy - 36), (cx + 36, cy - 20), (cx - 8, cy - 12)])
    elif pid == "buscar":                                # lupa
        pygame.draw.circle(dest, col, (cx - 6, cy - 6), 26, 7)
        pygame.draw.line(dest, col, (cx + 14, cy + 14), (cx + 36, cy + 36), 10)
    elif pid == "descargas":                             # flecha hacia una bandeja
        pygame.draw.line(dest, col, (cx, cy - 34), (cx, cy + 6), 8)
        pygame.draw.polygon(dest, col, [(cx - 22, cy - 2), (cx + 22, cy - 2), (cx, cy + 24)])
        pygame.draw.lines(dest, col, False, [(cx - 34, cy + 10), (cx - 34, cy + 36), (cx + 34, cy + 36),
                                             (cx + 34, cy + 10)], 7)
    elif pid == "perfil":                                # persona: cabeza y hombros
        pygame.draw.circle(dest, col, (cx, cy - 16), 17, 7)
        pygame.draw.arc(dest, col, pygame.Rect(cx - 32, cy + 6, 64, 56), 0.0, math.pi, 7)
    else:
        texto(dest, pid[:1].upper(), cx, cy, 56, col)


class BarraNavegacion(Ventana):
    """Barra inferior con las pestañas (iconos). Forma una sola tarjeta con el mini reproductor, que queda
    justo encima. Está visible en la portada y con el reproductor minimizado; se oculta en los
    visualizadores a pantalla completa. Tocar una pestaña cambia de ventana (y si el reproductor estaba
    abierto, lo minimiza)."""

    def __init__(self, lamp, principal):
        super().__init__(0, ALTO - NAV_H, ANCHO, NAV_H)
        self.lamp = lamp
        self.principal = principal
        self.px = NAV_H                       # alto visible ahora (se desliza al aparecer/ocultarse)
        n = len(PESTANAS)
        gap, margen = 20, 70
        w = (ANCHO - 2 * margen - gap * (n - 1)) // n
        self.botones = [(pid, txt, pygame.Rect(margen + i * (w + gap), 30, w, 120))
                        for i, (pid, txt) in enumerate(PESTANAS)]

    def update(self, dt):
        lamp = self.lamp
        px = max(lamp.margen_inf(), NAV_H * (1.0 - lamp.vista_t))
        if lamp.ajustes is not None and lamp.ajustes.visible:
            px = 0
        self.px = int(round(px))
        self.visible = self.px > 0
        self.rect = pygame.Rect(0, ALTO - self.px, ANCHO, self.px)

    def dibujar(self, dest):
        y0 = ALTO - self.px
        frac = self.lamp.margen_inf() / float(NAV_H)       # 1 = pegada a la mini ... 0 = flotando sola
        rad = int(44 * (1.0 - min(1.0, frac)))
        radios = dict(border_top_left_radius=rad, border_top_right_radius=rad,
                      border_bottom_left_radius=44, border_bottom_right_radius=44)
        card = pygame.Rect(30, y0, 1020, NAV_H - 20)
        pygame.draw.rect(dest, GRIS_TARJETA, card, **radios)
        if frac > 0.5:                                      # sin línea entre la mini y la barra
            pygame.draw.line(dest, GRIS_TARJETA, (card.x + 2, y0), (card.right - 3, y0), 3)
        for pid, txt, r in self.botones:
            activo = self.lamp.mini and pid == self.principal.pestana
            rr = r.move(0, y0)
            clave = f"nav_{pid}"
            if ui_img(clave) is not None or (activo and ui_img(clave + "_on") is not None):
                boton_ui(dest, rr, clave, txt, activo, 38)
            else:
                dibujar_icono_nav(dest, pid, rr, activo)
                etiqueta_ui(dest, rr, clave, False)

    def rueda(self, pos, dy):
        return True

    def evento(self, e):
        if e.type == pygame.MOUSEBUTTONDOWN:
            y0 = ALTO - self.px
            for pid, txt, r in self.botones:
                if r.move(0, y0).collidepoint(e.pos):
                    self.principal.ir(pid)
                    if not self.lamp.mini:
                        self.lamp.contraer()
                    return True
        return e.type != pygame.MOUSEMOTION      # la barra consume los toques sobre ella


class VentanaAjustesVis(Ventana):
    """Panel inferior para elegir visualizador y estilo. Se desliza sobre el reproductor,
    que sigue visible (y reaccionando) arriba para ver los cambios en vivo.
    Es modal: toca fuera del panel o 'Listo' para cerrarlo."""

    ALTO_HOJA = 1020

    def __init__(self, lamp):
        super().__init__(0, 0, ANCHO, ALTO)
        self.lamp = lamp
        self.visible = False
        self.prog = 0.0                       # 0 = oculto, 1 = abierto
        self.objetivo = 0.0
        self.hoja = pygame.Surface((ANCHO, self.ALTO_HOJA), pygame.SRCALPHA)
        self.velo = pygame.Surface((ANCHO, ALTO))
        self.velo.fill((0, 0, 0))
        self.r_listo = pygame.Rect(60, 905, 960, 95)

    def abrir(self):
        self.visible = True
        self.objetivo = 1.0

    def cerrar(self):
        self.objetivo = 0.0

    def update(self, dt):
        if not self.visible:
            return
        self.prog += (self.objetivo - self.prog) * min(1.0, 10.0 * dt)
        if abs(self.objetivo - self.prog) < 0.004:
            self.prog = self.objetivo
            if self.objetivo == 0.0:
                self.visible = False

    # filas de opciones según el visualizador activo -> coords locales de la hoja
    def _filas(self):
        lamp = self.lamp
        defs = [
            ("Tipo", 110, [("Lámpara de lava", "modo", "lava"), ("Láseres", "modo", "laser"),
                            ("Morfógeno", "modo", "morfo")]),
            ("Paleta", 100, [("Emoción", "paleta", "energia"), ("Portada", "paleta", "portada"),
                             ("Cálida", "paleta", "calida"),
                             ("Fría", "paleta", "fria"), ("Neón", "paleta", "neon")]),
        ]
        if lamp.vis_modo == "lava":
            defs.append(("Cantidad de masa", 100, [("Pocas", "lava_masa", 8),
                                                   ("Normal", "lava_masa", 14),
                                                   ("Muchas", "lava_masa", 24)]))
        elif lamp.vis_modo == "laser":
            defs.append(("Cantidad de rayos", 100, [("Pocos", "laser_rayos", 8),
                                                    ("Normal", "laser_rayos", 14),
                                                    ("Muchos", "laser_rayos", 20)]))
            defs.append(("Disposición", 100, [("Vórtice", "laser_disp", "vortice"), ("Abanico", "laser_disp", "abanico"),
                                              ("Cruzado", "laser_disp", "cruzado"),
                                              ("Radial", "laser_disp", "radial")]))
        else:                                  # Morfógeno
            defs.append(("Simetría", 100, [("Ninguna", "morfo_sim", "ninguna"),
                                           ("Espejo", "morfo_sim", "espejo"),
                                           ("Cuádruple", "morfo_sim", "cuadruple")]))
            defs.append(("Reactividad", 100, [("Suave", "morfo_react", "suave"),
                                              ("Normal", "morfo_react", "normal"),
                                              ("Intensa", "morfo_react", "intensa")]))
        defs.append(("Cristal", 90, [("Nítido", "cristal", 0), ("Suave", "cristal", 1),
                                     ("Mate", "cristal", 2)]))
        filas, y, gap = [], 140, 20
        for etiqueta, alto, opciones in defs:
            w = (960 - gap * (len(opciones) - 1)) // len(opciones)
            rects = [pygame.Rect(60 + k * (w + gap), y + 32, w, 90) for k in range(len(opciones))]
            filas.append((etiqueta, y, [(t, c, v, r) for (t, c, v), r in zip(opciones, rects)]))
            y += 32 + 90 + 28
        return filas

    def _activo(self, clave, valor):
        if clave == "modo":
            return self.lamp.vis_modo == valor
        return self.lamp.cfg[clave] == valor

    def _elegir(self, clave, valor):
        if clave == "modo":
            self.lamp.vis_modo = valor
        else:
            self.lamp.cfg[clave] = valor
        self.lamp.aplicar_config()

    def evento(self, e):
        if (e.type == pygame.MOUSEBUTTONDOWN and self.objetivo == 1.0 and self.prog > 0.9):
            y_top = ALTO - self.ALTO_HOJA * self.prog
            if e.pos[1] < y_top:                       # toque fuera del panel
                self.cerrar()
                return True
            p = (e.pos[0], e.pos[1] - y_top)
            if self.r_listo.collidepoint(p):
                self.cerrar()
                return True
            for _, _, opciones in self._filas():
                for _, clave, valor, r in opciones:
                    if r.collidepoint(p):
                        self._elegir(clave, valor)
                        return True
        return True                                    # modal: consume todo el mouse

    def dibujar(self, dest):
        self.velo.set_alpha(int(110 * self.prog))
        dest.blit(self.velo, (0, 0))

        hoja = self.hoja
        hoja.fill((0, 0, 0, 0))
        pygame.draw.rect(hoja, (36, 38, 38, 250), hoja.get_rect(),
                         border_top_left_radius=48, border_top_right_radius=48)
        pygame.draw.rect(hoja, (125, 128, 128), (ANCHO // 2 - 50, 18, 100, 8), border_radius=4)
        texto(hoja, "Visualizador", ANCHO // 2, 78, 60)

        for etiqueta, y, opciones in self._filas():
            texto_izq(hoja, etiqueta, 60, y, 38, color=(185, 188, 188))
            for t, clave, valor, r in opciones:
                muestra = PALETAS.get(valor) if clave == "paleta" else None
                nombre_img = f"{clave}_{valor}"
                con_img = ui_img(nombre_img) is not None
                icono = None if con_img else ui_img("icono_" + nombre_img)     # animación junto al nombre
                desp = 44 if icono is not None else (32 if muestra else 0)
                boton_ui(hoja, r, nombre_img, t, self._activo(clave, valor),
                         36 if clave in ("paleta", "modo") else 40, desp=desp)
                if icono is not None:
                    lado = r.h - 24
                    dibujar_icono(hoja, icono, pygame.Rect(r.x + 14, r.centery - lado // 2, lado, lado))
                elif muestra and not con_img:                          # dos puntos con los colores de la paleta
                    for k, col in enumerate(muestra):
                        pygame.draw.circle(hoja, col, (r.x + 26 + k * 24, r.centery), 9)
        boton_ui(hoja, self.r_listo, "listo", "Listo", False, 46, estado_texto=True)

        dest.blit(hoja, (0, ALTO - int(self.ALTO_HOJA * self.prog)))


# ------------------------------------------------------------------ inicio: elegir carpeta de música
def pedir_permisos_android():
    """Pide permiso para leer la música (y portadas) del celular. En PC no hace nada."""
    if not ES_ANDROID:
        return
    try:
        from android.permissions import request_permissions, Permission
        from android import api_version
        if api_version >= 33:              # Android 13+: permisos por tipo de archivo
            pedidos = [Permission.READ_MEDIA_AUDIO, Permission.READ_MEDIA_IMAGES]
        else:
            pedidos = [Permission.READ_EXTERNAL_STORAGE]
        request_permissions(pedidos)
    except Exception as ex:
        print(f"⚠ No se pudieron pedir permisos: {ex}")


def carpeta_inicial():
    """Dónde empieza el explorador de carpetas."""
    if ES_ANDROID:
        raiz = "/storage/emulated/0"
        for sub in ("Music", "Música", "Download"):
            if os.path.isdir(os.path.join(raiz, sub)):
                return os.path.join(raiz, sub)
        return raiz
    for c in (os.path.join(os.path.expanduser("~"), "Music"), carpetas_base()[0]):
        if os.path.isdir(c):
            return c
    return os.getcwd()


RAIZ_ANDROID = "/storage/emulated/0"      # en el celular no se puede subir más allá


class PantallaCarpeta:
    """Primera pantalla: aviso "Elegir carpeta de música" y un explorador de carpetas táctil.
    Devuelve (con ejecutar()) la carpeta elegida, o None si el usuario cerró la app."""
    FILA_H = 130
    LISTA = pygame.Rect(60, 470, ANCHO - 120, 1120)

    def __init__(self, ultima):
        self.ultima = ultima if ultima and contar_canciones(ultima) else None
        self.modo = "aviso"                        # "aviso" -> "explorar"
        self.actual = carpeta_inicial()
        self.subs, self.n_canciones = [], 0
        self.scroll = 0.0
        self.toque = None                          # (y inicial, scroll inicial) mientras se arrastra
        self.movido = False
        self.mensaje = ""
        self.r_elegir = pygame.Rect(140, 1230, ANCHO - 280, 150)
        self.r_ultima = pygame.Rect(140, 1420, ANCHO - 280, 130)
        self.r_subir = pygame.Rect(60, 300, 260, 110)
        self.r_usar = pygame.Rect(60, 1640, ANCHO - 120, 150)
        self.r_cancelar = pygame.Rect(ANCHO - 320, 300, 260, 110)
        self._listar()

    def _listar(self):
        try:
            nombres = os.listdir(self.actual)
        except OSError as ex:
            self.mensaje = f"No se puede abrir esta carpeta ({ex.__class__.__name__})"
            nombres = []
        else:
            self.mensaje = ""
        self.subs = sorted((n for n in nombres if not n.startswith(".")
                            and os.path.isdir(os.path.join(self.actual, n))), key=_norm)
        self.n_canciones = contar_canciones(self.actual)
        self.scroll = 0.0

    def _puede_subir(self):
        padre = os.path.dirname(self.actual.rstrip("/\\")) or self.actual
        if ES_ANDROID and not padre.startswith(RAIZ_ANDROID):
            return False
        return padre != self.actual

    def _subir(self):
        if self._puede_subir():
            self.actual = os.path.dirname(self.actual.rstrip("/\\")) or self.actual
            self._listar()

    def _max_scroll(self):
        return max(0, len(self.subs) * self.FILA_H - self.LISTA.h)

    # ---------------------------------------------------------- eventos (coords de diseño)
    def evento(self, e):
        """Devuelve la carpeta elegida, "salir", o None para seguir."""
        if e.type == pygame.QUIT:
            return "salir"
        if e.type == pygame.KEYDOWN and e.key in (pygame.K_AC_BACK, pygame.K_ESCAPE):
            if self.modo == "explorar":
                if self._puede_subir():
                    self._subir()
                else:
                    self.modo = "aviso"
            return None
        if self.modo == "aviso":
            if e.type == pygame.MOUSEBUTTONUP and e.button == 1:
                if self.r_elegir.collidepoint(e.pos):
                    pedir_permisos_android()
                    self.modo = "explorar"
                    self._listar()
                elif self.ultima and self.r_ultima.collidepoint(e.pos):
                    return self.ultima
            return None
        # modo explorar
        if e.type == pygame.MOUSEWHEEL:
            self.scroll = max(0, min(self._max_scroll(), self.scroll - e.y * 80))
        elif e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
            if self.LISTA.collidepoint(e.pos):
                self.toque = (e.pos[1], self.scroll)
                self.movido = False
        elif e.type == pygame.MOUSEMOTION and self.toque is not None:
            dy = e.pos[1] - self.toque[0]
            if abs(dy) > 25:
                self.movido = True
            if self.movido:
                self.scroll = max(0, min(self._max_scroll(), self.toque[1] - dy))
        elif e.type == pygame.MOUSEBUTTONUP and e.button == 1:
            arrastre, self.toque = self.toque, None
            if arrastre is not None and self.movido:
                return None
            if self.r_subir.collidepoint(e.pos):
                self._subir()
            elif self.r_cancelar.collidepoint(e.pos):
                self.modo = "aviso"
            elif self.r_usar.collidepoint(e.pos) and self.n_canciones:
                return self.actual
            elif self.LISTA.collidepoint(e.pos):
                i = int((e.pos[1] - self.LISTA.y + self.scroll) // self.FILA_H)
                if 0 <= i < len(self.subs):
                    self.actual = os.path.join(self.actual, self.subs[i])
                    self._listar()
        return None

    # ---------------------------------------------------------- dibujo
    def dibujar(self, dest):
        dest.fill(GRIS_FONDO)
        if self.modo == "aviso":
            self._dibujar_aviso(dest)
        else:
            self._dibujar_explorador(dest)

    def _dibujar_aviso(self, dest):
        texto(dest, "EMONIC LAVA", ANCHO // 2, 330, 120, (255, 140, 60), sombra=True)
        tarjeta = pygame.Rect(80, 560, ANCHO - 160, 560)
        pygame.draw.rect(dest, GRIS_TARJETA, tarjeta, border_radius=40)
        pygame.draw.rect(dest, (255, 140, 60), tarjeta, width=4, border_radius=40)
        cx, cy = ANCHO // 2 - 330, 660                                   # triángulo de advertencia
        pygame.draw.polygon(dest, (255, 170, 60), [(cx, cy - 34), (cx - 38, cy + 30), (cx + 38, cy + 30)])
        texto(dest, "!", cx, cy + 6, 56, GRIS_TARJETA)
        texto(dest, "Elegir carpeta de música", ANCHO // 2 + 40, 660, 64, (255, 200, 120))
        lineas = ["Para empezar, elige la carpeta de tu",
                  "celular donde guardas tus canciones",
                  "(MP3, WAV, OGG o FLAC).",
                  "",
                  "Si junto a cada canción hay una imagen",
                  "con el mismo nombre (.jpg o .png),",
                  "se usará como portada."]
        for k, l in enumerate(lineas):
            texto(dest, l, ANCHO // 2, 770 + k * 48, 44, (225, 225, 225))
        boton(dest, self.r_elegir, "Elegir carpeta", True, 60, radio=40)
        if self.ultima:
            boton(dest, self.r_ultima, "", False, 40, radio=36)
            texto_ajustado(dest, "Seguir con: " + os.path.basename(self.ultima.rstrip("/\\")),
                           self.r_ultima.centerx, self.r_ultima.centery, 44, self.r_ultima.w - 40)

    def _dibujar_explorador(self, dest):
        texto(dest, "Elige tu carpeta de música", ANCHO // 2, 120, 62)
        texto_ajustado(dest, self.actual, ANCHO // 2, 210, 36, ANCHO - 100, (170, 170, 170))
        boton(dest, self.r_subir, "Subir", False, 44)
        if not self._puede_subir():
            s = pygame.Surface(self.r_subir.size, pygame.SRCALPHA)
            s.fill((29, 30, 30, 160))
            dest.blit(s, self.r_subir)
        boton(dest, self.r_cancelar, "Volver", False, 44)

        dest.set_clip(self.LISTA)
        if not self.subs:
            texto(dest, self.mensaje or "(no hay subcarpetas)", ANCHO // 2, self.LISTA.y + 90, 40,
                  (150, 150, 150))
        primero = int(self.scroll // self.FILA_H)
        for i in range(primero, min(len(self.subs), primero + self.LISTA.h // self.FILA_H + 2)):
            y = self.LISTA.y + i * self.FILA_H - int(self.scroll)
            fila = pygame.Rect(self.LISTA.x, y + 8, self.LISTA.w, self.FILA_H - 16)
            pygame.draw.rect(dest, GRIS_BOTON, fila, border_radius=24)
            pygame.draw.polygon(dest, (255, 140, 60), [(fila.x + 30, fila.centery - 14),
                                (fila.x + 30, fila.centery + 14), (fila.x + 52, fila.centery)])
            texto_izq(dest, self.subs[i], fila.x + 75, fila.centery, 46, fila.w - 105)
        dest.set_clip(None)

        if self.n_canciones:
            boton(dest, self.r_usar, f"Usar esta carpeta ({self.n_canciones} canciones)", True, 50, radio=40)
        else:
            pygame.draw.rect(dest, GRIS_TARJETA, self.r_usar, border_radius=40)
            texto(dest, "Aquí no hay canciones: entra a otra carpeta", self.r_usar.centerx,
                  self.r_usar.centery, 40, (140, 140, 140))

    def ejecutar(self):
        refresco = 0
        while True:
            refresco += 1                 # el permiso llega después de que el usuario lo acepta:
            if (self.modo == "explorar" and refresco % 45 == 0 and self.toque is None
                    and (self.mensaje or (not self.subs and not self.n_canciones))):
                self._listar()            # vuelve a mirar la carpeta cada ~1.5 s mientras esté vacía
            for e in pygame.event.get():
                if e.type in (pygame.MOUSEBUTTONDOWN, pygame.MOUSEBUTTONUP, pygame.MOUSEMOTION):
                    e = escalar_mouse(e)
                r = self.evento(e)
                if r == "salir":
                    return None
                if r:
                    return r
            self.dibujar(lienzo)
            presentar()
            reloj.tick(30)


def elegir_carpeta_musica():
    """Muestra el aviso al inicio y carga la biblioteca. Devuelve False si el usuario cerró la app."""
    cfg = leer_config()
    while True:
        carpeta = PantallaCarpeta(cfg.get("carpeta_musica")).ejecutar()
        if carpeta is None:
            return False
        if cargar_biblioteca(carpeta):
            cfg["carpeta_musica"] = carpeta
            guardar_config(cfg)
            return True


# ------------------------------------------------------------------ setup / teclado
def iniciar_pantalla():
    """Crea la ventana. En el celular: pantalla completa (SDL escala y centra el lienzo de 1080x1920)."""
    global pantalla, reloj, lienzo, factor_ventana, desplazamiento
    pygame.mixer.pre_init(44100, -16, 2, 2048)
    pygame.init()
    desplazamiento = (0, 0)
    if ES_ANDROID:
        try:
            pantalla = pygame.display.set_mode((ANCHO, ALTO), pygame.SCALED | pygame.FULLSCREEN)
            factor_ventana = 1.0
            lienzo = pantalla                   # se dibuja directo: SDL se encarga de escalar y del toque
        except pygame.error:
            pantalla = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
            w, h = pantalla.get_size()
            factor_ventana = min(w / ANCHO, h / ALTO)
            desplazamiento = ((w - int(ANCHO * factor_ventana)) // 2, (h - int(ALTO * factor_ventana)) // 2)
            lienzo = pygame.Surface((ANCHO, ALTO))
    else:
        # La ventana SIEMPRE cabe en el monitor (5% de margen para la barra de tareas)
        info = pygame.display.Info()
        factor_ventana = min(info.current_w / ANCHO, info.current_h / ALTO) * 0.95
        pantalla = pygame.display.set_mode((int(ANCHO * factor_ventana),
                                            int(ALTO * factor_ventana)))
        lienzo = pygame.Surface((ANCHO, ALTO))     # aquí se dibuja en coords de diseño
    pygame.display.set_caption("EMONIC LAVA — prototipo 1080x1920")
    reloj = pygame.time.Clock()


def presentar():
    """Lleva el lienzo (coords de diseño) a la pantalla real."""
    if lienzo is not pantalla:
        w, h = int(ANCHO * factor_ventana), int(ALTO * factor_ventana)
        destino = pantalla.subsurface(pygame.Rect(desplazamiento, (w, h)))
        pygame.transform.smoothscale(lienzo, (w, h), destino)
    pygame.display.flip()


def setup():
    global gestor, ventana_lampara, ventana_principal, ventana_ajustes, ventana_nav, ventana_guardar
    # (la luz de bombilla detrás de los botones se eliminó)

    ventana_lampara = VentanaLampara()
    ventana_lampara.cargar_recursos()
    ventana_principal = VentanaPrincipal(ventana_lampara)
    ventana_ajustes = VentanaAjustesVis(ventana_lampara)
    ventana_lampara.ajustes = ventana_ajustes
    ventana_nav = BarraNavegacion(ventana_lampara, ventana_principal)

    ventana_guardar = VentanaGuardar(ventana_lampara)
    ventana_lampara.guardar = ventana_guardar

    gestor = GestorVentanas()
    gestor.add(ventana_principal)     # se dibuja primero (fondo)
    gestor.add(ventana_lampara)
    gestor.add(ventana_nav)           # barra de pestañas (sobre el reproductor)
    gestor.add(ventana_ajustes)
    gestor.add(ventana_guardar)       # se dibuja último (arriba de todo): "Guardar en playlist"

def escalar_mouse(e):
    """Convierte la posición del mouse de píxeles de ventana a coords de diseño."""
    d = dict(e.dict)
    d["pos"] = ((e.pos[0] - desplazamiento[0]) / factor_ventana,
                (e.pos[1] - desplazamiento[1]) / factor_ventana)
    if e.type == pygame.MOUSEMOTION and "rel" in d:
        d["rel"] = (e.rel[0] / factor_ventana, e.rel[1] / factor_ventana)
    return pygame.event.Event(e.type, d)


def teclado(e):
    global volumen, MOSTRAR_UI
    lamp = ventana_lampara
    rep = lamp.reproductor
    k, car = e.key, e.unicode
    if rep is not None:
        if car == 'a':
            rep.cue(rep.posicion - 5000)
        elif car == 'd':
            rep.cue(rep.posicion + 5000)
        elif car == 'r':
            rep.rewind()
        elif k == pygame.K_SPACE:
            rep.pause() if rep.esta_reproduciendo() else rep.play()
        elif k == pygame.K_UP:
            volumen = min(1.0, volumen + 0.05)
            rep.set_gain(mapear_volumen_a_ganancia(volumen))
        elif k == pygame.K_DOWN:
            volumen = max(0.0, volumen - 0.05)
            rep.set_gain(mapear_volumen_a_ganancia(volumen))
    if car == '1':
        lamp.lampara.agregar()
    elif car == '2':
        lamp.lampara.quitar()
    elif car == 'm':
        lamp.contraer() if not lamp.mini else lamp.expandir()
    elif car == 'v':
        if lamp.vista == "normal":
            lamp.vista = "visualizador"
        else:
            orden = ["lava", "laser", "morfo"]
            lamp.vis_modo = orden[(orden.index(lamp.vis_modo) + 1) % len(orden)]
    elif car == 'c':
        lamp.vista = "normal" if lamp.vista == "visualizador" else "visualizador"
    elif car == 'i':                  # mapa de imágenes: rotula cada botón con su archivo
        MOSTRAR_UI = not MOSTRAR_UI
    elif car == 'g':                  # crea ui_plantillas/ con una imagen de ejemplo por botón
        carpeta, n = generar_plantillas()
        print(f"[imágenes] {n} plantillas creadas en {carpeta}")
        pygame.display.set_caption(f"{n} plantillas creadas en {carpeta}")
    elif car == 'e':
        est = "analizando..." if lamp.emocion is None else "ok"
        print(f"[emoción] energía {lamp.energia:.2f} | valencia {lamp.valencia:.2f} ({est}) | graves {lamp.bass_s:.2f} medios {lamp.mid_s:.2f} agudos {lamp.high_s:.2f}")


# ------------------------------------------------------------------ bucle principal
def manejar_evento(e):
    """Reparte un evento de pygame. Devuelve True si hay que cerrar la app."""
    if e.type == pygame.QUIT:
        return True
    if e.type == pygame.MOUSEWHEEL:
        mx, my = pygame.mouse.get_pos()
        gestor.rueda(((mx - desplazamiento[0]) / factor_ventana,
                      (my - desplazamiento[1]) / factor_ventana), e.y)
    elif e.type == pygame.KEYDOWN and e.key == pygame.K_AC_BACK:
        if not ventana_lampara.mini:        # botón Atrás del celular: minimiza el reproductor
            ventana_lampara.contraer()      # (con el reproductor ya mini no hace nada: no cierra la app)
    elif e.type in (pygame.MOUSEBUTTONDOWN, pygame.MOUSEBUTTONUP) and e.button != 1:
        pass          # la rueda (botones 4/5 de pygame) y los demás botones no abren el reproductor
    elif e.type in (pygame.MOUSEBUTTONDOWN, pygame.MOUSEBUTTONUP, pygame.MOUSEMOTION):
        gestor.evento(escalar_mouse(e))
    elif e.type in (pygame.KEYDOWN, pygame.TEXTINPUT):
        if ventana_guardar.visible:
            ventana_guardar.teclado(e)               # la ventana emergente se queda con el teclado
        elif not ventana_principal.teclado(e) and e.type == pygame.KEYDOWN:
            teclado(e)        # (si la búsqueda tiene el foco, se queda con el teclado)
    return False


def main():
    if getattr(sys, "frozen", False):     # como .exe: las canciones, portadas y ui/ se buscan junto al .exe
        os.chdir(os.path.dirname(os.path.abspath(sys.executable)))
    iniciar_pantalla()
    if not elegir_carpeta_musica():       # aviso "Elegir carpeta de música" al inicio
        pygame.quit()
        return
    setup()
    corriendo = True
    while corriendo:
        dt = min(reloj.get_time() / 1000.0, 0.05)
        for e in pygame.event.get():
            if manejar_evento(e):
                corriendo = False
        gestor.update(dt)
        gestor.dibujar(lienzo)                           # ← dibuja en el lienzo virtual
        presentar()                                      # ← escala final
        reloj.tick(FPS)
    pygame.quit()
    
    


if __name__ == "__main__":
    main()