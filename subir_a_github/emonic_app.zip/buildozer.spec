[app]
# Nombre que se ve en el celular
title = Emonic Lava
package.name = emoniclava
package.domain = org.judark

# preparar_movil.ps1 copia aquí main.py (= LamparaLava), ui/ y los PNG de la app.
# Las canciones NO se empaquetan: el usuario elige su carpeta de música al abrir la app.
source.dir = .
source.include_exts = py,png,jpg,json,ttf
source.exclude_dirs = bin,.buildozer

version = 0.1

# pygame + numpy (incluye sndarray/surfarray); pyjnius y android para permisos y abrir enlaces.
# Python 3.10 fijo: la receta de pygame de python-for-android (pygame 2.1.0) no compila con Python 3.11+.
requirements = python3==3.10.12,hostpython3==3.10.12,pygame,numpy,pyjnius,android

orientation = portrait
fullscreen = 1

# Leer la música y las portadas del celular
#   Android 13+ : READ_MEDIA_AUDIO y READ_MEDIA_IMAGES
#   Android 12- : READ_EXTERNAL_STORAGE
android.permissions = READ_MEDIA_AUDIO, READ_MEDIA_IMAGES, (name=android.permission.READ_EXTERNAL_STORAGE;maxSdkVersion=32)

android.api = 33
android.minapi = 24
android.ndk = 25b
# arm64-v8a: casi todos los celulares actuales (agregar armeabi-v7a solo para equipos muy viejos; duplica el tiempo)
android.archs = arm64-v8a
android.accept_sdk_license = True

# Versión fija de python-for-android que funciona con pygame + Python 3.10 (la de "master" usa Python 3.14)
p4a.branch = v2024.01.21
p4a.bootstrap = sdl2

# icon.filename = %(source.dir)s/icono.png
# presplash.filename = %(source.dir)s/Bckground.png

[buildozer]
log_level = 2
warn_on_root = 1
